# ROADMAP.md

Sequenced by what unblocks what, not just by feature excitement. Nothing
below is started unless `PROJECT_STATE.md` says so.

## Done (v0.7)

- [x] **Config file loader** (`config/settings.py`): `load_config_file()`
      (JSON always, YAML if PyYAML happens to be installed -- not added as
      a hard dependency) + `--config` CLI flag on `CameraShieldConfig.
      from_args()`. Precedence: explicit CLI flag > config file > default.
      Unknown keys in a config file are a hard error, not a silent skip.
      18 new tests. Examples: `docs/config_example.json`,
      `docs/config_example.yaml`. See ARCHITECTURE.md for the merge-order
      design rationale.
- [x] **Camera Finding emission** (`camera/shield.py`): `CameraShield.
      get_findings()` now returns real `Finding`s -- HIGH when more faces
      are in frame than `max_faces` covers (previously silently
      unprotected), MEDIUM when a face's box degenerates to zero area and
      gets skipped (previously also silent). `camera/` is now the second
      real `Finding` producer alongside `file_privacy/`, proving out
      `privacy_engine`'s module-agnostic aggregator design against more
      than one module for the first time. 6 new tests (fake mediapipe-
      shaped mesh, no real camera/model needed). **Not done as part of
      this**: wiring these into `privacy_engine/cli.py`'s `report` command
      -- that command is file/directory-path based and has no live-feed
      concept yet; see "Next" below.
- [x] Verified this session: reinstalled the exact pinned dependency set
      (`opencv-python<4.12`, `numpy<2.0`, `mediapipe==0.10.21`) in this
      sandbox and confirmed `mediapipe.solutions` is only present with
      that pin -- the sandbox's previously-installed mediapipe (0.10.33)
      genuinely lacks it, matching the tech debt already documented below
      and in DEPENDENCY_REPORT.md. Full suite (82 tests: 58 pre-existing +
      24 new) passes against the pinned set.

## Done (v0.6)

- [x] Fixed the numpy/opencv-python/mediapipe pin conflict found during
      v0.5: capped `opencv-python>=4.9,<4.12` (was `<5`) so it stays on
      the numpy<2 side of opencv-python's 4.12.0.88 bump to `numpy>=2`.
      Verified with a completely fresh venv install (zero pre-existing
      packages): zero resolver conflicts, `pip check` clean, real
      mediapipe FaceMesh smoke test passed, full 58-test suite passed.
      See DEPENDENCY_REPORT.md for the full verification trail.

## Done (v0.5)

- [x] **Deployment-mode config switch** (`config/settings.py`,
      `camera/shield.py`, `camera/stream_server.py`): `--mode desktop`
      (unchanged behavior: local webcam, preview window, virtual camera)
      vs. `--mode headless` (for a homelab/server box: no display touched,
      accepts a device index *or* an RTSP/HTTP network camera URL via
      `--source`, serves anonymized output as an MJPEG HTTP stream instead
      of a virtual webcam). Every output (preview/vcam/stream) can still be
      forced on/off explicitly regardless of mode. 13 new tests (8 config,
      5 stream server against a real loopback HTTP server).
- [x] Found (fixed in v0.6, see above): `requirements.txt` pinned
      `numpy>=1.26,<2.0`, but current `opencv-python`/`opencv-python-headless`
      releases require `numpy>=2` — a real 3-way resolver conflict with the
      `mediapipe==0.10.21` pin (which itself wants numpy<2). See
      DEPENDENCY_REPORT.md.

## Now (v0.2 stabilization)

- [ ] Validate `CameraShield.run()` on real webcam hardware, all three OSes
      if possible. This sandbox has no camera device, so the live loop is
      untested end-to-end — see PROJECT_STATE.md for exactly what *was*
      verified.
- [ ] Validate `--mode headless` against a **real** RTSP/IP camera and a
      real homelab box (this session only verified the code paths and
      error handling — no physical network camera was available to test
      against; see PROJECT_STATE.md).
- [ ] Resolve the mediapipe `solutions` API deprecation properly instead of
      just pinning to 0.10.21 indefinitely. Options:
      1. Stay pinned, accept the tech debt, revisit when it becomes a real
         install problem (e.g. Python version incompatibility).
      2. Migrate to `mediapipe.tasks.vision.FaceLandmarker` (the replacement
         API). This is a real rewrite of `camera/shield.py`'s model-loading
         and result-parsing code, not a drop-in swap — the Tasks API result
         objects have a different shape than `solutions` results.
      Decision owner: project owner, not to be silently chosen by whoever
      picks up this ticket.

## Done (v0.3)

- [x] **`file_privacy/`**: metadata scanner + remover for JPEG/TIFF (EXIF +
      GPS), PDF (Info dict), DOCX (core.xml). CLI + Python API. 13 tests
      against real synthetic files.
- [x] Shared "privacy finding" data structure (`core/findings.py`,
      `Finding`/`Severity`) — `file_privacy` is the first real producer.

## Done (v0.4)

- [x] Expanded `file_privacy` format coverage: PNG (text chunks + eXIf
      chunk), DOCX `docProps/app.xml` (Company/Manager — these were missed
      entirely by v0.3's core.xml-only reader). 10 new tests.
- [x] **`privacy_engine/`**: real aggregator/reporter. `build_report()`
      turns a `Finding` list into a scored, explained `PrivacyReport`; CLI
      (`python -m privacy_engine.cli report <path>`) wires it to
      `file_privacy`'s scanner. 11 new tests. Verified end-to-end against a
      real demo directory (GPS-tagged JPEG + metadata PNG + clean PNG) —
      correct HIGH/MEDIUM/LOW findings, correct aggregate score, clean file
      correctly produced zero findings.

## Next

- [ ] Test `file_privacy` against real-world files (actual phone camera
      output, actual Word/Acrobat-generated documents), not just the
      synthetic fixtures used so far — real tools may set fields the
      current `NOTABLE_*` lists don't know about yet.
- [ ] HEIC support for `file_privacy` — the default iPhone photo format,
      still unsupported. Needs an extra dependency (e.g. `pillow-heif`)
      since stock Pillow doesn't decode HEIC; evaluate before adding.
- [ ] Legacy `.doc`/`.xls`/`.ppt` support (pre-XML Office binary formats) —
      lower priority than HEIC, these are increasingly rare in the wild.
- [ ] Recalibrate `privacy_engine`'s `SEVERITY_WEIGHT`/`RISK_THRESHOLDS`
      once there's real usage to check them against — currently a
      reasonable-sounding guess (documented as such in `report.py`).
- [x] ~~Give `camera/` a way to emit `Finding`s~~ — done in v0.7, see above.
      Follow-up now that this exists: design and wire a live/streaming
      report mode into `privacy_engine` (`cli.py`'s `report` command is
      file/directory-path based today and has no live-feed concept) so
      camera `Finding`s actually reach a `PrivacyReport`, not just
      `CameraShield.get_findings()`. Needs its own design pass — sampling
      window, how long to watch before reporting, whether it runs
      alongside `camera/`'s normal loop or as a separate short-lived scan
      — not a "few lines in `_collect_findings()`" change like adding a
      second file format was.

## Later

- [ ] `identity_audit/`: username exposure / local metadata analysis.
      Ethical scope note: self-auditing only, no scraping of other people's
      accounts or data — this needs an explicit design pass on what
      "authorized self-auditing" means technically before writing code.
      Concretely, in-scope: checking the user's *own* email/username
      against public breach-notification APIs (e.g. HaveIBeenPwned, which
      is designed for exactly this), scanning the user's *own* local
      files/accounts for exposure. Out of scope, and declined once already
      (see PROJECT_STATE.md v0.3 note): generic recon tooling aimed at
      arbitrary targets — WHOIS/subdomain-enum/port-scan/Google-dork style
      tools — even if a convenient package happens to bundle them.
- [ ] `network/`: VPN/DNS/public-IP *awareness* only — explicitly no
      offensive networking, no packet capture beyond what's needed to show
      the user their own exposure.
- [ ] `audio/`: mic monitoring, speech activity detection, optional voice
      anonymization.
- [ ] Camera Shield extensions: OCR-based readable-text detection,
      background privacy, QR/barcode detection, license plate detection —
      these plug into `privacy_engine/`'s `Finding` model (now real, see
      v0.4) rather than being camera-only pixel effects.

## Much later

- [ ] `dashboard/` (PyQt6): live preview, module status, privacy score,
      settings, logs. Deferred until there's more than one module worth
      dashboarding — building a UI shell around a single camera toggle
      isn't a good use of the first dashboard milestone.
- [ ] `plugins/`: enable/disable, versioning, dependency checking for
      third-party modules. Needs at least 2-3 first-party modules to exist
      first so the plugin interface is designed against real examples, not
      guessed at.
- [ ] GPU acceleration / performance pass across all modules once there's
      enough of the suite built to know where the actual bottlenecks are.

## Explicitly out of scope

- Anything that claims "perfect anonymity" — the privacy engine's job is to
  explain residual risk, not promise zero risk.
- Any network functionality beyond passive awareness of the user's own
  connection (no scanning others, no offensive tooling).
- Cloud processing of any kind for the core privacy features.
