"""Tests for config/settings.py's config-file loader (JSON/YAML) and its
merge precedence with CLI flags and mode defaults."""

from __future__ import annotations

import json

import pytest

from config.settings import (
    CameraShieldConfig,
    ConfigFileError,
    DeploymentMode,
    load_config_file,
)


def write_json(tmp_path, data, name="config.json"):
    p = tmp_path / name
    p.write_text(json.dumps(data))
    return p


def write_yaml(tmp_path, text, name="config.yaml"):
    p = tmp_path / name
    p.write_text(text)
    return p


# -- load_config_file() --------------------------------------------------

def test_load_json_config(tmp_path):
    p = write_json(tmp_path, {"block_size": 20, "max_faces": 2})
    data = load_config_file(p)
    assert data == {"block_size": 20, "max_faces": 2}


def test_load_yaml_config(tmp_path):
    p = write_yaml(tmp_path, "block_size: 20\nmax_faces: 2\n")
    data = load_config_file(p)
    assert data == {"block_size": 20, "max_faces": 2}


def test_missing_file_raises(tmp_path):
    with pytest.raises(ConfigFileError, match="not found"):
        load_config_file(tmp_path / "nope.json")


def test_unknown_extension_raises(tmp_path):
    p = tmp_path / "config.txt"
    p.write_text("block_size: 20")
    with pytest.raises(ConfigFileError, match="Unrecognized config file extension"):
        load_config_file(p)


def test_malformed_json_raises(tmp_path):
    p = tmp_path / "config.json"
    p.write_text("{not valid json")
    with pytest.raises(ConfigFileError, match="Malformed JSON"):
        load_config_file(p)


def test_unknown_key_raises(tmp_path):
    p = write_json(tmp_path, {"block_size": 20, "not_a_real_field": 1})
    with pytest.raises(ConfigFileError, match="Unknown config key"):
        load_config_file(p)


def test_non_mapping_top_level_raises(tmp_path):
    p = write_json(tmp_path, [1, 2, 3])
    with pytest.raises(ConfigFileError, match="top-level mapping"):
        load_config_file(p)


def test_empty_yaml_is_empty_dict(tmp_path):
    p = write_yaml(tmp_path, "")
    assert load_config_file(p) == {}


# -- CameraShieldConfig.from_args() merge precedence ----------------------

def test_config_file_alone_supplies_values(tmp_path):
    p = write_json(tmp_path, {"block_size": 22, "warp_strength": 55, "max_faces": 7})
    config = CameraShieldConfig.from_args(["--config", str(p)])
    assert config.block_size == 22
    assert config.warp_strength == 55
    assert config.max_faces == 7
    # Anything not in the file falls back to the ordinary default.
    assert config.pad_fraction == 0.35


def test_cli_flag_overrides_config_file(tmp_path):
    p = write_json(tmp_path, {"block_size": 22})
    config = CameraShieldConfig.from_args(["--config", str(p), "--block", "9"])
    assert config.block_size == 9


def test_config_file_sets_deployment_mode(tmp_path):
    p = write_json(tmp_path, {"deployment_mode": "headless"})
    config = CameraShieldConfig.from_args(["--config", str(p)])
    assert config.deployment_mode == DeploymentMode.HEADLESS
    # Headless mode defaults still apply since the file didn't override them.
    assert config.show_preview is False
    assert config.http_stream is True


def test_cli_mode_overrides_config_file_mode(tmp_path):
    p = write_json(tmp_path, {"deployment_mode": "headless"})
    config = CameraShieldConfig.from_args(["--config", str(p), "--mode", "desktop"])
    assert config.deployment_mode == DeploymentMode.DESKTOP


def test_config_file_source_as_int(tmp_path):
    p = write_json(tmp_path, {"source": 2})
    config = CameraShieldConfig.from_args(["--config", str(p)])
    assert config.source == 2


def test_config_file_source_as_url_string(tmp_path):
    p = write_json(tmp_path, {"source": "rtsp://cam.local/stream"})
    config = CameraShieldConfig.from_args(["--config", str(p)])
    assert config.source == "rtsp://cam.local/stream"


def test_config_file_only_fields_no_cli_flag(tmp_path):
    p = write_json(tmp_path, {
        "blur_ksize": 51,
        "smoothing_alpha": 0.8,
        "min_detection_confidence": 0.7,
        "min_tracking_confidence": 0.6,
    })
    config = CameraShieldConfig.from_args(["--config", str(p)])
    assert config.blur_ksize == 51
    assert config.smoothing_alpha == 0.8
    assert config.min_detection_confidence == 0.7
    assert config.min_tracking_confidence == 0.6


def test_config_file_boolean_override(tmp_path):
    p = write_json(tmp_path, {"show_preview": False, "http_stream": True})
    config = CameraShieldConfig.from_args(["--config", str(p)])
    assert config.show_preview is False
    assert config.http_stream is True


def test_cli_boolean_flag_overrides_config_file_boolean(tmp_path):
    p = write_json(tmp_path, {"show_preview": False})
    config = CameraShieldConfig.from_args(["--config", str(p), "--preview"])
    assert config.show_preview is True


def test_no_config_flag_behaves_as_before():
    config = CameraShieldConfig.from_args(["--mode", "desktop"])
    assert config.deployment_mode == DeploymentMode.DESKTOP
    assert config.block_size == 14
    assert config.source == 0
