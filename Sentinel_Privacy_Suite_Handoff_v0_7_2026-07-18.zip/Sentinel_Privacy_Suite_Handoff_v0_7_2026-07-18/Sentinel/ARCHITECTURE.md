# ARCHITECTURE.md

## Guiding constraints

- **Local-only.** No module should make an outbound network call with user
  data (camera frames, audio, files, metadata). `network/` is explicitly
  scoped as *monitoring-only* (VPN/DNS/IP visibility awareness), never as an
  offensive or data-exfiltrating capability.
- **Modular over monolithic.** Each capability (camera, audio, file privacy,
  identity audit, network awareness) is its own top-level package with a
  narrow public interface, so it can be developed, tested, versioned, and
  toggled independently — this is also what the `plugins/` system will need
  to enable/disable modules at runtime later.
- **Pure functions where possible.** Image/pixel transforms
  (`camera/distortions.py`) and geometry helpers (`camera/tracking.py`) take
  plain arrays/tuples in, return plain arrays/tuples out, with no I/O or
  global state. That's what makes them unit-testable without a webcam —
  the entire `tests/` suite runs without camera hardware.
- **I/O isolated at the edges.** Anything that touches a camera, a virtual
  cam device, a file on disk, or the network lives in one class per module
  (`CameraShield` today) that orchestrates the pure functions. This is the
  seam the dashboard will eventually hook into instead of the OpenCV preview
  window.

## Current module: `camera/`

```
camera/
├── distortions.py   pixelate, block_shuffle, landmark_warp, feather_mask,
│                    scramble_region (mode dispatch)
├── tracking.py       SmoothedBox (jitter reduction), get_box_from_landmarks
└── shield.py          CameraShield: owns cv2.VideoCapture, mediapipe FaceMesh,
                        pyvirtualcam.Camera, the render loop, and keyboard input
```

**Why split distortions from tracking from orchestration:** the original
single-file script mixed all three concerns, which made the "warp mode uses
face landmarks" claim in its own docstring silently false — nothing forced
the warp function to actually receive landmarks, and there was no test that
would have caught it. Separating "given these pixels and these landmark
points, produce distorted pixels" (testable, no I/O) from "read a camera,
find landmarks, call the distortion, show/send the result" (I/O, needs
hardware) makes that class of bug visible in a unit test instead of only in
a demo.

**Why `CameraShield` is still one class:** at this size (one video pipeline,
one output sink, one input device) an orchestrator class is simpler than
premature interfaces. The point where it should be split is when the
dashboard needs to drive frames through the same pipeline without an OpenCV
window and keyboard polling — at that point `process_frame()` (already a
standalone method taking a frame in, returning a frame out) becomes the
seam, and the `run()` loop's OpenCV-specific I/O gets extracted into a
`CameraShieldCliRunner` or similar, leaving `CameraShield` itself
UI-agnostic. Not done yet because there's no dashboard consuming it yet —
building that abstraction before it has a second caller would be
speculative.

## Face box smoothing

`SmoothedBox` uses exponential smoothing (`box = alpha * new + (1-alpha) *
old`) rather than a fixed-window moving average, because it needs O(1)
memory per tracked face and reacts smoothly to fast head movement without
a lag spike from a full window refill. `alpha=0.5` is a starting point, not
a tuned constant. As of v0.7 it (and every other `CameraShieldConfig`
field) can be adjusted via a config file without a code change -- see
"Current module: `config/settings.py` config-file loader" below -- but the
*value* itself is still an untuned guess, unrelated to whether it's easy to
change.

## Landmark-driven warp

`landmark_warp()` picks a small fixed set of semantically meaningful
landmarks (eye corners, nose tip, mouth corners, chin, forehead) rather than
all 468 mesh points, and builds a smooth displacement field by Gaussian-
weighting each anchor's random push vector by distance. Fewer anchors keeps
the per-frame cost low (no per-point remap, just one field composed from
~9 points) while still producing organic, face-shaped distortion instead of
the original's spatially-uniform random grid.

## Why mediapipe FaceMesh instead of separate face-detection + landmark
models

The original script used `mp.solutions.face_detection.FaceDetection` for
box-only detection and a separate `mp.solutions.face_mesh.FaceMesh` for
warp mode's landmarks — two different models loaded depending on mode. This
version uses `FaceMesh` unconditionally, deriving the bounding box *from*
the landmarks (`get_box_from_landmarks`) instead of from a separate
detector. Trade-off: `FaceMesh` is somewhat heavier per-frame than the
lightweight detector, but it removes the need to load/switch between two
models mid-stream, and gives every mode (not just warp) access to landmark
data if a future feature needs it (e.g. eye/mouth-region-only redaction).
If profiling on target hardware shows this is too slow for `light` mode on
low-end machines, reintroducing the cheaper detector for that mode
specifically is a reasonable follow-up — flagged in `ROADMAP.md`.

## Current module: `core/findings.py`

`Finding` and `Severity` (see docstring in that file) are the shared
vocabulary every detection module speaks. This was scaffolded as a "needs
to exist before `privacy_engine/` can be built for real" prerequisite in
v0.2's roadmap, and `file_privacy` is the first module to actually produce
instances of it. Deliberately minimal: category tag, human title/
description/remediation strings, a severity enum, which module produced it,
and an optional location + free-form `extra` dict for module-specific
details a future report renderer might want. `privacy_engine/` (not yet
built) is expected to import `Finding` from `core`, never the other way
around — modules stay ignorant of how their findings get aggregated.

## Current module: `file_privacy/`

```
file_privacy/
├── formats/
│   ├── images.py   EXIF read/strip (JPEG/TIFF), GPS decoding, PNG text-chunk
│   │                and eXIf-chunk read/strip (v0.4)
│   ├── pdf.py       PDF Info-dict read/strip
│   └── docx.py      DOCX core.xml AND app.xml read/strip (v0.4 added
│                     app.xml -- Company/Manager live there, not core.xml;
│                     stdlib zipfile+ElementTree only)
├── scanner.py        format detection + scan_file/scan_directory -> list[Finding]
├── remover.py         remove_metadata() dispatch by format
└── cli.py              `python -m file_privacy.cli scan|clean`
```

**Why format handlers are split from the scanner:** same rationale as
`camera/distortions.py` vs `camera/shield.py` — `formats/images.py`'s
`read_exif()`/`strip_exif()` take a path, return data/write a file, with no
knowledge of `Finding` or severity. `scanner.py` is the only place that
decides "GPS coordinates = HIGH severity." That split means adding a new
format (HEIC, legacy Office) only touches `formats/`, and adding a new
*policy* about what counts as high severity only touches `scanner.py` — a
`formats/*.py` change can't accidentally change severity scoring and vice
versa. This paid off concretely in v0.4: adding PNG and DOCX app.xml
support touched only `formats/images.py` and `formats/docx.py` plus a
small dispatch addition in `scanner.py`/`remover.py` — no severity logic
had to be re-derived.

**Why DOCX uses stdlib `zipfile`/`xml.etree` instead of `python-docx`:** the
only thing needed is reading/clearing a handful of fields in
`docProps/core.xml`. `python-docx` pulls in `lxml` and a much larger API
surface for that. A `.docx` is just a zip of XML parts, so stdlib is
sufficient and keeps the dependency footprint smaller — consistent with the
"avoid unnecessary dependencies" project principle.

**Why `remove_metadata()` never modifies files in place:** a privacy tool
that silently overwrites the user's only copy of a photo or document — with
no undo — is a bad failure mode even if the stripping logic is correct.
Every remover takes a separate output path; verified by a test that checks
the source file's bytes are byte-for-byte unchanged after cleaning.

**A real bug this surfaced, worth keeping in mind for future modules:**
`pypdf.PdfWriter` re-stamps `"/Producer": "pypdf"` on every `write()`
regardless of what's passed to `add_metadata()`, unless you explicitly
overwrite that key too. This was only caught because the round-trip test
asserted the *exact* post-strip metadata dict rather than just "author is
gone" — a lesson for how thorough these round-trip tests need to be as more
formats get added: assert on the full state, not just the field you were
thinking about when you wrote the test.

## Current module: `privacy_engine/`

```
privacy_engine/
├── report.py   build_report(findings) -> PrivacyReport (score, risk_label,
│               explanation, grouped by module/severity); pure function of
│               a Finding list, no I/O
└── cli.py       `python -m privacy_engine.cli report <path> [--json]`,
                  wires file_privacy's scanner into build_report()
```

**Why `build_report()` takes a flat `Finding` list instead of importing
`file_privacy` directly:** this is the design ARCHITECTURE.md's original
draft asked for -- `privacy_engine` should aggregate across modules without
being coupled to any one module's internals. `report.py` has zero imports
from `file_privacy`, `camera`, or any other detection module; only `cli.py`
(the I/O-touching orchestration layer, same pattern as `camera/shield.py`
and `file_privacy/cli.py`) knows that `file_privacy.scanner` is the current
source of findings. When `camera/` or another module starts producing
`Finding`s, wiring them in means adding a few lines to `cli.py`'s
`_collect_findings()` -- `report.py` doesn't change at all. This was a
real design decision, not just documentation after the fact: `report.py`
was written and fully tested (11 tests) against hand-built `Finding`
objects before `cli.py` touched `file_privacy` at all.

**Why the score is a simple weighted sum instead of something fancier:**
the project spec's example report format prioritizes an *explainable*
score over a precise one ("The system should explain what was detected,
why it matters, how to reduce exposure" — not "the system should have the
most accurate possible score"). A weighted sum where every point traces
back to one specific finding is trivially explainable; a learned or
compound-interaction model would need its own justification layer on top
just to answer "why is my score 47." If real-world usage shows the simple
sum is miscalibrated (flagged as a known limitation in PROJECT_STATE.md and
ROADMAP.md), the fix is retuning `SEVERITY_WEIGHT`/`RISK_THRESHOLDS`, not
necessarily abandoning the explainable-sum approach.

## Planned modules (not yet implemented)

See `ROADMAP.md` for sequencing. Architecturally, each planned module is
expected to follow the same split as `camera/` and `file_privacy/`: pure
analysis/transform functions in one file (testable without
hardware/filesystem), I/O orchestration in another, and detected exposures
represented as `core.findings.Finding` objects so they plug into
`privacy_engine.report.build_report()` with no changes to that function —
`report.py` genuinely doesn't import `camera`, `audio`, `identity_audit`,
or `network`, and shouldn't start to.

## Current module: `config/settings.py` config-file loader (v0.7)

`load_config_file()` reads a JSON or YAML file into a plain `dict` of
`CameraShieldConfig` field overrides; `CameraShieldConfig.from_args()`
merges it with CLI flags via one rule applied uniformly to every field:
**explicit CLI flag > config file value > hard default.** This is the same
tri-state (`None` = "not set here") pattern the desktop/headless mode
defaults already used for `--preview`/`--vcam`/`--stream`, just extended to
every other field instead of invented fresh.

**Why JSON always works but YAML is optional:** JSON parsing is stdlib
(`json`), so a `.json` config file has zero new dependencies. YAML needs
PyYAML, which is *not* in `requirements.txt`'s hard dependency list —
consistent with the project's "evaluate before adding a dependency"
practice (see the HEIC/`pillow-heif` note in `ROADMAP.md`). `import yaml`
is wrapped in a `try/except ImportError` at module load, so the whole
`config/settings.py` module still imports fine without PyYAML installed;
only actually pointing `--config` at a `.yaml`/`.yml` file without PyYAML
raises a clear `ConfigFileError` telling you to install it or use JSON.

**Why unknown keys are a hard error, not a warning or silent skip:** a
config file is written once and often not looked at again for months (the
homelab-deployment use case this was built for, per `ROADMAP.md`). A
typo'd key (`"blur_ksze": 40`) that's silently ignored means the operator
believes a setting is applied when it isn't, discovered only much later if
at all. Failing loudly at startup costs one extra look at an error message
in exchange for never silently running with the wrong config.

**Why `--config` doesn't shadow the mode-based preview/vcam/stream
defaults:** those defaults are computed from the *final, merged*
`deployment_mode` (CLI, then config file, then `"desktop"`), not from the
raw CLI value — so a config file that sets `deployment_mode: headless`
gets the headless output defaults (no preview/vcam, stream on) exactly as
if `--mode headless` had been passed on the command line, and an explicit
`show_preview`/`use_virtual_cam`/`http_stream` key in the same file (or an
explicit CLI flag) still overrides that default, same as today.

## Current module: camera-produced `Finding`s (v0.7)

`CameraShield.process_frame()` now populates `self.last_findings` (exposed
via `get_findings()`) every frame, making `camera/` the second real
`Finding` producer alongside `file_privacy/` — proving the
"`privacy_engine` doesn't need to know which module a `Finding` came from"
design against more than one module for the first time (see the
`privacy_engine/` section above).

Two conditions are detected, both representing "a face is visible in frame
right now but isn't actually being anonymized":

- **More faces detected than `max_faces` allows** (HIGH): `process_frame`
  already only scrambles `results.multi_face_landmarks[:max_faces]` —
  anyone past that slice was, before v0.7, silently left unprotected with
  no signal that this had happened. This is arguably the more important of
  the two: it's a real, current gap in what the tool advertises it does
  (see `ROADMAP.md`'s "explicitly out of scope" note about never claiming
  perfect protection — this Finding is what makes the actual, current limit
  visible instead of implicit).
- **A face's smoothed bounding box collapses to zero area** (MEDIUM,
  typically at the extreme edge of frame): also already silently skipped
  before v0.7 (`if x2 <= x1 or y2 <= y1: continue`); now it's a visible,
  explained gap instead of a silent one.

**Why `last_findings` resets every frame instead of accumulating:** a
video feed's exposure is a *current-moment* fact ("is anyone unprotected
right now"), not a historical log the way a scanned file's metadata is.
`file_privacy`'s findings describe a static artifact; camera's describe a
live, constantly-changing state. Accumulating them across frames would
make "3 faces over the limit, once, five minutes ago" look identical to
"3 faces over the limit, continuously, right now" — the wrong shape of
information for a live feed. Anything that wants a history (e.g. a future
dashboard's "you were unprotected for 4 minutes at 2pm" log) should sample
`get_findings()` per frame and build its own timeline on top, rather than
`CameraShield` doing that aggregation itself.

**Not yet done, deliberately:** `privacy_engine/cli.py`'s `report <path>`
command is file/directory-path based and has no notion of a live camera
feed — wiring camera `Finding`s into it isn't "add a few lines" the way
adding a second *file* format was, it needs an actual live/streaming
report mode (e.g. "sample N seconds of camera Finding output and report
on it") designed on its own terms, not bolted onto the existing path-based
`report` command. That design pass is listed as a next step in
`ROADMAP.md`, not attempted here.
