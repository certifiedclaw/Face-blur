"""Camera Shield: real-time face anonymization pipeline.

Modes (SPACE to cycle, desktop mode only):
  light : pixelation + randomized block shuffle over the detected face box.
          Cheap, good for video calls.
  warp  : landmark-driven nonlinear warp (eyes/nose/mouth pulled/pushed)
          + pixelation + shuffle. Heavier, more organic distortion.
  blur  : plain gaussian blur. Cheapest fallback for low-power machines.

Deployment modes (config.deployment_mode, see config/settings.py):
  desktop  : local USB webcam, on-screen preview window, output to a
             virtual camera via pyvirtualcam (select it as your webcam in
             Zoom/Meet/Discord/etc). Falls back to preview-only if no
             virtual camera driver is available.
  headless : for a homelab/server box with no display attached. Never
             touches cv2.imshow/waitKey. Reads from a local device index
             or a network camera URL (RTSP/HTTP), and serves the already-
             anonymized output as an MJPEG stream over HTTP instead (see
             camera/stream_server.py) -- "virtual webcam" isn't meaningful
             on a machine nobody is video-calling from.
"""

from __future__ import annotations

import logging
import time

import cv2
import mediapipe as mp
import numpy as np

from camera.distortions import scramble_region, WARP_ANCHOR_LANDMARKS, feather_mask
from camera.tracking import SmoothedBox, get_box_from_landmarks
from config.settings import CameraShieldConfig, DeploymentMode
from core.findings import Finding, Severity

logger = logging.getLogger(__name__)

mp_face_mesh = mp.solutions.face_mesh

MODE_CYCLE = ["light", "warp", "blur"]


class CameraShield:
    """Owns the camera loop, mediapipe model, and output (preview/vcam/HTTP)."""

    def __init__(self, config: CameraShieldConfig | None = None):
        self.config = config or CameraShieldConfig()
        self.mode_idx = 0
        self.block_size = self.config.block_size
        self.blur_ksize = self.config.blur_ksize
        self.warp_strength = self.config.warp_strength
        self.show_fps = True
        self.rng = np.random.default_rng()
        self.smoothers: dict[int, SmoothedBox] = {}
        self._vcam = None
        self._cap = None
        self._stream_server = None
        # Findings produced by the most recent process_frame() call -- see
        # get_findings(). Reset (not accumulated) every frame: this reflects
        # "what's true right now," not a running log, since a video feed's
        # privacy exposure is a per-moment thing, not a per-file one.
        self.last_findings: list[Finding] = []

    @property
    def mode(self) -> str:
        return MODE_CYCLE[self.mode_idx]

    def get_findings(self) -> list[Finding]:
        """Findings from the most recent process_frame() call, for feeding
        into privacy_engine.build_report() alongside file_privacy's findings.
        See ROADMAP.md 'Next' -- camera is the second real Finding producer,
        proving the aggregator design against more than one module."""
        return list(self.last_findings)

    def _open_camera(self) -> tuple[cv2.VideoCapture, int, int]:
        source = self.config.source
        cap = cv2.VideoCapture(source)
        if not cap.isOpened():
            raise RuntimeError(
                f"Could not open camera source {source!r}. "
                "For a local/USB webcam, pass a device index (--source 0). "
                "For a network/IP camera (homelab setups), pass the stream "
                "URL (--source rtsp://user:pass@host/stream)."
            )
        w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)) or 1280
        h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT)) or 720
        return cap, w, h

    def process_frame(self, frame: np.ndarray, mesh, frame_w: int, frame_h: int) -> np.ndarray:
        """Run detection + scrambling on a single BGR frame. Pure function of
        (frame, model state) aside from self.smoothers/rng, so it's the
        easiest entry point to unit test with a canned frame."""
        findings: list[Finding] = []
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = mesh.process(rgb)

        if not results.multi_face_landmarks:
            self.smoothers.clear()
            self.last_findings = findings
            return frame

        total_faces = len(results.multi_face_landmarks)
        if total_faces > self.config.max_faces:
            unprotected = total_faces - self.config.max_faces
            findings.append(
                Finding(
                    category="unprotected_face",
                    title="Face(s) detected but not anonymized",
                    description=(
                        f"{unprotected} face(s) beyond the configured max_faces "
                        f"limit ({self.config.max_faces}) were detected in frame "
                        "but are not being scrambled -- anyone else in view past "
                        "that limit is shown unprotected."
                    ),
                    remediation=(
                        "Raise --max-faces (or the max_faces config value) to "
                        "cover everyone who may appear in frame."
                    ),
                    severity=Severity.HIGH,
                    source_module="camera",
                    location=None,
                    extra={"detected_faces": total_faces, "max_faces": self.config.max_faces},
                )
            )

        for i, face_landmarks in enumerate(results.multi_face_landmarks[: self.config.max_faces]):
            landmarks_px = [(int(p.x * frame_w), int(p.y * frame_h)) for p in face_landmarks.landmark]
            raw_box = get_box_from_landmarks(landmarks_px, frame_w, frame_h, self.config.pad_fraction)

            smoother = self.smoothers.setdefault(i, SmoothedBox(alpha=self.config.smoothing_alpha))
            x1, y1, x2, y2 = smoother.update(raw_box)
            if x2 <= x1 or y2 <= y1:
                findings.append(
                    Finding(
                        category="unprotected_face",
                        title="Face detected but skipped (degenerate box)",
                        description=(
                            "A face was detected but its bounding box collapsed "
                            "to zero area this frame (typically at the extreme "
                            "edge of the frame) and was left unscrambled."
                        ),
                        remediation=(
                            "Reposition so faces stay fully inside the frame, "
                            "or increase --pad."
                        ),
                        severity=Severity.MEDIUM,
                        source_module="camera",
                        location=None,
                        extra={"face_slot": i},
                    )
                )
                continue

            region = frame[y1:y2, x1:x2].copy()

            anchors_local = None
            if self.mode == "warp":
                anchors_local = [
                    (landmarks_px[idx][0] - x1, landmarks_px[idx][1] - y1)
                    for idx in WARP_ANCHOR_LANDMARKS
                    if 0 <= landmarks_px[idx][0] - x1 < (x2 - x1)
                    and 0 <= landmarks_px[idx][1] - y1 < (y2 - y1)
                ]

            scrambled = scramble_region(
                region, self.mode, self.block_size, self.blur_ksize, self.warp_strength,
                self.rng, landmarks_local=anchors_local,
            )

            mask = feather_mask(x2 - x1, y2 - y1, self.config.feather_px)[..., None]
            blended = (
                scrambled.astype(np.float32) * mask + region.astype(np.float32) * (1 - mask)
            ).astype(np.uint8)
            frame[y1:y2, x1:x2] = blended

        self.last_findings = findings
        return frame

    def _handle_key(self, key: int) -> bool:
        """Returns False if the app should quit. Only called in desktop
        mode -- headless has no keyboard/window to read from."""
        if key == ord("q"):
            return False
        elif key == ord(" "):
            self.mode_idx = (self.mode_idx + 1) % len(MODE_CYCLE)
        elif key == ord("f"):
            self.show_fps = not self.show_fps
        elif key in (ord("="), ord("+")):
            self.block_size = max(4, self.block_size - 2)
            self.blur_ksize = max(5, self.blur_ksize - 4)
        elif key == ord("-"):
            self.block_size = min(60, self.block_size + 2)
            self.blur_ksize = min(99, self.blur_ksize + 4)
        elif key == ord("]"):
            self.warp_strength = min(150, self.warp_strength + 5)
        elif key == ord("["):
            self.warp_strength = max(0, self.warp_strength - 5)
        return True

    def run(self) -> None:
        is_desktop = self.config.deployment_mode == DeploymentMode.DESKTOP
        cap, w, h = self._open_camera()
        self._cap = cap

        vcam = None
        if self.config.use_virtual_cam:
            try:
                import pyvirtualcam

                vcam = pyvirtualcam.Camera(width=w, height=h, fps=30)
                logger.info("Virtual camera started: %s", vcam.device)
            except Exception as e:  # pragma: no cover - depends on host OS/drivers
                logger.warning("No virtual camera available (%s); continuing without it.", e)
        self._vcam = vcam

        frame_buffer = None
        if self.config.http_stream:
            from camera.stream_server import FrameBuffer, MjpegStreamServer

            frame_buffer = FrameBuffer()
            self._stream_server = MjpegStreamServer(
                frame_buffer,
                host=self.config.http_host,
                port=self.config.http_port,
                jpeg_quality=self.config.http_jpeg_quality,
            )
            self._stream_server.start()

        show_preview = is_desktop and self.config.show_preview

        prev_t = time.time()
        fps = 0.0

        with mp_face_mesh.FaceMesh(
            max_num_faces=self.config.max_faces,
            refine_landmarks=False,
            min_detection_confidence=self.config.min_detection_confidence,
            min_tracking_confidence=self.config.min_tracking_confidence,
        ) as mesh:
            try:
                while True:
                    ok, frame = cap.read()
                    if not ok:
                        logger.warning("Lost camera feed, retrying...")
                        time.sleep(0.5)
                        cap.release()
                        cap, w, h = self._open_camera()
                        continue

                    if is_desktop:
                        # Mirror for a natural "looking in a mirror" self-view.
                        # Wrong for a fixed IP/homelab camera -- you want its
                        # actual orientation, not a mirrored one.
                        frame = cv2.flip(frame, 1)
                    frame = self.process_frame(frame, mesh, w, h)

                    now = time.time()
                    inst_fps = 1.0 / max(1e-6, now - prev_t)
                    fps = fps * 0.9 + inst_fps * 0.1
                    prev_t = now

                    if show_preview:
                        label = (
                            f"mode: {self.mode}  block: {self.block_size}  warp: {self.warp_strength}  "
                            "(space=mode +/-=intensity [/ ]=warp f=fps q=quit)"
                        )
                        cv2.putText(frame, label, (10, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1, cv2.LINE_AA)
                        if self.show_fps:
                            cv2.putText(frame, f"{fps:0.1f} fps", (10, 50), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 255, 0), 1, cv2.LINE_AA)

                    if vcam is not None:
                        vcam.send(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
                        vcam.sleep_until_next_frame()

                    if frame_buffer is not None:
                        frame_buffer.update(frame)

                    if show_preview:
                        cv2.imshow("preview (local only, not sent to call)", frame)
                        key = cv2.waitKey(1) & 0xFF
                        if not self._handle_key(key):
                            break
                    elif not is_desktop:
                        # Headless has no keyboard/window to poll -- yield the
                        # CPU briefly between frames instead of busy-looping,
                        # and rely on Ctrl+C / process manager for shutdown.
                        time.sleep(0.001)
            except KeyboardInterrupt:
                logger.info("Shutting down (interrupted).")
            finally:
                cap.release()
                if show_preview:
                    cv2.destroyAllWindows()
                if vcam is not None:
                    vcam.close()
                if self._stream_server is not None:
                    self._stream_server.stop()
