# PROJECT_STATE.md

_Last updated: 2026-07-18, v0.7.1 handoff._

## v0.7.1 session summary

Added `install.bat`/`run.bat`/`uninstall.bat` for a one-click Windows
install/run/remove flow, all scoped to a `.venv` folder in the project
directory (see CHANGELOG.md v0.7.1). **Not verified on an actual Windows
machine** — this sandbox is Linux, so these scripts have only been traced
by hand, not run. Test on real Windows before treating them as reliable.

## v0.7 session summary

Picked up two items from ROADMAP.md that don't require physical camera
hardware (which this sandbox still doesn't have):

1. **Config file loader** for `CameraShieldConfig` (JSON always works;
   YAML only if PyYAML happens to be installed — not added as a new hard
   dependency). `--config PATH` on the CLI, merge precedence explicit CLI
   flag > config file > default, unknown keys are a hard error. See
   ARCHITECTURE.md's new "config-file loader" section for the design
   rationale and CHANGELOG.md v0.7 for the full change list.
2. **Camera Finding emission**: `CameraShield.get_findings()` now returns
   real findings for two previously-silent gaps (faces beyond `max_faces`,
   degenerate/skipped face boxes). `camera/` is now the second real
   `Finding` producer alongside `file_privacy/`. See ARCHITECTURE.md's new
   "camera-produced Findings" section.

Also discovered and worked around a real environment issue: this sandbox's
default `mediapipe` (0.10.33) doesn't have `mediapipe.solutions` at all —
confirmed directly, not assumed — which meant `camera/shield.py` couldn't
even be *imported*, let alone tested, until the exact pinned dependency set
from `requirements.txt` was reinstalled. This is the same tech debt already
flagged in v0.2/DEPENDENCY_REPORT.md, now additionally confirmed to bite in
*this* environment specifically, not just as a theoretical future risk.

**Explicitly not done this session** (see ROADMAP.md "Next" for why):
wiring camera `Finding`s into `privacy_engine/cli.py`'s `report` command.
That command is file/directory-path based; camera is a live feed. Bolting
one onto the other without a real design pass (sampling window, when to
report, whether it runs alongside `camera/`'s normal loop) would have been
the kind of speculative interface-guessing this project's architecture
notes explicitly warn against.

## v0.6 session summary

Fixed the numpy/opencv-python/mediapipe pin conflict that v0.5 found but
left open. Verified the fix in a completely clean virtualenv, not just by
editing the file — see CHANGELOG.md v0.6 and DEPENDENCY_REPORT.md for the
full verification trail. No code changes this session, only
`requirements.txt` and documentation.

## v0.5 session summary

Added a `deployment_mode` config switch (`desktop` / `headless`) so
Camera Shield runs both as a desktop video-call tool and as an always-on
service on a homelab/server box from the same codebase, in response to
the operator asking specifically about homelab deployment. See the
"Done (v0.5)" section of ROADMAP.md and the v0.5 entry in CHANGELOG.md
for full detail. Everything below this point is carried over from the
v0.4 handoff except where explicitly marked v0.5.

## How this document was produced

The GitHub repo linked for this project (`certifiedclaw/Face-blur`) returned
a 404 when fetched during this session — it may be private, renamed, or not
yet pushed. **This state doc is therefore built from the single Python
script provided directly in the handoff conversation, not from repo
history.** If the real repo has diverged from that script, this document
and the code in this package should be reconciled against it before further
work.

## A request that was declined this session

A second repo (`certifiedclaw/aether`) was suggested as a source to pull an
"OSINT module" from. On inspection it's an unrelated general-purpose voice
assistant with a generic OSINT toolkit (WHOIS, subdomain enumeration, port
scanning, breach checks, Google dorks) aimed at arbitrary targets — not
scoped to self-auditing. That conflicts with this project's own stated
scope for `identity_audit/` ("only support authorized self-auditing") and
`network/` ("do not add offensive networking functionality"), so it was not
imported. `identity_audit/` remains an empty placeholder; see ROADMAP.md for
what a properly self-audit-scoped version would look like.

## Completed / implemented (verified by running, not just read)

- **Camera Shield** (`camera/` + `config/` + `main.py`)
  - Live webcam capture, face-mesh detection, per-face bounding box.
  - Three modes: `light` (pixelate + block shuffle), `warp` (landmark-driven
    nonlinear displacement + pixelate + shuffle), `blur` (Gaussian blur).
  - **Fixed a gap in the original script**: its docstring advertised
    "warp mode uses face mesh landmarks" but the actual warp function used a
    random displacement grid with no landmark input at all. The new
    `landmark_warp()` genuinely anchors displacement to detected landmarks
    (nose, eyes, mouth corners, chin, forehead).
  - **Added**: exponential box smoothing (`SmoothedBox`) to remove
    frame-to-frame jitter — the original recomputed an unsmoothed box every
    frame.
  - **Added**: multi-face support — the original only ran single-face
    detection; this uses FaceMesh with `max_num_faces` and a smoother per
    face slot.
  - **Added**: edge feathering so the scrambled patch blends into the frame
    instead of showing a hard rectangle.
  - **Added**: `blur` mode as a cheap fallback.
  - **Added**: camera-drop recovery (original would just crash the loop on
    a failed `cap.read()`; this retries).
  - **Added**: CLI args via `argparse` instead of hard-coded module
    constants.
  - Virtual camera output via `pyvirtualcam`, same as original, still
    optional/best-effort.
  - **(v0.5) Deployment-mode switch**: `--mode desktop` (unchanged) vs.
    `--mode headless` (no `cv2.imshow`/`waitKey`, accepts a device index
    or an RTSP/HTTP network camera URL via `--source`, serves output as
    an MJPEG HTTP stream via the new `camera/stream_server.py` instead of
    a virtual webcam). See CHANGELOG.md v0.5 for full detail.
  - **(v0.7) Config file loader**: `config/settings.py`'s
    `load_config_file()` + `--config PATH` on `CameraShieldConfig.
    from_args()`. JSON always works (stdlib `json`); YAML works if PyYAML
    happens to be installed (not a new hard dependency). Precedence:
    explicit CLI flag > config file > hard default, for every field.
    Unknown keys in the file are a hard error. Examples:
    `docs/config_example.json`, `docs/config_example.yaml`.
  - **(v0.7) Finding emission**: `CameraShield.get_findings()` returns
    real `core.findings.Finding`s for two conditions that were already
    happening silently before this: faces beyond the `max_faces` limit
    left unscrambled (HIGH), and faces whose bounding box degenerates to
    zero area and gets skipped (MEDIUM). `camera/` is now the second real
    `Finding` producer, alongside `file_privacy/`.

- **File Privacy** (`file_privacy/` + `core/findings.py`)
  - Metadata scan + strip for four formats: JPEG/TIFF (EXIF, including GPS
    coordinate decoding), **PNG (v0.4: text chunks + eXIf chunk)**, PDF
    (Info dictionary), DOCX (**v0.4: both core.xml and app.xml** —
    Company/Manager fields live in app.xml, not core.xml, and were missed
    entirely before v0.4).
  - `core/findings.py` defines the shared `Finding`/`Severity` data
    structure that ARCHITECTURE.md said was a prerequisite for
    `privacy_engine/` — `file_privacy` is the first module to produce it.
  - `file_privacy/scanner.py`: `scan_file()` / `scan_directory()` return
    `Finding` lists; GPS in a photo is flagged HIGH severity, author/
    creator/company/manager fields MEDIUM, other metadata LOW.
  - `file_privacy/remover.py`: `remove_metadata()` writes a stripped copy —
    **never modifies the original file**, verified by a test that checks
    the source file's bytes are unchanged after cleaning.
  - CLI: `python -m file_privacy.cli scan <path>` and
    `python -m file_privacy.cli clean <path> -o <output>`. Both manually
    run end-to-end against a real generated JPEG with GPS EXIF in this
    session (see Verified section below).
  - Bugs caught by the test suite and fixed before this handoff:
    (1) pypdf's `PdfWriter` re-stamps its own `"/Producer": "pypdf"` on
    every `write()` even when you pass `add_metadata({})` — clearing it
    requires explicitly overwriting every key with `""`. (2) Pillow's
    `Image.getdata()`/`putdata()` is deprecated (removal slated 2027);
    switched to `img.tobytes()`/`Image.frombytes()`.

- **Privacy Engine** (`privacy_engine/`, new in v0.4)
  - `report.py`: `build_report(findings)` aggregates a flat `Finding` list
    into a `PrivacyReport` — total score (weighted sum by severity: LOW=1,
    MEDIUM=3, HIGH=8), an overall risk label (None/Low/Moderate/High/
    Severe), a plain-language explanation, and findings grouped by module
    and by severity. This is the aggregator ARCHITECTURE.md said
    `file_privacy`'s `Finding` output was a prerequisite for.
  - `cli.py`: `python -m privacy_engine.cli report <path> [--json]` — scans
    a file or directory via `file_privacy` and prints the report in the
    `Privacy Report / <module>: / Overall Risk: / Explanation:` format the
    original project spec sketched, or as JSON.
  - Only consumes `file_privacy` findings today, since that's the only
    module producing `Finding`s so far — camera/audio/identity_audit/
    network findings will flow into the same `build_report()` once those
    modules exist, with no changes needed to `privacy_engine/` itself.
  - Risk thresholds are intuition-based, not data-calibrated (documented
    in-code and in ROADMAP.md) — a single GPS leak alone now correctly
    reads as "High" risk, not diluted down to "Moderate" just because it's
    the only finding. This was caught and fixed by a failing test during
    this session, not designed correctly on the first attempt.

- **Tests**: 82 pytest unit tests total — 11 for `camera/` (`distortions`/
  `tracking`, unchanged since v0.2), 23 for `file_privacy/` (13 from v0.3 +
  10 for PNG/app.xml in v0.4), 11 for `privacy_engine/` (v0.4), 13 for the
  v0.5 deployment-mode switch (8 config + 5 stream server), 18 for the v0.7
  config-file loader, 6 for v0.7 camera Finding emission. All passing
  (`python -m pytest tests/` → `82 passed`).

## Verified this session, exactly what was checked

- `python -m py_compile` on every changed file: clean.
- Full pytest suite: 11/11 passed.
- Ran `CameraShield.process_frame()` against a **real** MediaPipe FaceMesh
  model instance on a synthetic frame (no real webcam available in this
  environment) — no exceptions, correct output shape.
- Manually exercised the `warp` code path (`scramble_region(..., "warp", ...)`)
  with fabricated landmark anchors to confirm `landmark_warp()` runs and
  returns a correctly-shaped array.
- Exercised keyboard handling (`_handle_key`) for mode cycling and quit.
- **Not verified**: the full `CameraShield.run()` live loop against a real
  physical webcam, and `pyvirtualcam` actually producing a usable virtual
  device — both require hardware/OS drivers not present in this sandbox.
  Test on a real machine before treating video-call use as fully validated.
- **file_privacy, this session**: built real synthetic files (a JPEG with
  actual EXIF GPS/Make tags via `piexif`, a PDF with a real Info dictionary
  via `pypdf`, a DOCX with real `docProps/core.xml` via `zipfile`), ran
  scan → verify findings → strip → rescan → verify zero findings through
  both the Python API (pytest) and the CLI directly (`python -m
  file_privacy.cli scan/clean`, manually run against a generated demo JPEG,
  output inspected). Not tested: PDFs/DOCX files produced by real-world
  tools (Word, Acrobat, phone cameras) which may have metadata in shapes
  the synthetic fixtures don't cover — see known debt below.

## Known technical debt / bugs found

1. **Critical dependency break, found and pinned during this session**:
   `mediapipe` releases `>=0.10.30` remove the legacy `mediapipe.solutions`
   API (`FaceMesh`, `FaceDetection`) that both the original script and this
   codebase depend on, in favor of the new MediaPipe Tasks API. Verified by
   installing and testing versions 0.10.14 through 0.10.35 directly:
   0.10.21 still has `solutions`, 0.10.30 does not.
   `requirements.txt` now pins `mediapipe==0.10.21`. **This is a ticking
   time bomb** — that pin will eventually fail to install on newer Python
   versions or get flagged as outdated. See `ROADMAP.md` for the Tasks-API
   migration item and `DEPENDENCY_REPORT.md` for detail.
2. The original script had no separation between pipeline logic and I/O
   (single ~180-line file). This handoff splits it into `distortions.py`
   (pure functions, tested), `tracking.py` (pure functions, tested), and
   `shield.py` (I/O orchestration, not unit-testable without hardware) —
   but `shield.py` itself is still one class doing capture + detection +
   rendering + virtual cam + keyboard handling. It's a reasonable size now,
   but if the dashboard (PyQt6) module lands, `run()`'s OpenCV-window-based
   UI loop will need to be decoupled from the processing pipeline so the
   dashboard can drive frames instead.
3. No structured logging config beyond `logging.basicConfig` in `main.py`;
   fine for a CLI tool, will need revisiting once there's a dashboard
   writing to the same log stream.
4. ~~No config file support yet~~ **(resolved in v0.7)**: `config/
   settings.py`'s `load_config_file()` + `--config PATH`. See CHANGELOG.md
   v0.7 and ARCHITECTURE.md's config-file-loader section.
5. `file_privacy` only scrubs the standard metadata containers (EXIF Info
   IFD, PDF Info dict, DOCX core.xml). It does **not** touch: PDF XMP
   metadata streams, DOCX `docProps/app.xml` (company/manager fields
   sometimes live there too), embedded thumbnails that can carry their own
   EXIF, or document *content* (e.g. tracked changes, comments, hidden
   text). Tested only against synthetically-constructed files with metadata
   this code itself understands — a photo from a real phone or a Word doc
   from real Microsoft Word may carry additional fields not yet in
   `NOTABLE_TAGS`/`NOTABLE_KEYS`/`NOTABLE_CORE_TAGS`. Treat "no findings" as
   "no findings in the fields we currently check," not "provably clean."
6. `file_privacy/scanner.py` only handles `.jpg/.jpeg/.tiff/.tif`, `.pdf`,
   `.docx`. PNG (which can carry its own metadata chunks), HEIC (default
   iPhone photo format), and older `.doc`/`.xls`/`.ppt` formats are not
   supported yet (PNG added in v0.4 -- HEIC and legacy Office formats still
   aren't).
7. `privacy_engine`'s risk score is a simple weighted sum (LOW=1, MEDIUM=3,
   HIGH=8) with hand-picked thresholds, not calibrated against any real
   judgment of what "Severe" vs "High" should mean in practice. Treat the
   label as a rough, explainable indicator, not a precise measurement --
   the report's `explanation` text is more informative than the label
   alone.
8. `privacy_engine` only aggregates `file_privacy` findings through its
   `cli.py`/`report` command **as of v0.7 too** — `camera/` now genuinely
   produces `Finding`s (see above), which does prove out the aggregator's
   module-agnostic design at the `build_report()` level (tested directly
   against hand-built `Finding` objects from both modules' shapes), but
   `privacy_engine/cli.py`'s `report <path>` command still only wires up
   `file_privacy` because it's file/directory-path based and camera is a
   live feed — see ROADMAP.md "Next" for the live-report-mode design work
   this still needs.
9. **(v0.7)** YAML config file support is genuinely optional and untested
   in an environment *without* PyYAML installed (this sandbox happens to
   have it). The `ImportError` fallback path (`yaml = None`) is exercised
   by code inspection, not by an actual PyYAML-absent test run — worth a
   real check in an environment where PyYAML truly isn't present before
   fully trusting that error path.

## Not implemented (placeholders only)

Every package below exists as an empty directory with `__init__.py` so the
target architecture in the handoff spec is scaffolded, but contains **no
functional code**: `audio/`, `identity_audit/`, `network/`, `dashboard/`,
`plugins/`, `models/`.
(`file_privacy/` moved out of this list in v0.3; `privacy_engine/` moved
out in v0.4 — see above for both.)

Do not assume any OCR/document redaction, username/breach exposure
checking, network awareness, or dashboard UI exists — none of it does yet.
Building any of it as "already there" in future sessions would be
inaccurate; check this file first.

## Immediate next steps (see ROADMAP.md for full plan)

0. **(v0.5)** Validate `--mode headless` against real hardware: a real USB
   webcam or RTSP/IP camera, on an actual headless Linux box, with the
   MJPEG stream viewed from another device on the LAN. This session only
   verified the code paths, config defaults, and error handling — no
   physical homelab hardware was available to test against.
1. Validate `CameraShield.run()` against real webcam hardware on a target
   OS (Windows/macOS/Linux) before calling Camera Shield "done."
2. Decide the mediapipe migration path (pin vs. port to Tasks API) — see
   `DEPENDENCY_REPORT.md`.
3. Test `file_privacy` against real-world files (actual phone photos, actual
   Word/Acrobat output), not just synthetic fixtures, and expand
   `NOTABLE_TAGS`/`NOTABLE_KEYS`/`NOTABLE_CORE_TAGS`/`NOTABLE_APP_TAGS` as
   gaps are found.
4. Add HEIC support to `file_privacy` — it's the default iPhone photo
   format and still unsupported.
5. ~~Wire `camera/`'s pipeline to also emit `Finding`s~~ **done in v0.7**
   (`CameraShield.get_findings()`). Follow-up: design and wire a live/
   streaming report mode into `privacy_engine` so those findings actually
   reach a `PrivacyReport` — `cli.py`'s `report <path>` command is still
   file/directory-path only; see ROADMAP.md "Next".
6. Revisit `privacy_engine`'s scoring weights/thresholds once there's
   real usage — they're currently a reasonable-sounding guess, documented
   as such in `privacy_engine/report.py` and `ROADMAP.md`.
7. **(v0.7)** Test the YAML config-file path in an environment that
   genuinely doesn't have PyYAML installed, to confirm the "install
   PyYAML or use JSON" error message actually fires correctly rather than
   just being correct by code inspection.
