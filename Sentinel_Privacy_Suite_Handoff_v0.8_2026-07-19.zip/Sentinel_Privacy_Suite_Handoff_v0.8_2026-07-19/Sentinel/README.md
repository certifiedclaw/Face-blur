# Sentinel Privacy Suite

A local-first privacy and identity protection platform. Everything runs on
your machine — no cloud calls, no telemetry.

**Current status: v0.4 — Camera Shield + File Privacy + Privacy Engine.**
The broader suite described in `ROADMAP.md` (audio shield, identity audit,
network awareness, dashboard) is planned but not yet implemented. See
`PROJECT_STATE.md` for the honest current state.

## What works today: Camera Shield

Real-time webcam face anonymization with three modes:

- **light** — pixelation + randomized block shuffle over the detected face.
  Cheap, good for video calls.
- **warp** — landmark-driven nonlinear warp (eyes/nose/mouth get pulled and
  pushed based on actual face-mesh geometry) + pixelation + shuffle. Heavier
  distortion, still moves naturally with your face.
- **blur** — plain Gaussian blur. Cheapest option, good fallback on weak
  hardware.

Output is sent to a virtual camera you can select as your webcam source in
Zoom/Meet/Discord, or previewed locally if no virtual camera driver is found.

### Install

```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

> **Note on the mediapipe/opencv-python version pins:** `requirements.txt`
> pins `mediapipe==0.10.21` deliberately — releases from 0.10.30 onward
> removed the legacy `mediapipe.solutions` API this code uses for FaceMesh.
> That pin requires `numpy<2`, which is why `opencv-python` is also capped
> (`<4.12`, since 4.12.0.88+ requires `numpy>=2`). Change either pin only
> after re-reading `DEPENDENCY_REPORT.md` — they're linked, not independent.

### Run

Two deployment modes, one codebase (`--mode`):

```bash
# Desktop: local webcam, preview window, output to a virtual webcam
# for use in Zoom/Meet/Discord. This is the default.
python main.py --mode desktop

# Headless: for a homelab/server box with no display attached. Reads
# from a local device index OR a network camera (RTSP/HTTP), and
# serves the anonymized output as an MJPEG stream you can view from
# any browser on your LAN instead of a virtual webcam.
python main.py --mode headless --source 0
python main.py --mode headless --source rtsp://user:pass@192.168.1.50/stream
# -> visit http://<server-ip>:8080/ in a browser
```

> **Security note:** the MJPEG stream has **no authentication** and binds
> `0.0.0.0` by default (needed for LAN viewing — that's the whole point of
> the feature). Trust your LAN; never port-forward `--http-port` to the
> public internet without adding your own auth/TLS in front of it (e.g. a
> reverse proxy). Use `--http-host 127.0.0.1` if you only need to view it
> from the same machine. Sentinel logs a warning at startup whenever it
> binds to a non-loopback address, as a reminder. Full threat model in
> `ARCHITECTURE.md`.

Options:

```
--config PATH    JSON or YAML file providing defaults for any option
                 below (see docs/config_example.json). CLI flags you
                 pass explicitly always override the config file.
--mode {desktop,headless}   deployment mode (default: desktop)
--source SRC     device index (e.g. 0) or a stream URL (rtsp://.../http://...)
--block N        pixel block size (default 14)
--warp N         max warp displacement in px (default 40)
--pad F          face box padding fraction (default 0.35)
--feather N      edge feather width in px, 0 to disable (default 18)
--max-faces N    max faces to scramble at once (default 4)

# Every output can be forced on/off regardless of --mode:
--preview / --no-preview     local cv2 window (desktop default: on)
--vcam / --no-vcam           virtual camera output (desktop default: on)
--stream / --no-stream       MJPEG HTTP stream (headless default: on)
--http-host HOST             stream bind address (default 0.0.0.0)
--http-port PORT             stream bind port (default 8080)
--http-quality N             MJPEG JPEG quality 1-100 (default 80)
```

Instead of remembering flags every run, point at a config file:

```bash
python main.py --config docs/config_example.json
# CLI flags still win if you also pass them:
python main.py --config docs/config_example.json --block 20
```

YAML config files (`docs/config_example.yaml`) work the same way if
PyYAML is installed (`pip install pyyaml`) — it's optional, not a hard
dependency of this project; `.json` config files need nothing extra.

Virtual camera driver is only relevant in desktop mode (needed for
`--vcam` to actually produce a virtual webcam rather than falling back to
preview-only):

- **Windows**: install OBS (bundles the virtual cam driver), or "OBS Virtual Camera".
- **macOS**: `brew install obs`, or use OBS's virtual cam.
- **Linux**: `sudo modprobe v4l2loopback devices=1 video_nr=10 card_label="ScrambleCam"`

Controls while running (desktop preview window only — headless mode has
no keyboard to read from; stop it with Ctrl+C or your process manager):

```
SPACE   cycle light -> warp -> blur -> light
=/-     increase/decrease scramble intensity
[ / ]   decrease/increase warp strength (warp mode)
f       toggle FPS overlay
q       quit
```

### Run tests

```bash
pip install pytest
python -m pytest tests/
```

The test suite covers the pure image-processing functions (pixelate, block
shuffle, feathering, warp, box smoothing) without needing a webcam. It does
**not** cover `CameraShield.run()`'s live camera loop, which needs real
hardware — see `PROJECT_STATE.md` for what's manually verified vs.
unit-tested.

## What works today: File Privacy

Scans photos and documents for metadata that could identify or locate you,
and can write a metadata-stripped copy. Supports JPEG/TIFF and PNG (EXIF/
text-chunk metadata, including GPS), PDF (Info dictionary), and DOCX (core
properties — author, last editor, title — and extended properties —
company, manager).

```bash
python -m file_privacy.cli scan photo.jpg
python -m file_privacy.cli scan ~/Documents --recursive
python -m file_privacy.cli clean photo.jpg -o photo_clean.jpg
```

`clean` always writes to a separate output path — it never overwrites or
modifies the original file.

**Not yet supported**: HEIC (the default iPhone photo format), legacy
`.doc`/`.xls`/`.ppt`, PDF XMP metadata streams, and document *content*
(tracked changes, comments, hidden text) as opposed to metadata fields. See
`PROJECT_STATE.md` for the current, honest coverage limits.

## What works today: Privacy Engine

Aggregates findings from other modules (currently: File Privacy) into a
single risk report with an overall score, a risk label, and a
plain-language explanation of what was found and why it matters.

```bash
python -m privacy_engine.cli report photo.jpg
python -m privacy_engine.cli report ~/Documents --json
```

Example output:

```
Privacy Report
===============

file_privacy:
  [HIGH  ] GPS coordinates found in photo
           This image embeds a precise location (51.50740, -0.12780)...
           -> Strip EXIF metadata before sharing this photo.

Overall Risk: High (score: 8)
Explanation: 1 high-severity finding(s) ... are enough to meaningfully
identify or locate you.
```

The score is a simple, explainable weighted sum (not a trained model) —
see `ARCHITECTURE.md` for why that trade-off was made deliberately.

## Project layout

```
Sentinel/
├── main.py              # entry point
├── camera/               # Camera Shield (implemented)
│   ├── distortions.py    # pixelate / shuffle / landmark-warp / feather
│   ├── tracking.py       # box smoothing, landmark -> bbox
│   └── shield.py         # pipeline orchestrator (capture -> detect -> distort -> output)
├── config/                # CameraShieldConfig dataclass + CLI parsing
├── core/
│   └── findings.py        # shared Finding/Severity data structure
├── file_privacy/           # metadata scan/strip (implemented)
│   ├── formats/            # images.py (incl. PNG), pdf.py, docx.py (core+app.xml)
│   ├── scanner.py
│   ├── remover.py
│   └── cli.py
├── privacy_engine/          # findings aggregator + report (implemented)
│   ├── report.py            # build_report() -> PrivacyReport
│   └── cli.py
├── tests/                  # pytest suite: camera/, file_privacy/, privacy_engine/
├── audio/                  # placeholder package, not implemented
├── identity_audit/          # placeholder package, not implemented
├── network/                  # placeholder package, not implemented
├── dashboard/              # placeholder package, not implemented
├── plugins/                # placeholder package, not implemented
├── models/                 # reserved for local model weights
├── docs/                   # this documentation set
└── releases/                # handoff zips
```

See `ARCHITECTURE.md` for design rationale and `ROADMAP.md` for what's next.

## Design principles

- **Local processing** — no frame, image, or metadata ever leaves the machine.
- **Privacy by design** — every module should default to the more protective
  option.
- **Transparency** — the suite should explain *why* it flags something as a
  risk, not just present a score.
- **Modular** — each capability is its own package with a narrow interface,
  so it can be developed, tested, and disabled independently.
