
@echo off
setlocal
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
    echo [ERROR] No .venv found here yet.
    echo Run install.bat first, then try run.bat again.
    pause
    exit /b 1
)

rem Forwards any arguments straight to main.py, e.g.:
rem   run.bat --mode headless --source 0
rem   run.bat --config docs\config_example.json
rem   run.bat --help
".venv\Scripts\python.exe" main.py %*

if errorlevel 1 (
    echo.
    echo Sentinel exited with an error ^(see above^).
    pause
)
 