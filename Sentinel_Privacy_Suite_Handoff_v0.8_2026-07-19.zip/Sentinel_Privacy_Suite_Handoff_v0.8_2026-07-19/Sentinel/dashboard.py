
@echo off
setlocal
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
    echo [ERROR] No .venv found here yet.
    echo Run install.bat first, then try dashboard.bat again.
    pause
    exit /b 1
)

echo Starting the Sentinel dashboard at http://127.0.0.1:8090/
echo Open that address in your browser. Press Ctrl+C here to stop it.
echo.

rem Forwards any arguments straight to dashboard/server.py, e.g.:
rem   dashboard.bat --source 0
rem   dashboard.bat --no-camera
rem   dashboard.bat --host 0.0.0.0 --port 9000   (see ARCHITECTURE.md first)
".venv\Scripts\python.exe" -m dashboard.server %*

if errorlevel 1 (
    echo.
    echo Dashboard exited with an error ^(see above^).
    pause
)
 