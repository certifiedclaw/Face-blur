"""File/directory scan: collect `file_privacy` findings for a single file
or a whole directory tree, as a flat list ready for
`privacy_engine.report.build_report()`.

This is the I/O orchestration layer for the *file* path of the privacy
engine -- the live-camera counterpart lives in `privacy_engine.camera_scan`.
Pulled out of `privacy_engine.cli` (where it started as a private
`_collect_findings()` helper) so `dashboard/server.py`'s on-demand file-scan
panel can reuse the exact same logic the CLI's `report <path>` command
uses, rather than the dashboard reimplementing directory-walking and
unsupported-file-type handling itself.
"""

from __future__ import annotations

from pathlib import Path

from core.findings import Finding
from file_privacy.scanner import UnsupportedFileType, scan_directory, scan_file


def collect_file_findings(path: Path) -> list[Finding]:
    """Scan `path` (a file or a directory) and return a flat list of
    Findings. A directory is scanned recursively; individual files of an
    unsupported type are silently skipped (same behavior `cli.py`'s
    `report` command has always had -- `file_privacy.scanner` already
    raises `UnsupportedFileType` for exactly this, so skipping it here
    isn't new leniency, just centralizing where that's handled).
    """
    if path.is_dir():
        results = scan_directory(path, recursive=True)
        findings: list[Finding] = []
        for file_findings in results.values():
            findings.extend(file_findings)
        return findings
    try:
        return scan_file(path)
    except UnsupportedFileType:
        return []
