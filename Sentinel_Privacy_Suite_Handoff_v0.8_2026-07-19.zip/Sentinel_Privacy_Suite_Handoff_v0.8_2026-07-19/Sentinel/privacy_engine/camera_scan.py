"""Live camera scan: sample CameraShield findings over a bounded time
window, return a deduplicated union for the privacy report aggregator.

This is the I/O orchestration layer for the *live* path of the privacy
engine -- the file-scan path lives in `file_privacy.scanner` and is
wired up by `privacy_engine.cli.cmd_report()`. The aggregator
(`privacy_engine.report.build_report`) is unchanged from v0.7 and
consumes whatever list of `Finding`s we hand it.

This module owns only the live-vs-file difference:
  - The per-frame sampling loop.
  - The time-bounded run (camera scans aren't a static artifact, so
    we need a deadline rather than a single read).
  - The dedup key (file scans never need it -- one file = one
    Finding list -- so it lives here, not in the aggregator).

Scope note (v0.8): this is camera-only. Audio/identity/network live
scans are deliberately out of scope -- those modules don't produce
`Finding`s yet, and the `plugins/` design in ROADMAP.md says to wait
for at least one more live producer before designing a unified live
interface (we already have the second consumer needed: this scan
path proves `build_report()` is genuinely live-source agnostic).
"""

from __future__ import annotations

import logging
import time
from typing import Callable

import cv2
import mediapipe as mp

from camera.shield import MODE_CYCLE, CameraShield
from config.settings import CameraShieldConfig, redact_source
from core.findings import Finding

logger = logging.getLogger(__name__)


def _dedup_key(f: Finding) -> tuple[str, str, str]:
    """Findings with the same (source_module, category, title) describe
    the same kind of exposure. Per-frame `extra` data varies frame to
    frame (e.g. how many faces overflowed) but the kind-of-exposure is
    stable, so that's what we dedup on."""
    return (f.source_module, f.category, f.title)


def scan_camera(
    config: CameraShieldConfig,
    duration_s: float,
    *,
    mode: str | None = None,
    time_source: Callable[[], float] = time.monotonic,
) -> list[Finding]:
    """Run CameraShield on the configured source for `duration_s` seconds
    and return the deduplicated union of findings observed across all
    frames.

    The anonymization mode the camera uses during the scan can be pinned
    via `mode` ("light" / "warp" / "blur"). If `mode` is None the
    camera's default (the first mode in MODE_CYCLE, "light") is used --
    this matches the existing CameraShield constructor behavior, so
    callers that don't care don't need to pass anything.

    `time_source` defaults to `time.monotonic`; tests can pass a callable
    that advances faster than wall clock to exercise the deadline check
    without sleeping.
    """
    if duration_s <= 0:
        raise ValueError("duration_s must be positive")

    cap = cv2.VideoCapture(config.source)
    if not cap.isOpened():
        raise RuntimeError(
            f"Could not open camera source {redact_source(config.source)!r}. "
            "Pass a device index (--source 0) or a stream URL "
            "(--source rtsp://user:pass@host/stream)."
        )
    w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)) or 1280
    h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT)) or 720

    shield = CameraShield(config)
    if mode is not None:
        if mode not in MODE_CYCLE:
            raise ValueError(
                f"Unknown anonymization mode {mode!r}; expected one of {MODE_CYCLE}."
            )
        shield.mode_idx = MODE_CYCLE.index(mode)

    # Union of findings seen, keyed by (source_module, category, title).
    # `setdefault` keeps the FIRST occurrence's Finding object (so its
    # `extra` is from the first frame we saw the condition on, not the
    # last). That's a deliberate, documented choice: the per-frame
    # `extra` data is most informative as "this condition happened at
    # least once" rather than as a latest-value snapshot. If a future
    # use case needs the worst-case or latest frame's numbers, that
    # would be a small follow-up -- don't pre-empt it now.
    by_key: dict[tuple[str, str, str], Finding] = {}

    deadline = time_source() + duration_s
    frame_count = 0
    try:
        with mp.solutions.face_mesh.FaceMesh(
            max_num_faces=config.max_faces,
            refine_landmarks=False,
            min_detection_confidence=config.min_detection_confidence,
            min_tracking_confidence=config.min_tracking_confidence,
        ) as mesh:
            while time_source() < deadline:
                ok, frame = cap.read()
                if not ok:
                    logger.warning("Lost camera feed; retrying...")
                    time.sleep(0.1)
                    continue
                shield.process_frame(frame, mesh, w, h)
                for f in shield.get_findings():
                    by_key.setdefault(_dedup_key(f), f)
                frame_count += 1
    except KeyboardInterrupt:
        # Return whatever we've already collected rather than raising --
        # a long-running scan that gets Ctrl+C'd is still useful: the
        # findings observed so far are still real exposures.
        logger.info("Scan interrupted; reporting findings collected so far.")
    finally:
        cap.release()

    logger.info(
        "Scanned %d frames in %.1fs; %d unique finding(s).",
        frame_count, duration_s, len(by_key),
    )
    return list(by_key.values())
