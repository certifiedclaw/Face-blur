# MediaPipe Solutions API to Tasks API Migration Plan

## Overview
This document outlines the plan to migrate from the deprecated MediaPipe Solutions API (`mp.solutions.face_mesh`) to the modern MediaPipe Tasks API (`mediapipe.tasks.vision.FaceLandmarker`). This migration is necessary to:
1. Remove the hard pin on `mediapipe==0.10.21` 
2. Allow updating `opencv-python` and `numpy` to newer versions
3. Maintain compatibility with future MediaPipe releases
4. Address the technical debt noted in ROADMAP.md and DEPENDENCY_REPORT.md

## Current State (v0.8)
- **MediaPipe version**: `==0.10.21` (hard pin)
- **API used**: `mediapipe.solutions.face_mesh.FaceMesh`
- **Dependencies**: 
  - `opencv-python>=4.9,<4.12` (load-bearing cap)
  - `numpy>=1.26,<2.0` (due to mediapipe constraint)
- **Location**: `camera/shield.py` lines 29 and 119-125

## Target State
- **MediaPipe version**: `>=0.10.30` (latest stable)
- **API used**: `mediapipe.tasks.vision.FaceLandmarker`
- **Dependencies**: Updated versions allowing numpy>=2.0 if needed
- **Location**: `camera/shield.py` - updated imports and processing logic

## Migration Steps

### 1. Preparation
- [ ] Backup current `camera/shield.py`
- [ ] Review MediaPipe Tasks API documentation: https://developers.google.com/mediapipe/solutions/vision/face_landmarker/python
- [ ] Download face landmarker model (if not using default)

### 2. Dependency Updates
Update `requirements.txt`:
```diff
- opencv-python>=4.9,<4.12
- numpy>=1.26,<2.0
- mediapipe==0.10.21
+ opencv-python>=4.9  # Upper bound can be re-evaluated post-migration
+ numpy>=1.26         # Lower bound maintained, upper can be re-evaluated
+ mediapipe>=0.10.30  # Remove hard pin, use Tasks API
```

### 3. Code Changes in `camera/shield.py`

#### Import Changes
```diff
- import mediapipe as mp
- mp_face_mesh = mp.solutions.face_mesh
+ from mediapipe import tasks
+ from mediapipe.tasks import python
+ from mediapipe.tasks.python import vision
```

#### Initialization Changes
Replace the `with mp_face_mesh.FaceMesh(...) as mesh:` context manager with FaceLandmarker initialization:

```diff
-    def run(self):
-        """Main processing loop running in a daemon thread."""
-        with self._cond:
-            self._ready = True
-            self._cond.notify_all()
-
-        with mp_face_mesh.FaceMesh(
-            static_image_mode=self.config.freeze_frame,
-            max_num_faces=2,
-            refine_landmarks=True,
-            min_detection_confidence=0.5,
-            min_tracking_confidence=0.5,
-        ) as mesh:
-            # ... rest of method
+    def run(self):
+        """Main processing loop running in a daemon thread."""
+        with self._cond:
+            self._ready = True
+            self._cond.notify_all()
+
+        # Configure FaceLandmarker options
+        base_options = python.BaseOptions(model_asset_path='face_landmarker.task')
+        options = vision.FaceLandmarkerOptions(
+            base_options=base_options,
+            output_face_blendshapes=False,  # Disable if not needed for performance
+            output_facial_transformation_matrixes=False,
+            num_faces=2,
+            min_face_detection_confidence=0.5,
+            min_face_presence_confidence=0.5,
+            min_tracking_confidence=0.5,
+            running_mode=vision.RunningMode.VIDEO if not self.config.freeze_frame else vision.RunningMode.IMAGE
+        )
+        detector = vision.FaceLandmarker.create_from_options(options)
+        
+        # For video mode, we need to track timestamp
+        timestamp = 0
+
+        try:
+            while self.running:
+                # ... frame capture logic ...
+                
+                # Process frame
+                mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb)
+                
+                if self.config.freeze_frame:
+                    # Image mode for static images
+                    detection_result = detector.detect(mp_image)
+                else:
+                    # Video mode for streaming
+                    detection_result = detector.detect_for_video(mp_image, timestamp)
+                    timestamp += 1  # Increment timestamp for video frames
+
+                # Process detection results (similar to existing logic)
+                findings: list[Finding] = []
+                if detection_result.face_landmarks:
+                    for face_landmarks in detection_result.face_landmarks:
+                        # Convert landmarks to same format as before
#                         # ... landmark processing logic ...
+                else:
+                    self.smoothers.clear()
+                    
+                self.last_findings = findings
+                # ... rest of frame processing ...
+        finally:
+            detector.close()
```

#### Process Frame Method Changes
Update `process_frame` method to work with FaceLandmarker results:

```diff
-    def process_frame(self, frame: np.ndarray, mesh, frame_w: int, frame_h: int) -> np.ndarray:
-        """Run detection + scrambling on a single BGR frame. Pure function of
-        (frame, model state) aside from self.smoothers/rng, so it's the
-        easiest entry point to unit test with a canned frame."""
-        findings: list[Finding] = []
-        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
-        results = mesh.process(rgb)
-
-        if not results.multi_face_landmarks:
-            self.smoothers.clear()
-            self.last_findings = findings
-            return frame
+
+    def process_frame(self, frame: np.ndarray, detector, frame_w: int, frame_h: int, timestamp: int = 0) -> np.ndarray:
+        """Run detection + scrambling on a single BGR frame. Pure function of
+        (frame, model state) aside from self.smoothers/rng, so it's the
+        easiest entry point to unit test with a canned frame."""
+        findings: list[Finding] = []
+        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
+        mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb)
+        
+        detection_result = detector.detect_for_video(mp_image, timestamp)
+
+        if not detection_result.face_landmarks:
+            self.smoothers.clear()
+            self.last_findings = findings
+            return frame
```

#### Landmark Processing Adaptation
The landmark data structure differs between the APIs:
- **Solutions API**: `results.multi_face_landmarks` -> list of `NormalizedLandmarkList`
- **Tasks API**: `detection_result.face_landmarks` -> list of `NormalizedLandmark` lists

Need to adapt the landmark processing code that calculates eye/mouth ratios, etc.

### 4. Model File Handling
The Tasks API requires a `.task` model file. Options:
- **Bundle the model**: Download `face_landmarker.task` and include in repo
- **Use default path**: Let MediaPipe download automatically (requires internet)
- **Embed in code**: Not recommended for size reasons

Recommendation: Download and include the model file in the repo under `models/face_landmarker.task`

### 5. Testing Strategy
1. **Unit tests**: Update tests in `tests/` to mock the new API
2. **Integration tests**: Verify face detection still works with webcam
3. **Regression tests**: Ensure privacy effects (blur, warp, etc.) still function
4. **Performance tests**: Compare FPS between old and new implementations

### 6. Risks and Mitigations
- **Risk**: Different landmark coordinates/prediction accuracy
  - **Mitigation**: Compare outputs and adjust thresholds if needed
- **Risk**: Performance regression
  - **Mitigation**: Benchmark both implementations, optimize if needed
- **Risk**: Model file size increase
  - **Mitigation**: Use quantized model if available, check size impact

### 7. Dependencies Update Impact
After successful migration:
- Can potentially remove `opencv-python<4.12` constraint
- Can potentially remove `numpy<2.0` constraint
- Would need to re-evaluate both constraints together per DEPENDENCY_REPORT.md lines 133-141

### 8. Estimated Effort
- **Research & planning**: 2 hours
- **Implementation**: 4-6 hours
- **Testing**: 2-4 hours
- **Documentation**: 1 hour
- **Total**: 9-13 hours

## References
- MediaPipe Tasks API Guide: https://developers.google.com/mediapipe/solutions/vision
- Face Landmarker Guide: https://developers.google.com/mediapipe/solutions/vision/face_landmarker/python
- Model Asset: https://developers.google.com/mediapipe/solutions/vision/face_landmarker#models
- DEPENDENCY_REPORT.md: Lines 79-81 and 133-141
- ROADMAP.md: "Resolve the mediapipe `solutions` API deprecation properly"

## Files to Modify
1. `camera/shield.py` - Main implementation
2. `requirements.txt` - Dependency updates
3. `tests/` - Update any tests that mock MediaPipe
4. `docs/` or create new documentation - Migration notes
5. `models/face_landmarker.task` - Model file (if bundled)

## Verification Checklist
- [ ] Face detection still works with webcam
- [ ] All privacy effects (blur, warp, etc.) still function
- [ ] Dashboard integration unaffected
- [ ] File scanning functionality unaffected
- [ ] Performance within acceptable range (<10% FPS change)
- [ ] No regression in existing unit tests
- [ ] Dependencies can be updated as planned