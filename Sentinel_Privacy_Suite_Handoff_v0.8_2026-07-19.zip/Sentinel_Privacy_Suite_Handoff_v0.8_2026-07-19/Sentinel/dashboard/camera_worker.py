"""Background camera worker for the web dashboard.

Runs `CameraShield`'s detection/anonymization loop in a daemon thread,
continuously updating:
  - a `camera.stream_server.FrameBuffer` (so `dashboard/server.py` can serve
    the exact same MJPEG stream `--mode headless --stream` already serves),
  - a live `Finding`/`PrivacyReport` snapshot (so the dashboard's `/api/status`
    endpoint has something to poll).

This is deliberately a *third* shape for running Camera Shield's loop,
alongside the two that already exist:
  - `CameraShield.run()`: owns the whole desktop/headless deployment loop
    (preview window, virtual cam, its own HTTP stream) -- blocks until the
    user quits.
  - `privacy_engine.camera_scan.scan_camera()`: runs for a fixed
    `duration_s` and returns a deduplicated Finding list -- a bounded,
    one-shot scan.
  - `CameraDashboardWorker` (here): runs indefinitely in the background
    until `stop()` is called, and exposes a live, continuously-refreshed
    snapshot rather than returning a single final result. None of the
    three should be collapsed into one another -- they have genuinely
    different lifecycles (blocking-until-quit vs. bounded-duration vs.
    start/stop-from-another-thread), and forcing one shape to serve all
    three callers would make all of them worse. See ARCHITECTURE.md's
    dashboard section for the full rationale.
"""

from __future__ import annotations

import logging
import threading
import time

import cv2
import mediapipe as mp

from camera.shield import MODE_CYCLE, CameraShield
from camera.stream_server import FrameBuffer
from config.settings import CameraShieldConfig, redact_source
from core.findings import Finding
from privacy_engine.report import build_report

logger = logging.getLogger(__name__)


class CameraDashboardWorker:
    """Owns exactly one background camera loop.

    Not safe to `start()` twice concurrently on the same instance without
    an intervening `stop()` -- there is only one `cv2.VideoCapture` and one
    `FrameBuffer` per instance, matching how `CameraShield` itself is
    single-loop.
    """

    def __init__(self, config: CameraShieldConfig | None = None, mode: str | None = None):
        self.config = config or CameraShieldConfig()
        self.shield = CameraShield(self.config)
        if mode is not None:
            if mode not in MODE_CYCLE:
                raise ValueError(f"Unknown anonymization mode {mode!r}; expected one of {MODE_CYCLE}.")
            self.shield.mode_idx = MODE_CYCLE.index(mode)

        self.frame_buffer = FrameBuffer()

        self._lock = threading.Lock()
        self._findings: list[Finding] = []
        self._frame_count = 0
        self._started_at: float | None = None
        self._error: str | None = None
        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None

    @property
    def running(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    def start(self) -> None:
        if self.running:
            return
        self._stop_event.clear()
        self._error = None
        self._frame_count = 0
        self._started_at = time.monotonic()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop_event.set()
        if self._thread is not None:
            self._thread.join(timeout=5)
            self._thread = None

    def _run(self) -> None:
        cap = cv2.VideoCapture(self.config.source)
        if not cap.isOpened():
            self._error = (
                f"Could not open camera source {redact_source(self.config.source)!r}."
            )
            logger.error(self._error)
            return

        w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)) or 1280
        h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT)) or 720

        try:
            with mp.solutions.face_mesh.FaceMesh(
                max_num_faces=self.config.max_faces,
                refine_landmarks=False,
                min_detection_confidence=self.config.min_detection_confidence,
                min_tracking_confidence=self.config.min_tracking_confidence,
            ) as mesh:
                while not self._stop_event.is_set():
                    ok, frame = cap.read()
                    if not ok:
                        logger.warning("Dashboard camera worker lost the feed; retrying...")
                        time.sleep(0.5)
                        continue

                    frame = self.shield.process_frame(frame, mesh, w, h)
                    self.frame_buffer.update(frame)
                    with self._lock:
                        self._findings = self.shield.get_findings()
                        self._frame_count += 1
        except Exception as e:  # pragma: no cover - defensive; surfaced via snapshot()["error"]
            logger.exception("Dashboard camera worker crashed")
            self._error = str(e)
        finally:
            cap.release()

    def snapshot(self) -> dict:
        """A JSON-able snapshot of the current findings/report plus basic
        run stats, for `/api/status` to poll. Builds a fresh
        `PrivacyReport` from whatever the most recent frame's findings
        were -- cheap (a handful of Findings, not thousands) so recomputing
        on every poll rather than caching is the simpler, still-correct
        choice here.
        """
        with self._lock:
            findings = list(self._findings)
            frame_count = self._frame_count

        report = build_report(findings)
        uptime_s = None if self._started_at is None else time.monotonic() - self._started_at

        return {
            "running": self.running,
            "error": self._error,
            "mode": self.shield.mode,
            "frame_count": frame_count,
            "uptime_s": uptime_s,
            "report": report.to_dict(),
        }
