"""Local web dashboard for Sentinel Privacy Suite.

A single stdlib-only HTTP server (no Flask/FastAPI -- same philosophy as
`camera/stream_server.py`) that puts three things in one browser tab:

  1. The live, already-anonymized camera feed (MJPEG, same mechanism as
     `--mode headless --stream`).
  2. A live-updating privacy report built from whatever `Finding`s
     `CameraShield` is currently producing (unprotected faces, degenerate
     boxes -- see `camera/shield.py`), polled from the browser every couple
     of seconds.
  3. An on-demand file/directory scan panel: type a path on this machine,
     get back the same `PrivacyReport` shape `privacy_engine report <path>`
     produces.

See ARCHITECTURE.md's dashboard section for why this is a browser
dashboard instead of the PyQt6 desktop app ROADMAP.md originally sketched,
and for the threat-model reasoning behind the loopback-only default below.

Routes:
    GET  /              dashboard HTML page
    GET  /stream.mjpg   live anonymized video (only meaningful if the
                         camera worker is running -- see --no-camera)
    GET  /api/status    JSON: live findings + report + basic run stats
    GET  /api/file-scan?path=...   JSON: PrivacyReport for that file/dir
"""

from __future__ import annotations

import argparse
import json
import logging
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from camera.shield import LOOPBACK_HOSTS
from camera.stream_server import stream_mjpeg
from config.settings import CameraShieldConfig
from dashboard.camera_worker import CameraDashboardWorker
from privacy_engine.file_scan import collect_file_findings
from privacy_engine.report import build_report

logger = logging.getLogger(__name__)


def warn_if_file_scan_exposed(host: str, port: int, log: logging.Logger = logger) -> bool:
    """Log a sharper warning than `camera.shield.warn_if_stream_exposed`
    when the dashboard's `/api/file-scan` endpoint is reachable from
    outside this machine.

    This is a materially bigger exposure than the video stream: it lets
    whoever can reach this port ask "does this path exist, and if so what
    metadata/findings does it contain" for *any* path this process can
    read on the host filesystem -- not just the camera feed. Kept as its
    own function (rather than folded into `warn_if_stream_exposed`) so the
    two risks stay independently named and testable; the dashboard binds
    one port serving both, but they're different capabilities with
    different blast radii, and a reader of the logs should be able to
    tell which warning is about which.
    """
    if host in LOOPBACK_HOSTS:
        return False

    log.warning(
        "Dashboard binding to %s:%s -- this exposes /api/file-scan, which "
        "will report privacy findings for ANY file or directory path this "
        "process can read on this machine, to anyone who can reach this "
        "address. This is a materially bigger exposure than the video "
        "stream alone. Trust your LAN; never port-forward this port to "
        "the public internet. Use --host 127.0.0.1 (the default) to "
        "restrict the dashboard to this machine only. See "
        "ARCHITECTURE.md for the full threat model.",
        host, port,
    )
    return True


_INDEX_HTML = b"""<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Sentinel Dashboard</title>
<style>
  :root { color-scheme: dark; }
  body { margin: 0; background: #0b0d10; color: #e6e6e6; font-family: -apple-system, Segoe UI, Helvetica, Arial, sans-serif; }
  header { padding: 14px 20px; border-bottom: 1px solid #2a2e33; display: flex; align-items: baseline; gap: 12px; }
  header h1 { font-size: 18px; margin: 0; }
  header .sub { color: #8a8f98; font-size: 13px; }
  main { display: grid; grid-template-columns: minmax(320px, 1.1fr) minmax(360px, 1fr); gap: 16px; padding: 16px 20px; }
  @media (max-width: 900px) { main { grid-template-columns: 1fr; } }
  section { background: #14171a; border: 1px solid #2a2e33; border-radius: 10px; padding: 14px; }
  section h2 { font-size: 14px; text-transform: uppercase; letter-spacing: 0.04em; color: #9aa0aa; margin: 0 0 10px; }
  #video-wrap { background: #000; border-radius: 8px; overflow: hidden; aspect-ratio: 16/9; display: flex; align-items: center; justify-content: center; position: relative; }
  #video-wrap img { width: 100%; display: block; }
  #video-placeholder { color: #6a6f78; font-size: 13px; position: absolute; }
  .stat-row { display: flex; justify-content: space-between; font-size: 13px; padding: 4px 0; color: #c7cad0; }
  .stat-row b { color: #fff; }
  .risk-badge { display: inline-block; padding: 3px 10px; border-radius: 999px; font-weight: 600; font-size: 13px; }
  .risk-None, .risk-Low { background: #16351f; color: #6fd88a; }
  .risk-Moderate { background: #3a3417; color: #e6c85a; }
  .risk-High, .risk-Severe { background: #3a1a1a; color: #e67a7a; }
  .finding { border-left: 3px solid #444; padding: 6px 0 6px 10px; margin-bottom: 8px; font-size: 13px; }
  .finding.high { border-color: #e67a7a; }
  .finding.medium { border-color: #e6c85a; }
  .finding.low { border-color: #6fd88a; }
  .finding .title { font-weight: 600; }
  .finding .desc { color: #9aa0aa; margin-top: 2px; }
  .empty { color: #6a6f78; font-size: 13px; }
  #scan-form { display: flex; gap: 8px; margin-bottom: 12px; }
  #scan-path { flex: 1; background: #0b0d10; border: 1px solid #2a2e33; color: #e6e6e6; padding: 7px 10px; border-radius: 6px; font-size: 13px; }
  #scan-form button { background: #2b5fd9; color: white; border: none; padding: 7px 14px; border-radius: 6px; font-size: 13px; cursor: pointer; }
  #scan-form button:hover { background: #3a6ce0; }
  #scan-error { color: #e67a7a; font-size: 13px; margin-bottom: 8px; }
  footer { padding: 10px 20px; color: #5a5f68; font-size: 12px; }
</style>
</head>
<body>
<header>
  <h1>Sentinel Dashboard</h1>
  <span class="sub">local-first, no cloud &mdash; everything on this page comes from this machine</span>
</header>
<main>
  <section>
    <h2>Live camera feed</h2>
    <div id="video-wrap">
      <img id="video" src="/stream.mjpg" alt="live anonymized feed"
           onerror="this.style.display='none'; document.getElementById('video-placeholder').style.display='block';">
      <div id="video-placeholder" style="display:none">
        No camera feed (worker not running, or camera unavailable)
      </div>
    </div>
    <div style="margin-top:12px">
      <div class="stat-row"><span>Status</span><b id="stat-running">&ndash;</b></div>
      <div class="stat-row"><span>Mode</span><b id="stat-mode">&ndash;</b></div>
      <div class="stat-row"><span>Frames processed</span><b id="stat-frames">&ndash;</b></div>
      <div class="stat-row"><span>Uptime</span><b id="stat-uptime">&ndash;</b></div>
    </div>
    <div id="stat-error" style="color:#e67a7a;font-size:13px;margin-top:8px"></div>
  </section>

  <section>
    <h2>Live privacy report (camera)</h2>
    <div style="margin-bottom:10px">
      Overall risk: <span id="live-risk" class="risk-badge risk-None">&ndash;</span>
    </div>
    <div id="live-findings"><p class="empty">Waiting for first status update&hellip;</p></div>
  </section>

  <section style="grid-column: 1 / -1">
    <h2>Scan a file or directory on this machine</h2>
    <form id="scan-form" onsubmit="return runScan()">
      <input id="scan-path" type="text" placeholder="/path/to/file/or/folder" autocomplete="off">
      <button type="submit">Scan</button>
    </form>
    <div id="scan-error"></div>
    <div id="scan-result"><p class="empty">No scan run yet.</p></div>
  </section>
</main>
<footer>Findings shown here reflect what Sentinel currently checks for &mdash; see PROJECT_STATE.md for known gaps. This dashboard itself listens on loopback by default; see ARCHITECTURE.md before exposing it beyond this machine.</footer>

<script>
function riskClass(label) { return "risk-" + (label || "None").replace(/\\s+/g, ""); }

function renderFindings(container, findings) {
  if (!findings || findings.length === 0) {
    container.innerHTML = '<p class="empty">No findings.</p>';
    return;
  }
  const order = {high: 0, medium: 1, low: 2};
  const sorted = findings.slice().sort((a, b) => (order[a.severity] ?? 3) - (order[b.severity] ?? 3));
  container.innerHTML = sorted.map(f => `
    <div class="finding ${f.severity}">
      <div class="title">[${f.severity.toUpperCase()}] ${escapeHtml(f.title)}</div>
      <div class="desc">${escapeHtml(f.description)}</div>
      <div class="desc">&rarr; ${escapeHtml(f.remediation)}</div>
    </div>
  `).join("");
}

function escapeHtml(s) {
  const div = document.createElement("div");
  div.textContent = s == null ? "" : String(s);
  return div.innerHTML;
}

function fmtUptime(s) {
  if (s == null) return "\\u2013";
  s = Math.floor(s);
  const m = Math.floor(s / 60), sec = s % 60;
  return m > 0 ? `${m}m ${sec}s` : `${sec}s`;
}

async function pollStatus() {
  try {
    const resp = await fetch("/api/status");
    const data = await resp.json();
    document.getElementById("stat-running").textContent = data.running ? "running" : "stopped";
    document.getElementById("stat-mode").textContent = data.mode || "\\u2013";
    document.getElementById("stat-frames").textContent = data.frame_count ?? "\\u2013";
    document.getElementById("stat-uptime").textContent = fmtUptime(data.uptime_s);
    document.getElementById("stat-error").textContent = data.error || "";

    const badge = document.getElementById("live-risk");
    badge.textContent = `${data.report.risk_label} (score ${data.report.score})`;
    badge.className = "risk-badge " + riskClass(data.report.risk_label);

    renderFindings(document.getElementById("live-findings"), data.report.findings);
  } catch (e) {
    document.getElementById("stat-error").textContent = "Could not reach /api/status: " + e;
  }
}

async function runScan() {
  const path = document.getElementById("scan-path").value.trim();
  const errorEl = document.getElementById("scan-error");
  const resultEl = document.getElementById("scan-result");
  errorEl.textContent = "";
  if (!path) { errorEl.textContent = "Enter a path first."; return false; }

  resultEl.innerHTML = '<p class="empty">Scanning&hellip;</p>';
  try {
    const resp = await fetch("/api/file-scan?path=" + encodeURIComponent(path));
    const data = await resp.json();
    if (data.error) {
      errorEl.textContent = data.error;
      resultEl.innerHTML = '<p class="empty">No scan run yet.</p>';
      return false;
    }
    const badge = `<span class="risk-badge ${riskClass(data.report.risk_label)}">${data.report.risk_label} (score ${data.report.score})</span>`;
    resultEl.innerHTML = `<div style="margin-bottom:10px">Scanned <code>${escapeHtml(data.path)}</code> &mdash; ${badge}</div><div id="scan-findings"></div>`;
    renderFindings(document.getElementById("scan-findings"), data.report.findings);
  } catch (e) {
    errorEl.textContent = "Scan request failed: " + e;
  }
  return false;
}

pollStatus();
setInterval(pollStatus, 2000);
</script>
</body>
</html>
"""


def _make_handler(worker: CameraDashboardWorker, jpeg_quality: int):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, fmt: str, *args) -> None:
            logger.debug("%s - %s", self.address_string(), fmt % args)

        def do_GET(self) -> None:  # noqa: N802 - stdlib method name
            parsed = urlparse(self.path)

            if parsed.path in ("/", "/index.html"):
                self._serve_index()
            elif parsed.path in ("/stream", "/stream.mjpg"):
                stream_mjpeg(self, worker.frame_buffer, jpeg_quality)
            elif parsed.path == "/api/status":
                self._serve_json(worker.snapshot())
            elif parsed.path == "/api/file-scan":
                self._serve_file_scan(parse_qs(parsed.query))
            else:
                self.send_response(404)
                self.end_headers()

        def _serve_index(self) -> None:
            body = _INDEX_HTML
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def _serve_json(self, data: dict) -> None:
            body = json.dumps(data, default=str).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def _serve_file_scan(self, query: dict) -> None:
            raw_paths = query.get("path")
            if not raw_paths or not raw_paths[0].strip():
                self._serve_json({"error": "missing ?path= query parameter"})
                return

            raw_path = raw_paths[0]
            p = Path(raw_path)
            if not p.exists():
                self._serve_json({"error": f"path does not exist: {raw_path}"})
                return

            try:
                findings = collect_file_findings(p)
            except Exception as e:
                logger.exception("Dashboard file-scan failed for %s", raw_path)
                self._serve_json({"error": str(e)})
                return

            report = build_report(findings)
            self._serve_json({"path": str(p), "report": report.to_dict()})

    return Handler


class DashboardServer:
    """Runs a `ThreadingHTTPServer` serving the dashboard in a background
    thread, same pattern as `camera.stream_server.MjpegStreamServer`."""

    def __init__(
        self,
        worker: CameraDashboardWorker,
        host: str = "127.0.0.1",
        port: int = 8090,
        jpeg_quality: int = 80,
    ) -> None:
        self.worker = worker
        self._server = ThreadingHTTPServer((host, port), _make_handler(worker, jpeg_quality))
        self._thread: threading.Thread | None = None

    @property
    def address(self) -> tuple[str, int]:
        return self._server.server_address[:2]

    def start(self) -> None:
        self._thread = threading.Thread(target=self._server.serve_forever, daemon=True)
        self._thread.start()
        host, port = self.address
        logger.info("Dashboard available at http://%s:%s/", host, port)

    def stop(self) -> None:
        self._server.shutdown()
        self._server.server_close()
        if self._thread is not None:
            self._thread.join(timeout=2)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="dashboard",
        description="Sentinel local web dashboard: live camera feed + live "
                    "findings + on-demand file/directory scan, in one browser tab.",
    )
    parser.add_argument(
        "--config", type=str, default=None,
        help="JSON/YAML camera config file (same format as main.py --config).",
    )
    parser.add_argument(
        "--source", type=str, default=None,
        help="camera source override: device index (e.g. 0) or a stream URL.",
    )
    parser.add_argument(
        "--mode", choices=["light", "warp", "blur"], default=None,
        help="anonymization mode for the camera worker (default: light).",
    )
    parser.add_argument(
        "--host", type=str, default="127.0.0.1",
        help="dashboard bind host (default: 127.0.0.1, loopback-only -- see "
             "ARCHITECTURE.md before changing this: /api/file-scan can read "
             "any path this process can access).",
    )
    parser.add_argument("--port", type=int, default=8090, help="dashboard bind port (default 8090)")
    parser.add_argument(
        "--no-camera", action="store_true",
        help="start the dashboard without the camera worker -- file-scan "
             "panel only, no live feed. Useful if no camera is attached.",
    )
    args = parser.parse_args(argv)

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")

    camera_argv: list[str] = []
    if args.config:
        camera_argv += ["--config", args.config]
    if args.source is not None:
        camera_argv += ["--source", args.source]
    config = CameraShieldConfig.from_args(camera_argv)

    worker = CameraDashboardWorker(config, mode=args.mode)
    if not args.no_camera:
        worker.start()

    warn_if_file_scan_exposed(args.host, args.port)

    server = DashboardServer(worker, host=args.host, port=args.port, jpeg_quality=config.http_jpeg_quality)
    server.start()
    print(f"Dashboard running at http://{args.host}:{args.port}/  (Ctrl+C to stop)")

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("Shutting down...")
    finally:
        server.stop()
        worker.stop()
    return 0


if __name__ == "__main__":
    sys.exit(main())
