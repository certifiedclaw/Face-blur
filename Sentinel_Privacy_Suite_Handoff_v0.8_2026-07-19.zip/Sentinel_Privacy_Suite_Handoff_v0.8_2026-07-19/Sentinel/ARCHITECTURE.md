# ARCHITECTURE.md

## Guiding constraints

- **Local-only.** No module should make an outbound network call with user
  data (camera frames, audio, files, metadata). `network/` is explicitly
  scoped as *monitoring-only* (VPN/DNS/IP visibility awareness), never as an
  offensive or data-exfiltrating capability.
- **Modular over monolithic.** Each capability (camera, audio, file privacy,
  identity audit, network awareness) is its own top-level package with a
  narrow public interface, so it can be developed, tested, versioned, and
  toggled independently — this is also what the `plugins/` system will need
  to enable/disable modules at runtime later.
- **Pure functions where possible.** Image/pixel transforms
  (`camera/distortions.py`) and geometry helpers (`camera/tracking.py`) take
  plain arrays/tuples in, return plain arrays/tuples out, with no I/O or
  global state. That's what makes them unit-testable without a webcam —
  the entire `tests/` suite runs without camera hardware.
- **I/O isolated at the edges.** Anything that touches a camera, a virtual
  cam device, a file on disk, or the network lives in one class per module
  (`CameraShield` today) that orchestrates the pure functions. `process_frame()`
  turned out to be exactly the seam `dashboard/camera_worker.py` (v0.9)
  needed to hook into instead of the OpenCV preview window -- see below.
- **Credentials never appear in logs or error messages.** A camera source
  can be an RTSP/HTTP URL with embedded `user:pass@` credentials (the
  standard way to reach a homelab IP camera). Anywhere a source is shown
  to a human — a log line, an exception message — it must go through
  `config.settings.redact_source()` first. The raw, unredacted source is
  still what actually gets passed to `cv2.VideoCapture()`; only the
  *display* path is redacted. See "Current module: `camera/stream_server.py`"
  below for the related network-exposure threat model.

## Current module: `camera/`

```
camera/
├── distortions.py   pixelate, block_shuffle, landmark_warp, feather_mask,
│                    scramble_region (mode dispatch)
├── tracking.py       SmoothedBox (jitter reduction), get_box_from_landmarks
└── shield.py          CameraShield: owns cv2.VideoCapture, mediapipe FaceMesh,
                        pyvirtualcam.Camera, the render loop, and keyboard input
```

**Why split distortions from tracking from orchestration:** the original
single-file script mixed all three concerns, which made the "warp mode uses
face landmarks" claim in its own docstring silently false — nothing forced
the warp function to actually receive landmarks, and there was no test that
would have caught it. Separating "given these pixels and these landmark
points, produce distorted pixels" (testable, no I/O) from "read a camera,
find landmarks, call the distortion, show/send the result" (I/O, needs
hardware) makes that class of bug visible in a unit test instead of only in
a demo.

**Why `CameraShield` is still one class:** at this size (one video pipeline,
one output sink, one input device) an orchestrator class is simpler than
premature interfaces. The point where it should be split is when the
dashboard needs to drive frames through the same pipeline without an OpenCV
window and keyboard polling — at that point `process_frame()` (already a
standalone method taking a frame in, returning a frame out) becomes the
seam, and the `run()` loop's OpenCV-specific I/O gets extracted into a
`CameraShieldCliRunner` or similar, leaving `CameraShield` itself
UI-agnostic. Not done yet because there's no dashboard consuming it yet —
building that abstraction before it has a second caller would be
speculative.

## Face box smoothing

`SmoothedBox` uses exponential smoothing (`box = alpha * new + (1-alpha) *
old`) rather than a fixed-window moving average, because it needs O(1)
memory per tracked face and reacts smoothly to fast head movement without
a lag spike from a full window refill. `alpha=0.5` is a starting point, not
a tuned constant. As of v0.7 it (and every other `CameraShieldConfig`
field) can be adjusted via a config file without a code change -- see
"Current module: `config/settings.py` config-file loader" below -- but the
*value* itself is still an untuned guess, unrelated to whether it's easy to
change.

## Landmark-driven warp

`landmark_warp()` picks a small fixed set of semantically meaningful
landmarks (eye corners, nose tip, mouth corners, chin, forehead) rather than
all 468 mesh points, and builds a smooth displacement field by Gaussian-
weighting each anchor's random push vector by distance. Fewer anchors keeps
the per-frame cost low (no per-point remap, just one field composed from
~9 points) while still producing organic, face-shaped distortion instead of
the original's spatially-uniform random grid.

## Why mediapipe FaceMesh instead of separate face-detection + landmark
models

The original script used `mp.solutions.face_detection.FaceDetection` for
box-only detection and a separate `mp.solutions.face_mesh.FaceMesh` for
warp mode's landmarks — two different models loaded depending on mode. This
version uses `FaceMesh` unconditionally, deriving the bounding box *from*
the landmarks (`get_box_from_landmarks`) instead of from a separate
detector. Trade-off: `FaceMesh` is somewhat heavier per-frame than the
lightweight detector, but it removes the need to load/switch between two
models mid-stream, and gives every mode (not just warp) access to landmark
data if a future feature needs it (e.g. eye/mouth-region-only redaction).
If profiling on target hardware shows this is too slow for `light` mode on
low-end machines, reintroducing the cheaper detector for that mode
specifically is a reasonable follow-up — flagged in `ROADMAP.md`.

## Current module: `camera/stream_server.py` — threat model (v0.8)

`MjpegStreamServer` (used in `--mode headless`) binds `0.0.0.0` by
default and serves the anonymized video feed over **plain HTTP with no
authentication**. That's a deliberate default, not an oversight — worth
stating explicitly rather than leaving implicit:

- It only ever runs when the operator explicitly chose `--mode headless`
  or passed `--stream`. Desktop mode never starts it. There's no scenario
  where a user gets an exposed port they didn't ask for.
- The entire point of the feature is LAN visibility — viewing the stream
  from another device on the same network. Binding to `127.0.0.1` by
  default would make the feature nonfunctional for its one stated use
  case (a homelab server has no local display to view `127.0.0.1` from).
- **What this does NOT protect against:** anyone else who can reach the
  bound port — anyone on the same LAN, or anyone reachable through a
  router misconfigured to forward that port to the internet — can view
  the stream. There is no login, no token, no TLS. The stream is the
  *already-anonymized* output (faces already scrambled), which limits
  the sensitivity of what leaks, but background/environment/audio-free
  video is still being served to anyone who can reach the port.
- **Operator responsibility, not yet enforced by the code:** trust your
  LAN, and never port-forward `--http-port` to the public internet
  without adding your own auth/TLS layer in front of it (a reverse proxy
  like Caddy or nginx with basic auth is the straightforward option).
  `--http-host 127.0.0.1` is available if you only need to view the
  stream from the same machine, or you're fronting it with something
  else that handles the network exposure itself.
- **Implemented:** `camera.shield.warn_if_stream_exposed()` logs a
  warning at startup whenever `http_host` binds to a non-loopback
  address (covers the normal `--mode headless` case, since `0.0.0.0` is
  the functioning default) — see CHANGELOG.md v0.8. `README.md` also
  carries this note next to the `--mode headless` example.
- **Not yet implemented:** any actual authentication or TLS on the
  stream itself — the warning makes the exposure visible, it doesn't
  close it. A real auth layer would be a reasonable follow-up if this
  sees genuine homelab use (see ROADMAP.md).

## Current module: `dashboard/` — web dashboard, not PyQt6 (v0.9)

ROADMAP.md originally sketched `dashboard/` as a PyQt6 desktop app, deferred
to "much later." v0.9 built it instead as a local **browser** dashboard,
after the operator was asked directly and chose that over the PyQt6 plan
(the two are a real fork, not a detail — see the tradeoffs below).

**Why a browser dashboard instead of PyQt6:**

- **Reuses what already exists.** `camera/stream_server.py`'s MJPEG
  approach (already built for `--mode headless`) is the same mechanism the
  dashboard uses for its live feed — `stream_mjpeg()` was pulled out of
  `stream_server.py` specifically so both call sites share one
  implementation of the multipart-framing details, rather than the
  dashboard reinventing them.
- **No new GUI dependency.** PyQt6 is a large, platform-specific
  dependency this project doesn't otherwise need; the dashboard adds zero
  new entries to `requirements.txt` (stdlib `http.server` only, same as
  `stream_server.py`).
- **Testable in this sandbox.** This environment has no display server, so
  a PyQt6 GUI could not have been exercised at all here — only traced by
  hand, the same gap `install.bat`/`run.bat`/`uninstall.bat` (v0.7.1) are
  stuck with. The web dashboard, by contrast, is a real HTTP server:
  `tests/test_dashboard_server.py` makes real loopback HTTP requests
  against it (same pattern as `test_stream_server.py`), so its routes,
  JSON shapes, and error handling are genuinely verified, not just
  reasoned about.
- **Fits the existing headless story.** A homelab box already serves its
  camera feed over HTTP for a reason (no display attached) — a browser
  dashboard is the natural extension of that, not a new paradigm.

**What this does *not* mean:** PyQt6 isn't ruled out forever. If a genuine
need for an OS-native app (system tray icon, native notifications, running
without a browser tab open) shows up, that's a real reason to revisit —
just not a default to reach for when a browser already does the job.

**Three different shapes for running Camera Shield's loop now coexist, on
purpose** (see `dashboard/camera_worker.py`'s docstring for the full
comparison): `CameraShield.run()` (blocks until the user quits — desktop/
headless deployment), `privacy_engine.camera_scan.scan_camera()` (blocks
for a fixed `duration_s`, returns one result — bounded diagnostic scan),
and `CameraDashboardWorker` (background thread, `start()`/`stop()`,
continuously-refreshed snapshot — a live dashboard). Each caller's
lifecycle is genuinely different; collapsing them into one shared function
would force at least one of the three into an awkward fit (e.g. bolting a
background-thread mode onto `scan_camera()` would mean threading through
stop-signaling that the CLI's bounded-scan callers never need).

**Threat model, extending the `stream_server.py` section above:** the
dashboard binds `127.0.0.1` **by default** — deliberately different from
`MjpegStreamServer`'s `0.0.0.0` default. `/api/file-scan?path=...` isn't
just a video feed: it lets whoever can reach the port ask "what privacy
findings exist for this path" for **any file or directory the process can
read on the host**, which is a materially bigger exposure surface than
watching an already-anonymized video stream. `warn_if_file_scan_exposed()`
(in `dashboard/server.py`, deliberately a separate function from
`warn_if_stream_exposed()` even though the dashboard binds one port serving
both capabilities) fires a sharper warning if `--host` is changed to
anything non-loopback. If genuine LAN access to the dashboard is needed
later, this is the same "add your own auth/TLS via a reverse proxy, don't
rely on the app itself" answer as the plain MJPEG stream — not attempted
here.

**Not done, deliberately:** no auth on `/api/file-scan` or `/stream.mjpg`
beyond the loopback-by-default bind; no persistence of scan history (every
`/api/file-scan` call is a fresh scan, nothing is stored between requests);
no dashboard view of `file_privacy`'s *stripping* capability (the dashboard
can show what's wrong with a file, not fix it) — all reasonable follow-ups,
none attempted speculatively here.

## Current module: `core/findings.py`

`Finding` and `Severity` (see docstring in that file) are the shared
vocabulary every detection module speaks. This was scaffolded as a "needs
to exist before `privacy_engine/` can be built for real" prerequisite in
v0.2's roadmap, and `file_privacy` is the first module to actually produce
instances of it. Deliberately minimal: category tag, human title/
description/remediation strings, a severity enum, which module produced it,
and an optional location + free-form `extra` dict for module-specific
details a future report renderer might want. `privacy_engine/` (not yet
built) is expected to import `Finding` from `core`, never the other way
around — modules stay ignorant of how their findings get aggregated.

## Current module: `file_privacy/`

```
file_privacy/
├── formats/
│   ├── images.py   EXIF read/strip (JPEG/TIFF), GPS decoding, PNG text-chunk
│   │                and eXIf-chunk read/strip (v0.4)
│   ├── pdf.py       PDF Info-dict read/strip
│   └── docx.py      DOCX core.xml AND app.xml read/strip (v0.4 added
│                     app.xml -- Company/Manager live there, not core.xml;
│                     stdlib zipfile+ElementTree only)
├── scanner.py        format detection + scan_file/scan_directory -> list[Finding]
├── remover.py         remove_metadata() dispatch by format
└── cli.py              `python -m file_privacy.cli scan|clean`
```

**Why format handlers are split from the scanner:** same rationale as
`camera/distortions.py` vs `camera/shield.py` — `formats/images.py`'s
`read_exif()`/`strip_exif()` take a path, return data/write a file, with no
knowledge of `Finding` or severity. `scanner.py` is the only place that
decides "GPS coordinates = HIGH severity." That split means adding a new
format (HEIC, legacy Office) only touches `formats/`, and adding a new
*policy* about what counts as high severity only touches `scanner.py` — a
`formats/*.py` change can't accidentally change severity scoring and vice
versa. This paid off concretely in v0.4: adding PNG and DOCX app.xml
support touched only `formats/images.py` and `formats/docx.py` plus a
small dispatch addition in `scanner.py`/`remover.py` — no severity logic
had to be re-derived.

**Why DOCX uses stdlib `zipfile`/`xml.etree` instead of `python-docx`:** the
only thing needed is reading/clearing a handful of fields in
`docProps/core.xml`. `python-docx` pulls in `lxml` and a much larger API
surface for that. A `.docx` is just a zip of XML parts, so stdlib is
sufficient and keeps the dependency footprint smaller — consistent with the
"avoid unnecessary dependencies" project principle.

**Why `remove_metadata()` never modifies files in place:** a privacy tool
that silently overwrites the user's only copy of a photo or document — with
no undo — is a bad failure mode even if the stripping logic is correct.
Every remover takes a separate output path; verified by a test that checks
the source file's bytes are byte-for-byte unchanged after cleaning.

**A real bug this surfaced, worth keeping in mind for future modules:**
`pypdf.PdfWriter` re-stamps `"/Producer": "pypdf"` on every `write()`
regardless of what's passed to `add_metadata()`, unless you explicitly
overwrite that key too. This was only caught because the round-trip test
asserted the *exact* post-strip metadata dict rather than just "author is
gone" — a lesson for how thorough these round-trip tests need to be as more
formats get added: assert on the full state, not just the field you were
thinking about when you wrote the test.

## Current module: `privacy_engine/`

```
privacy_engine/
├── report.py       build_report(findings) -> PrivacyReport (score,
│                   risk_label, explanation, grouped by module/severity);
│                   pure function of a Finding list, no I/O.
├── file_scan.py     collect_file_findings(path) -> list[Finding]; the
│                   file/directory orchestration layer (v0.9 -- extracted
│                   from cli.py's private _collect_findings(), see below).
├── camera_scan.py   scan_camera(config, duration_s) -> list[Finding]; the
│                   live-camera orchestration layer (v0.8), bounded-
│                   duration sampling + dedup (camera's Finding list
│                   changes every frame; a static "scan result" needs the
│                   union across the sampling window, not a snapshot).
└── cli.py           `python -m privacy_engine.cli report <path> [--json]`
                    and `camera-scan [--source ...] [--duration ...]`,
                    wiring file_scan.py / camera_scan.py into build_report().
```

**Why `build_report()` takes a flat `Finding` list instead of importing
`file_privacy`/`camera` directly:** this is the design ARCHITECTURE.md's
original draft asked for — `privacy_engine` should aggregate across
modules without being coupled to any one module's internals. `report.py`
has zero imports from `file_privacy`, `camera`, or any other detection
module. This was a real design decision, not just documentation after the
fact: `report.py` was written and fully tested (11 tests) against
hand-built `Finding` objects before `cli.py` touched `file_privacy` at
all, and that same `build_report()` was later proven against a second,
genuinely different producer (`camera/`) without changing a single line
of `report.py` — see `camera_scan.py`'s tests and the v0.8 camera-produced-
Findings section above.

**Why `file_scan.py` is a separate module, not still a private helper in
`cli.py` (v0.9):** it started as `cli.py`'s private `_collect_findings()`.
Pulled out once a second caller needed it: `dashboard/server.py`'s
`/api/file-scan` endpoint wants the exact same file/directory scanning
`report <path>` does, and importing a leading-underscore "private" helper
from another module would have been the wrong smell to ignore. Now
`file_scan.py` sits alongside `camera_scan.py` with a matching shape (one
function, `path`/`config` in, `list[Finding]` out) — `cli.py` and
`dashboard/server.py` both call it, and neither needs to know the other
exists.

**Why the score is a simple weighted sum instead of something fancier:**
the project spec's example report format prioritizes an *explainable*
score over a precise one ("The system should explain what was detected,
why it matters, how to reduce exposure" — not "the system should have the
most accurate possible score"). A weighted sum where every point traces
back to one specific finding is trivially explainable; a learned or
compound-interaction model would need its own justification layer on top
just to answer "why is my score 47." If real-world usage shows the simple
sum is miscalibrated (flagged as a known limitation in PROJECT_STATE.md and
ROADMAP.md), the fix is retuning `SEVERITY_WEIGHT`/`RISK_THRESHOLDS`, not
necessarily abandoning the explainable-sum approach.

## Planned modules (not yet implemented)

See `ROADMAP.md` for sequencing. Architecturally, each planned module is
expected to follow the same split as `camera/` and `file_privacy/`: pure
analysis/transform functions in one file (testable without
hardware/filesystem), I/O orchestration in another, and detected exposures
represented as `core.findings.Finding` objects so they plug into
`privacy_engine.report.build_report()` with no changes to that function —
`report.py` genuinely doesn't import `camera`, `audio`, `identity_audit`,
or `network`, and shouldn't start to.

## Current module: `config/settings.py` config-file loader (v0.7)

`load_config_file()` reads a JSON or YAML file into a plain `dict` of
`CameraShieldConfig` field overrides; `CameraShieldConfig.from_args()`
merges it with CLI flags via one rule applied uniformly to every field:
**explicit CLI flag > config file value > hard default.** This is the same
tri-state (`None` = "not set here") pattern the desktop/headless mode
defaults already used for `--preview`/`--vcam`/`--stream`, just extended to
every other field instead of invented fresh.

**Why JSON always works but YAML is optional:** JSON parsing is stdlib
(`json`), so a `.json` config file has zero new dependencies. YAML needs
PyYAML, which is *not* in `requirements.txt`'s hard dependency list —
consistent with the project's "evaluate before adding a dependency"
practice (see the HEIC/`pillow-heif` note in `ROADMAP.md`). `import yaml`
is wrapped in a `try/except ImportError` at module load, so the whole
`config/settings.py` module still imports fine without PyYAML installed;
only actually pointing `--config` at a `.yaml`/`.yml` file without PyYAML
raises a clear `ConfigFileError` telling you to install it or use JSON.

**Why unknown keys are a hard error, not a warning or silent skip:** a
config file is written once and often not looked at again for months (the
homelab-deployment use case this was built for, per `ROADMAP.md`). A
typo'd key (`"blur_ksze": 40`) that's silently ignored means the operator
believes a setting is applied when it isn't, discovered only much later if
at all. Failing loudly at startup costs one extra look at an error message
in exchange for never silently running with the wrong config.

**Why `--config` doesn't shadow the mode-based preview/vcam/stream
defaults:** those defaults are computed from the *final, merged*
`deployment_mode` (CLI, then config file, then `"desktop"`), not from the
raw CLI value — so a config file that sets `deployment_mode: headless`
gets the headless output defaults (no preview/vcam, stream on) exactly as
if `--mode headless` had been passed on the command line, and an explicit
`show_preview`/`use_virtual_cam`/`http_stream` key in the same file (or an
explicit CLI flag) still overrides that default, same as today.

## Current module: camera-produced `Finding`s (v0.7)

`CameraShield.process_frame()` now populates `self.last_findings` (exposed
via `get_findings()`) every frame, making `camera/` the second real
`Finding` producer alongside `file_privacy/` — proving the
"`privacy_engine` doesn't need to know which module a `Finding` came from"
design against more than one module for the first time (see the
`privacy_engine/` section above).

Two conditions are detected, both representing "a face is visible in frame
right now but isn't actually being anonymized":

- **More faces detected than `max_faces` allows** (HIGH): `process_frame`
  already only scrambles `results.multi_face_landmarks[:max_faces]` —
  anyone past that slice was, before v0.7, silently left unprotected with
  no signal that this had happened. This is arguably the more important of
  the two: it's a real, current gap in what the tool advertises it does
  (see `ROADMAP.md`'s "explicitly out of scope" note about never claiming
  perfect protection — this Finding is what makes the actual, current limit
  visible instead of implicit).
- **A face's smoothed bounding box collapses to zero area** (MEDIUM,
  typically at the extreme edge of frame): also already silently skipped
  before v0.7 (`if x2 <= x1 or y2 <= y1: continue`); now it's a visible,
  explained gap instead of a silent one.

**Why `last_findings` resets every frame instead of accumulating:** a
video feed's exposure is a *current-moment* fact ("is anyone unprotected
right now"), not a historical log the way a scanned file's metadata is.
`file_privacy`'s findings describe a static artifact; camera's describe a
live, constantly-changing state. Accumulating them across frames would
make "3 faces over the limit, once, five minutes ago" look identical to
"3 faces over the limit, continuously, right now" — the wrong shape of
information for a live feed. Anything that wants a history (e.g. a future
dashboard's "you were unprotected for 4 minutes at 2pm" log) should sample
`get_findings()` per frame and build its own timeline on top, rather than
`CameraShield` doing that aggregation itself.

**Not yet done, deliberately:** `privacy_engine/cli.py`'s `report <path>`
command is file/directory-path based and has no notion of a live camera
feed — wiring camera `Finding`s into it isn't "add a few lines" the way
adding a second *file* format was, it needs an actual live/streaming
report mode (e.g. "sample N seconds of camera Finding output and report
on it") designed on its own terms, not bolted onto the existing path-based
`report` command. That design pass is listed as a next step in
`ROADMAP.md`, not attempted here.
