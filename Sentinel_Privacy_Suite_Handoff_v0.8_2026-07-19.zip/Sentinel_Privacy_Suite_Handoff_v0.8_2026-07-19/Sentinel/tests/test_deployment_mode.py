"""Tests for config/settings.py's deployment-mode switch (desktop vs headless)."""

from __future__ import annotations

from config.settings import CameraShieldConfig, DeploymentMode, _parse_source, redact_source


def test_parse_source_int_string_becomes_int():
    assert _parse_source("0") == 0
    assert _parse_source("2") == 2


def test_parse_source_url_stays_string():
    url = "rtsp://user:pass@192.168.1.50/stream1"
    assert _parse_source(url) == url


def test_desktop_defaults():
    config = CameraShieldConfig.from_args(["--mode", "desktop"])
    assert config.deployment_mode == DeploymentMode.DESKTOP
    assert config.show_preview is True
    assert config.use_virtual_cam is True
    assert config.http_stream is False


def test_headless_defaults():
    config = CameraShieldConfig.from_args(["--mode", "headless"])
    assert config.deployment_mode == DeploymentMode.HEADLESS
    assert config.show_preview is False
    assert config.use_virtual_cam is False
    assert config.http_stream is True


def test_headless_with_rtsp_source():
    config = CameraShieldConfig.from_args(
        ["--mode", "headless", "--source", "rtsp://cam.local/stream"]
    )
    assert config.source == "rtsp://cam.local/stream"


def test_desktop_source_defaults_to_device_index_zero():
    config = CameraShieldConfig.from_args(["--mode", "desktop"])
    assert config.source == 0


def test_explicit_overrides_beat_mode_defaults():
    # Force streaming on even in desktop mode.
    config = CameraShieldConfig.from_args(["--mode", "desktop", "--stream"])
    assert config.http_stream is True
    assert config.show_preview is True  # unaffected

    # Force preview/vcam off even in desktop mode.
    config2 = CameraShieldConfig.from_args(["--mode", "desktop", "--no-preview", "--no-vcam"])
    assert config2.show_preview is False
    assert config2.use_virtual_cam is False

    # Force preview on even in headless mode (unusual, but should be honored).
    config3 = CameraShieldConfig.from_args(["--mode", "headless", "--preview"])
    assert config3.show_preview is True
    assert config3.http_stream is True  # headless default still applies


def test_http_host_and_port_configurable():
    config = CameraShieldConfig.from_args(
        ["--mode", "headless", "--http-host", "127.0.0.1", "--http-port", "9001"]
    )
    assert config.http_host == "127.0.0.1"
    assert config.http_port == 9001


# -- redact_source(): must never leak embedded RTSP/HTTP credentials -------

def test_redact_source_device_index_passthrough():
    assert redact_source(0) == "0"
    assert redact_source(2) == "2"


def test_redact_source_credential_free_url_unchanged():
    url = "rtsp://192.168.1.50/stream1"
    assert redact_source(url) == url


def test_redact_source_strips_rtsp_credentials():
    redacted = redact_source("rtsp://admin:hunter2@192.168.1.50/stream1")
    assert "admin" not in redacted
    assert "hunter2" not in redacted
    assert "192.168.1.50" in redacted
    assert redacted.startswith("rtsp://***:***@")


def test_redact_source_strips_http_credentials_and_keeps_port():
    redacted = redact_source("http://user:secret@cam.local:8081/mjpeg")
    assert "user" not in redacted
    assert "secret" not in redacted
    assert "cam.local" in redacted
    assert "8081" in redacted
    assert "/mjpeg" in redacted


def test_redact_source_username_only_still_redacted():
    # RTSP cameras sometimes only need a username, no password -- still
    # sensitive enough (often a fixed default like "admin") to strip.
    redacted = redact_source("rtsp://admin@192.168.1.50/stream1")
    assert "admin" not in redacted
    assert redacted.startswith("rtsp://***:***@")
