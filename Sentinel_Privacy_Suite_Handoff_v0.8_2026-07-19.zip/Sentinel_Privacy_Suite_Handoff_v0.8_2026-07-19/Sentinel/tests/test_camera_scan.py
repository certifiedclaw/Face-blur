"""Tests for the v0.8 live camera scan: `privacy_engine.camera_scan.
scan_camera()` and the new `python -m privacy_engine.cli camera-scan`
subcommand.

No real camera, no real mediapipe model, no real wall-clock sleeps:
`cv2.VideoCapture` and `mediapipe.solutions.face_mesh.FaceMesh` are
monkey-patched with fakes that yield synthetic frames / a controllable
mesh, and `scan_camera()` accepts a `time_source` callable so the
deadline check can be exercised without actually waiting N seconds.

The fake-mesh pattern (an object exposing .process() -> an object
with .multi_face_landmarks) is reused from `tests/test_camera_findings.py`
-- same approach, different orchestration layer under test.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import privacy_engine.camera_scan as camera_scan_module
import privacy_engine.cli as cli_module
from camera.shield import CameraShield
from config.settings import CameraShieldConfig
from core.findings import Finding, Severity


# --- Fake mediapipe mesh (same shape as test_camera_findings.py) -----------

class _FakeLandmark:
    def __init__(self, x: float, y: float):
        self.x = x
        self.y = y


class _FakeFaceLandmarks:
    def __init__(self, landmarks):
        self.landmark = landmarks


class _FakeResults:
    def __init__(self, faces):
        self.multi_face_landmarks = faces or None


class _FakeMesh:
    """Returns the same list of faces on every .process() call, so
    scan_camera's per-frame dedup is what actually shrinks the result."""

    def __init__(self, faces):
        self._faces = faces

    def process(self, rgb):
        return _FakeResults(self._faces)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False


# --- Fake cv2.VideoCapture ------------------------------------------------

class _FakeCapture:
    """Yields the same synthetic BGR frame on every .read() call."""

    def __init__(self, source, frame=None):
        self._source = source
        self._frame = frame if frame is not None else np.zeros((100, 100, 3), dtype=np.uint8)
        self._released = False

    def isOpened(self):
        return True

    def get(self, prop):
        if prop == 3:  # CAP_PROP_FRAME_WIDTH
            return self._frame.shape[1]
        if prop == 4:  # CAP_PROP_FRAME_HEIGHT
            return self._frame.shape[0]
        return 0

    def read(self):
        if self._released:
            return False, None
        return True, self._frame.copy()

    def release(self):
        self._released = True


class _FakeCaptureFactory:
    """Stand-in for `cv2.VideoCapture` that records its source arg and
    returns a _FakeCapture. Lets the test verify the source string
    actually flowed through `from_args()` into `scan_camera()`."""

    def __init__(self, frames=None):
        self.sources_seen: list = []
        self._frames = frames

    def __call__(self, source):
        self.sources_seen.append(source)
        return _FakeCapture(source, frame=self._frames)


# --- Fake FaceMesh class (monkey-patched in as mediapipe's class) ---------

def _make_fake_face_mesh_class(fake_mesh):
    """Return a context-manager class that always returns the same
    `_FakeMesh` instance regardless of kwargs, so `mp.solutions.
    face_mesh.FaceMesh(...)` works inside `scan_camera`."""

    class _FakeFaceMeshCM:
        def __init__(self, *args, **kwargs):
            pass

        def __enter__(self):
            return fake_mesh

        def __exit__(self, exc_type, exc, tb):
            return False

    return _FakeFaceMeshCM


# --- Helpers --------------------------------------------------------------

def _centered_face(cx=0.5, cy=0.5, spread=0.1, n=8):
    offsets = np.linspace(-spread, spread, n)
    return _FakeFaceLandmarks([_FakeLandmark(cx + o, cy + o) for o in offsets])


def _patch_mediapipe(monkeypatch, fake_mesh):
    """Replace the `mediapipe` module attribute access in
    `privacy_engine.camera_scan` with a tiny stand-in that has
    `solutions.face_mesh.FaceMesh` -> _FakeFaceMeshCM."""
    class _FakeSolutions:
        class face_mesh:
            FaceMesh = _make_fake_face_mesh_class(fake_mesh)

    class _FakeMediapipe:
        solutions = _FakeSolutions

    monkeypatch.setattr(camera_scan_module, "mp", _FakeMediapipe())


def _monotonic_advancing(start: float = 0.0, step: float = 0.05):
    """Returns a `time_source` that returns start, then start+step,
    start+2*step, ... on every call -- so a duration_s=0.2 lets
    exactly 4 frames run before the deadline."""
    state = {"n": 0}

    def _t():
        v = start + state["n"] * step
        state["n"] += 1
        return v

    return _t


# --- scan_camera() unit tests --------------------------------------------

def test_scan_camera_no_faces_no_findings(monkeypatch):
    """Fake mesh returns no faces, fake capture returns a valid frame.
    scan_camera() should return an empty Finding list -- no unprotected-
    face finding because no faces were ever detected."""
    fake_mesh = _FakeMesh(faces=[])
    _patch_mediapipe(monkeypatch, fake_mesh)
    cap_factory = _FakeCaptureFactory()
    monkeypatch.setattr(camera_scan_module.cv2, "VideoCapture", cap_factory)

    config = CameraShieldConfig(max_faces=4)
    findings = camera_scan_module.scan_camera(
        config, duration_s=0.1, time_source=_monotonic_advancing(start=0.0, step=0.05),
    )
    assert findings == []
    # Camera source flowed through to the (fake) capture object.
    assert cap_factory.sources_seen == [0]


def test_scan_camera_dedups_unprotected_face_across_frames(monkeypatch):
    """3 faces with max_faces=1 should produce the same
    'unprotected face' finding on every frame, and the dedup in
    scan_camera() should collapse them to a single Finding."""
    fake_mesh = _FakeMesh(
        faces=[_centered_face(0.3, 0.3), _centered_face(0.6, 0.6), _centered_face(0.8, 0.2)],
    )
    _patch_mediapipe(monkeypatch, fake_mesh)
    monkeypatch.setattr(camera_scan_module.cv2, "VideoCapture", _FakeCaptureFactory())

    config = CameraShieldConfig(max_faces=1)
    findings = camera_scan_module.scan_camera(
        config, duration_s=0.5, time_source=_monotonic_advancing(start=0.0, step=0.05),
    )
    # Without dedup we'd get 10+ copies of the same finding (one per
    # frame). With dedup: exactly one.
    assert len(findings) == 1
    f = findings[0]
    assert f.source_module == "camera"
    assert f.category == "unprotected_face"
    assert f.severity == Severity.HIGH
    # `extra` came from the first frame we saw the condition on
    # (documented choice -- see camera_scan.py for why).
    assert f.extra == {"detected_faces": 3, "max_faces": 1}


def test_scan_camera_respects_duration(monkeypatch):
    """With time_source advancing in 0.05s steps and duration_s=0.2,
    exactly 4 frame iterations should run before the deadline."""
    fake_mesh = _FakeMesh(faces=[])
    _patch_mediapipe(monkeypatch, fake_mesh)

    # Wrap _FakeMesh in a counter so we can count process_frame calls.
    process_calls = {"n": 0}
    real_process = fake_mesh.process

    def counting_process(rgb):
        process_calls["n"] += 1
        return real_process(rgb)

    fake_mesh.process = counting_process
    monkeypatch.setattr(camera_scan_module.cv2, "VideoCapture", _FakeCaptureFactory())

    config = CameraShieldConfig(max_faces=4)
    camera_scan_module.scan_camera(
        config, duration_s=0.2, time_source=_monotonic_advancing(start=0.0, step=0.05),
    )
    # `deadline = time_source() + duration_s` consumes the very first
    # time_source() call (t=0) to compute deadline=0.2. The while-loop's
    # own checks then land on the *next* calls: 0.05, 0.10, 0.15 all
    # satisfy `< 0.2` (3 frames processed); the check at 0.20 does not
    # (0.20 < 0.20 is False), so the loop stops before a 4th frame.
    assert process_calls["n"] == 3


def test_scan_camera_rejects_zero_duration():
    """A defensive guard -- duration_s<=0 is meaningless and likely a
    caller bug, so we raise ValueError instead of silently returning
    nothing."""
    config = CameraShieldConfig()
    with pytest.raises(ValueError, match="duration_s must be positive"):
        camera_scan_module.scan_camera(config, 0.0)
    with pytest.raises(ValueError, match="duration_s must be positive"):
        camera_scan_module.scan_camera(config, -1.0)


def test_scan_camera_camera_open_failure_raises_runtime_error(monkeypatch):
    """If cv2.VideoCapture can't open the source, scan_camera should
    raise a clear RuntimeError -- same shape as CameraShield.run()'s
    error message so operators see consistent diagnostics across the
    two entry points."""

    class _ClosedCapture(_FakeCapture):
        def isOpened(self):
            return False

    class _ClosedFactory:
        def __call__(self, source):
            return _ClosedCapture(source)

    monkeypatch.setattr(camera_scan_module.cv2, "VideoCapture", _ClosedFactory())
    _patch_mediapipe(monkeypatch, _FakeMesh(faces=[]))

    config = CameraShieldConfig(source=9999)
    with pytest.raises(RuntimeError, match="Could not open camera source"):
        camera_scan_module.scan_camera(config, duration_s=0.1, time_source=lambda: 0.0)


def test_scan_camera_camera_open_failure_never_leaks_rtsp_credentials(monkeypatch):
    """Regression test: a wrong-password RTSP source must not put the
    password in the RuntimeError message -- that message commonly ends
    up in logs, terminal scrollback, or a pasted bug report."""

    class _ClosedCapture(_FakeCapture):
        def isOpened(self):
            return False

    class _ClosedFactory:
        def __call__(self, source):
            return _ClosedCapture(source)

    monkeypatch.setattr(camera_scan_module.cv2, "VideoCapture", _ClosedFactory())
    _patch_mediapipe(monkeypatch, _FakeMesh(faces=[]))

    config = CameraShieldConfig(source="rtsp://admin:hunter2@192.168.1.50/stream1")
    with pytest.raises(RuntimeError) as exc_info:
        camera_scan_module.scan_camera(config, duration_s=0.1, time_source=lambda: 0.0)

    message = str(exc_info.value)
    assert "admin" not in message
    assert "hunter2" not in message
    assert "192.168.1.50" in message  # host is still useful for debugging


def test_scan_camera_anonymization_mode_kwarg_validated(monkeypatch):
    """An invalid anonymization mode raises ValueError immediately,
    not a confusing downstream error inside CameraShield."""
    fake_mesh = _FakeMesh(faces=[])
    _patch_mediapipe(monkeypatch, fake_mesh)
    monkeypatch.setattr(camera_scan_module.cv2, "VideoCapture", _FakeCaptureFactory())

    config = CameraShieldConfig()
    with pytest.raises(ValueError, match="Unknown anonymization mode"):
        camera_scan_module.scan_camera(
            config, duration_s=0.1, mode="wibble",
            time_source=_monotonic_advancing(),
        )


def test_scan_camera_keyboard_interrupt_returns_partial_findings(monkeypatch):
    """A Ctrl+C mid-scan should return whatever was already observed,
    not raise. Real exposures observed so far are still real -- the
    aggregator should report on them."""
    fake_mesh = _FakeMesh(
        faces=[_centered_face(0.3, 0.3), _centered_face(0.7, 0.7)],
    )
    _patch_mediapipe(monkeypatch, fake_mesh)
    monkeypatch.setattr(camera_scan_module.cv2, "VideoCapture", _FakeCaptureFactory())

    config = CameraShieldConfig(max_faces=1)
    # 2 frames process normally, then KeyboardInterrupt on the 3rd.
    call_count = {"n": 0}

    def process_or_kbi(rgb):
        call_count["n"] += 1
        if call_count["n"] >= 3:
            raise KeyboardInterrupt
        return _FakeResults(fake_mesh._faces)

    fake_mesh.process = process_or_kbi

    findings = camera_scan_module.scan_camera(
        config, duration_s=10.0,  # long -- we'd never reach the deadline
        time_source=_monotonic_advancing(start=0.0, step=0.05),
    )
    # 2 frames saw the unprotected-face condition; dedup keeps one.
    assert len(findings) == 1
    assert findings[0].source_module == "camera"
    assert findings[0].category == "unprotected_face"


# --- CLI subcommand tests -------------------------------------------------

def test_camera_scan_cli_subcommand_text_renders_report(monkeypatch, capsys):
    """End-to-end: with scan_camera monkey-patched to return a known
    Finding list, the CLI should produce the same `Privacy Report /`
    shape as `report <path>` does."""
    sample_finding = Finding(
        category="unprotected_face",
        title="Face(s) detected but not anonymized",
        description="3 face(s) beyond max_faces limit",
        remediation="raise --max-faces",
        severity=Severity.HIGH,
        source_module="camera",
        extra={"detected_faces": 3, "max_faces": 1},
    )

    def fake_scan(config, duration_s, *, mode=None, time_source=None):
        assert duration_s == 0.1
        assert mode == "light"
        return [sample_finding]

    monkeypatch.setattr(cli_module, "scan_camera", fake_scan)

    rc = cli_module.main(["camera-scan", "--source", "0", "--duration", "0.1", "--max-faces", "1"])
    assert rc == 0
    out = capsys.readouterr().out
    assert "Privacy Report" in out
    assert "camera:" in out
    assert "Face(s) detected but not anonymized" in out
    assert "HIGH" in out
    assert "Overall Risk: High" in out


def test_camera_scan_cli_subcommand_json(monkeypatch, capsys):
    sample_finding = Finding(
        category="unprotected_face",
        title="Face(s) detected but not anonymized",
        description="3 face(s) beyond max_faces limit",
        remediation="raise --max-faces",
        severity=Severity.HIGH,
        source_module="camera",
        extra={"detected_faces": 3, "max_faces": 1},
    )

    def fake_scan(config, duration_s, *, mode=None, time_source=None):
        return [sample_finding]

    monkeypatch.setattr(cli_module, "scan_camera", fake_scan)

    rc = cli_module.main([
        "camera-scan", "--source", "0", "--duration", "0.1",
        "--max-faces", "1", "--json",
    ])
    assert rc == 0
    out = capsys.readouterr().out
    parsed = json.loads(out)
    assert parsed["risk_label"] == "High"
    assert parsed["score"] == 8
    assert parsed["finding_count"] == 1
    assert parsed["findings"][0]["source_module"] == "camera"
    assert parsed["findings"][0]["severity"] == "high"


def test_camera_scan_cli_subcommand_camera_open_error_exits_nonzero(monkeypatch, capsys):
    """When the camera can't be opened, the CLI prints a clean error
    to stderr and returns exit code 1 -- same shape as the existing
    `report <path>` "does not exist" error path."""

    def fake_scan(config, duration_s, *, mode=None, time_source=None):
        raise RuntimeError("Could not open camera source 9999. ...")

    monkeypatch.setattr(cli_module, "scan_camera", fake_scan)

    rc = cli_module.main(["camera-scan", "--source", "9999", "--duration", "0.1"])
    assert rc == 1
    err = capsys.readouterr().err
    assert "error:" in err
    assert "Could not open camera source" in err


def test_camera_scan_cli_help_lists_all_flags(capsys):
    """The --help output should expose every documented flag so users
    can discover them without reading the source. This is a small
    test, but it would catch a future 'someone renamed --duration
    to --length' regression that would silently break scripts."""
    with pytest.raises(SystemExit) as exc:
        cli_module.main(["camera-scan", "--help"])
    assert exc.value.code == 0
    out = capsys.readouterr().out
    for flag in ["--source", "--duration", "--mode", "--max-faces", "--config", "--json"]:
        assert flag in out, f"missing {flag} in --help output"
