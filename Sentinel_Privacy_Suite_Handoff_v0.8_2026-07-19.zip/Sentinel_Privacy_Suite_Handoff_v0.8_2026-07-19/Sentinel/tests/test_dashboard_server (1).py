"""Tests for dashboard/server.py.

Runs a real DashboardServer on 127.0.0.1 with an ephemeral port, against a
fake camera worker (no real camera/mediapipe involved -- this only tests
the HTTP routing, JSON shapes, and the file-scan panel's plumbing). The
fake worker only needs to satisfy the two things `_make_handler()` actually
uses: a `.frame_buffer` (a real `camera.stream_server.FrameBuffer`, so the
MJPEG route is genuinely exercised) and a `.snapshot()` method.
"""

from __future__ import annotations

import json
import sys
import urllib.error
import urllib.request
from pathlib import Path
from urllib.parse import quote

import numpy as np
import piexif
import pytest
from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from camera.stream_server import FrameBuffer
from dashboard.server import DashboardServer, warn_if_file_scan_exposed


class _FakeWorker:
    def __init__(self):
        self.frame_buffer = FrameBuffer()
        self.frame_buffer.update(np.full((16, 16, 3), 128, dtype=np.uint8))
        self._snapshot = {
            "running": True,
            "error": None,
            "mode": "light",
            "frame_count": 42,
            "uptime_s": 12.5,
            "report": {
                "score": 0,
                "risk_label": "None",
                "explanation": "No metadata or exposure indicators were detected in what was scanned.",
                "finding_count": 0,
                "by_module_counts": {},
                "by_severity_counts": {},
                "findings": [],
            },
        }

    def snapshot(self) -> dict:
        return self._snapshot


@pytest.fixture
def running_dashboard():
    worker = _FakeWorker()
    server = DashboardServer(worker, host="127.0.0.1", port=0, jpeg_quality=80)
    server.start()
    yield server, worker
    server.stop()


def _get(url: str):
    return urllib.request.urlopen(url, timeout=5)


def _get_json(url: str) -> dict:
    with _get(url) as resp:
        return json.loads(resp.read())


# -- routing --------------------------------------------------------------

def test_index_serves_html(running_dashboard):
    server, _ = running_dashboard
    host, port = server.address
    with _get(f"http://{host}:{port}/") as resp:
        assert resp.status == 200
        assert "text/html" in resp.headers.get("Content-Type", "")
        body = resp.read()
        assert b"Sentinel Dashboard" in body
        assert b"/stream.mjpg" in body
        assert b"/api/status" in body
        assert b"/api/file-scan" in body


def test_stream_endpoint_serves_multipart_jpeg(running_dashboard):
    server, _ = running_dashboard
    host, port = server.address
    with _get(f"http://{host}:{port}/stream.mjpg") as resp:
        assert resp.status == 200
        assert "multipart/x-mixed-replace" in resp.headers.get("Content-Type", "")
        chunk = resp.read(4096)
        assert b"\xff\xd8" in chunk


def test_unknown_path_returns_404(running_dashboard):
    server, _ = running_dashboard
    host, port = server.address
    with pytest.raises(urllib.error.HTTPError) as exc_info:
        _get(f"http://{host}:{port}/nonexistent")
    assert exc_info.value.code == 404


# -- /api/status ------------------------------------------------------------

def test_api_status_returns_worker_snapshot(running_dashboard):
    server, worker = running_dashboard
    host, port = server.address
    data = _get_json(f"http://{host}:{port}/api/status")
    assert data == worker.snapshot()


# -- /api/file-scan ---------------------------------------------------------

def test_file_scan_missing_path_param(running_dashboard):
    server, _ = running_dashboard
    host, port = server.address
    data = _get_json(f"http://{host}:{port}/api/file-scan")
    assert "error" in data
    assert "path" in data["error"]


def test_file_scan_nonexistent_path(running_dashboard, tmp_path):
    server, _ = running_dashboard
    host, port = server.address
    missing = tmp_path / "does-not-exist.jpg"
    data = _get_json(f"http://{host}:{port}/api/file-scan?path={quote(str(missing))}")
    assert "error" in data
    assert "does not exist" in data["error"]


def test_file_scan_finds_gps_metadata(running_dashboard, tmp_path):
    server, _ = running_dashboard
    host, port = server.address

    img_path = tmp_path / "photo.jpg"
    img = Image.new("RGB", (20, 20), color="red")
    gps_ifd = {
        piexif.GPSIFD.GPSLatitudeRef: "N",
        piexif.GPSIFD.GPSLatitude: [(37, 1), (46, 1), (2964, 100)],
        piexif.GPSIFD.GPSLongitudeRef: "W",
        piexif.GPSIFD.GPSLongitude: [(122, 1), (25, 1), (1584, 100)],
    }
    img.save(img_path, "jpeg", exif=piexif.dump({"GPS": gps_ifd}))

    data = _get_json(f"http://{host}:{port}/api/file-scan?path={quote(str(img_path))}")
    assert "error" not in data
    assert data["path"] == str(img_path)
    assert data["report"]["finding_count"] >= 1
    assert any(f["category"] == "gps_metadata" for f in data["report"]["findings"])


def test_file_scan_clean_file_has_no_findings(running_dashboard, tmp_path):
    server, _ = running_dashboard
    host, port = server.address

    img_path = tmp_path / "clean.jpg"
    Image.new("RGB", (20, 20), color="blue").save(img_path, "jpeg")

    data = _get_json(f"http://{host}:{port}/api/file-scan?path={quote(str(img_path))}")
    assert data["report"]["finding_count"] == 0
    assert data["report"]["risk_label"] == "None"


# -- warn_if_file_scan_exposed() -------------------------------------------

def test_warn_if_file_scan_exposed_loopback_no_warning(caplog):
    with caplog.at_level("WARNING"):
        fired = warn_if_file_scan_exposed("127.0.0.1", 8090)
    assert fired is False
    assert caplog.records == []


def test_warn_if_file_scan_exposed_all_interfaces_warns(caplog):
    with caplog.at_level("WARNING"):
        fired = warn_if_file_scan_exposed("0.0.0.0", 8090)
    assert fired is True
    assert len(caplog.records) == 1
    message = caplog.records[0].getMessage()
    assert "ANY file or directory path" in message
