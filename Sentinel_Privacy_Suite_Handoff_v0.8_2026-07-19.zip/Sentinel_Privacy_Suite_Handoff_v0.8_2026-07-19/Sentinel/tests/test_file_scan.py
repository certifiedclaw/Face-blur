"""Tests for privacy_engine/file_scan.py -- the file/directory Finding
collector extracted from privacy_engine/cli.py so dashboard/server.py can
reuse the exact same scan logic the CLI's `report <path>` command uses.
"""

from __future__ import annotations

import sys
from pathlib import Path

import piexif
import pytest
from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from privacy_engine.file_scan import collect_file_findings


@pytest.fixture
def jpeg_with_gps(tmp_path) -> Path:
    img_path = tmp_path / "photo.jpg"
    img = Image.new("RGB", (20, 20), color="red")
    gps_ifd = {
        piexif.GPSIFD.GPSLatitudeRef: "N",
        piexif.GPSIFD.GPSLatitude: [(37, 1), (46, 1), (2964, 100)],
        piexif.GPSIFD.GPSLongitudeRef: "W",
        piexif.GPSIFD.GPSLongitude: [(122, 1), (25, 1), (1584, 100)],
    }
    exif_dict = {"0th": {piexif.ImageIFD.Make: b"TestCam"}, "GPS": gps_ifd}
    img.save(img_path, "jpeg", exif=piexif.dump(exif_dict))
    return img_path


@pytest.fixture
def jpeg_without_metadata(tmp_path) -> Path:
    img_path = tmp_path / "clean.jpg"
    Image.new("RGB", (20, 20), color="blue").save(img_path, "jpeg")
    return img_path


def test_single_file_with_findings(jpeg_with_gps):
    findings = collect_file_findings(jpeg_with_gps)
    assert len(findings) >= 1
    assert any(f.category == "gps_metadata" for f in findings)


def test_single_file_without_findings(jpeg_without_metadata):
    findings = collect_file_findings(jpeg_without_metadata)
    assert findings == []


def test_unsupported_file_type_returns_empty(tmp_path):
    p = tmp_path / "notes.txt"
    p.write_text("just some text, not a supported format")
    assert collect_file_findings(p) == []


def test_directory_aggregates_across_files(tmp_path, jpeg_with_gps, jpeg_without_metadata):
    # fixtures already write into tmp_path, so scanning tmp_path covers both.
    findings = collect_file_findings(tmp_path)
    assert any(f.category == "gps_metadata" for f in findings)


def test_directory_with_no_supported_files_returns_empty(tmp_path):
    (tmp_path / "readme.txt").write_text("hello")
    assert collect_file_findings(tmp_path) == []
