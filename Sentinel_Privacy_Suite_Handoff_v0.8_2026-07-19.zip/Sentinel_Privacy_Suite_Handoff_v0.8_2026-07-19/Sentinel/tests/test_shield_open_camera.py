"""Tests for CameraShield._open_camera()'s failure path.

Separate from privacy_engine/camera_scan.py's own camera-open failure
(tests/test_camera_scan.py) -- CameraShield._open_camera() is a distinct
code path (used by CameraShield.run(), the desktop/headless service
loop) that had the same raw-source-in-error-message bug and needed the
same fix + regression test.
"""

from __future__ import annotations

import pytest

from camera.shield import CameraShield, warn_if_stream_exposed
from config.settings import CameraShieldConfig


class _ClosedCapture:
    def __init__(self, source):
        self._source = source

    def isOpened(self):
        return False


class _ClosedFactory:
    def __call__(self, source):
        return _ClosedCapture(source)


def test_open_camera_failure_raises_runtime_error(monkeypatch):
    monkeypatch.setattr("camera.shield.cv2.VideoCapture", _ClosedFactory())
    shield = CameraShield(CameraShieldConfig(source=9999))
    with pytest.raises(RuntimeError, match="Could not open camera source"):
        shield._open_camera()


def test_open_camera_failure_never_leaks_rtsp_credentials(monkeypatch):
    """Regression test matching test_camera_scan.py's equivalent -- the
    same bug existed in this separate code path and needed the same fix."""
    monkeypatch.setattr("camera.shield.cv2.VideoCapture", _ClosedFactory())
    config = CameraShieldConfig(source="rtsp://admin:hunter2@192.168.1.50/stream1")
    shield = CameraShield(config)

    with pytest.raises(RuntimeError) as exc_info:
        shield._open_camera()

    message = str(exc_info.value)
    assert "admin" not in message
    assert "hunter2" not in message
    assert "192.168.1.50" in message


# -- warn_if_stream_exposed(): non-loopback MJPEG bind should warn --------

def test_warn_if_stream_exposed_loopback_no_warning(caplog):
    with caplog.at_level("WARNING"):
        fired = warn_if_stream_exposed("127.0.0.1", 8080)
    assert fired is False
    assert caplog.records == []


def test_warn_if_stream_exposed_localhost_no_warning(caplog):
    with caplog.at_level("WARNING"):
        fired = warn_if_stream_exposed("localhost", 8080)
    assert fired is False
    assert caplog.records == []


def test_warn_if_stream_exposed_all_interfaces_warns(caplog):
    with caplog.at_level("WARNING"):
        fired = warn_if_stream_exposed("0.0.0.0", 8080)
    assert fired is True
    assert len(caplog.records) == 1
    message = caplog.records[0].getMessage()
    assert "NO AUTHENTICATION" in message
    assert "0.0.0.0" in message
    assert "8080" in message


def test_warn_if_stream_exposed_lan_ip_warns(caplog):
    with caplog.at_level("WARNING"):
        fired = warn_if_stream_exposed("192.168.1.50", 9001)
    assert fired is True
    message = caplog.records[0].getMessage()
    assert "192.168.1.50" in message
    assert "9001" in message
