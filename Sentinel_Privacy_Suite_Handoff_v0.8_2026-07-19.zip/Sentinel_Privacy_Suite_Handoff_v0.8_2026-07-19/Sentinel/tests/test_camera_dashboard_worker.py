"""Tests for dashboard/camera_worker.py: CameraDashboardWorker's
start/stop/snapshot lifecycle against a fake camera + fake mediapipe mesh.

Same fake-mesh/fake-capture pattern as tests/test_camera_scan.py, just
exercising the "run until stop()" shape (a background thread) instead of
camera_scan's "run for duration_s" shape (a blocking call). No real
camera or mediapipe model is used; `time.sleep`-based polling (via
`_wait_for`) is used to synchronize with the background thread since,
unlike scan_camera's injectable `time_source`, a real thread's progress
can't be driven by a fake clock.
"""

from __future__ import annotations

import sys
import time
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import dashboard.camera_worker as worker_module
from config.settings import CameraShieldConfig


# --- Fakes (same shapes as tests/test_camera_scan.py) -----------------------

class _FakeLandmark:
    def __init__(self, x, y):
        self.x = x
        self.y = y


class _FakeFaceLandmarks:
    def __init__(self, landmarks):
        self.landmark = landmarks


class _FakeResults:
    def __init__(self, faces):
        self.multi_face_landmarks = faces or None


class _FakeMesh:
    def __init__(self, faces):
        self._faces = faces

    def process(self, rgb):
        return _FakeResults(self._faces)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False


def _make_fake_face_mesh_class(fake_mesh):
    class _FakeFaceMeshCM:
        def __init__(self, *args, **kwargs):
            pass

        def __enter__(self):
            return fake_mesh

        def __exit__(self, exc_type, exc, tb):
            return False

    return _FakeFaceMeshCM


def _patch_mediapipe(monkeypatch, fake_mesh):
    class _FakeSolutions:
        class face_mesh:
            FaceMesh = _make_fake_face_mesh_class(fake_mesh)

    class _FakeMediapipe:
        solutions = _FakeSolutions

    monkeypatch.setattr(worker_module, "mp", _FakeMediapipe())


class _FakeCapture:
    def __init__(self, source, frame=None):
        self._frame = frame if frame is not None else np.zeros((100, 100, 3), dtype=np.uint8)
        self._released = False

    def isOpened(self):
        return True

    def get(self, prop):
        if prop == 3:  # CAP_PROP_FRAME_WIDTH
            return self._frame.shape[1]
        if prop == 4:  # CAP_PROP_FRAME_HEIGHT
            return self._frame.shape[0]
        return 0

    def read(self):
        # A tiny sleep so the background thread doesn't busy-spin a full
        # CPU core while tests wait for a handful of iterations.
        time.sleep(0.01)
        if self._released:
            return False, None
        return True, self._frame.copy()

    def release(self):
        self._released = True


class _FakeCaptureFactory:
    def __init__(self, frame=None):
        self._frame = frame

    def __call__(self, source):
        return _FakeCapture(source, frame=self._frame)


class _ClosedCapture(_FakeCapture):
    def isOpened(self):
        return False


class _ClosedFactory:
    def __call__(self, source):
        return _ClosedCapture(source)


def _centered_face(cx=0.5, cy=0.5, spread=0.1, n=8):
    offsets = np.linspace(-spread, spread, n)
    return _FakeFaceLandmarks([_FakeLandmark(cx + o, cy + o) for o in offsets])


def _wait_for(predicate, timeout=2.0, interval=0.02) -> bool:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if predicate():
            return True
        time.sleep(interval)
    return False


# --- tests ------------------------------------------------------------------

def test_worker_not_running_before_start():
    worker = worker_module.CameraDashboardWorker(CameraShieldConfig())
    assert worker.running is False
    snap = worker.snapshot()
    assert snap["running"] is False
    assert snap["frame_count"] == 0
    assert snap["error"] is None


def test_worker_runs_and_updates_frame_buffer(monkeypatch):
    _patch_mediapipe(monkeypatch, _FakeMesh(faces=[]))
    monkeypatch.setattr(worker_module.cv2, "VideoCapture", _FakeCaptureFactory())

    worker = worker_module.CameraDashboardWorker(CameraShieldConfig())
    worker.start()
    try:
        assert _wait_for(lambda: worker.frame_buffer.get_jpeg() is not None)
        assert worker.running is True
        assert _wait_for(lambda: worker.snapshot()["frame_count"] > 0)
    finally:
        worker.stop()

    assert worker.running is False


def test_worker_snapshot_reflects_live_findings(monkeypatch):
    fake_mesh = _FakeMesh(
        faces=[_centered_face(0.3, 0.3), _centered_face(0.6, 0.6), _centered_face(0.8, 0.2)],
    )
    _patch_mediapipe(monkeypatch, fake_mesh)
    monkeypatch.setattr(worker_module.cv2, "VideoCapture", _FakeCaptureFactory())

    config = CameraShieldConfig(max_faces=1)
    worker = worker_module.CameraDashboardWorker(config)
    worker.start()
    try:
        assert _wait_for(lambda: worker.snapshot()["report"]["finding_count"] > 0)
        snap = worker.snapshot()
        assert snap["report"]["risk_label"] == "High"
        assert any(f["category"] == "unprotected_face" for f in snap["report"]["findings"])
        assert all(f["source_module"] == "camera" for f in snap["report"]["findings"])
    finally:
        worker.stop()


def test_worker_camera_open_failure_sets_error(monkeypatch):
    monkeypatch.setattr(worker_module.cv2, "VideoCapture", _ClosedFactory())
    worker = worker_module.CameraDashboardWorker(CameraShieldConfig(source=9999))
    worker.start()
    try:
        assert _wait_for(lambda: worker.snapshot()["error"] is not None)
        snap = worker.snapshot()
        assert "Could not open camera source" in snap["error"]
    finally:
        worker.stop()


def test_worker_camera_open_failure_never_leaks_rtsp_credentials(monkeypatch):
    monkeypatch.setattr(worker_module.cv2, "VideoCapture", _ClosedFactory())
    config = CameraShieldConfig(source="rtsp://admin:hunter2@192.168.1.50/stream1")
    worker = worker_module.CameraDashboardWorker(config)
    worker.start()
    try:
        assert _wait_for(lambda: worker.snapshot()["error"] is not None)
        err = worker.snapshot()["error"]
        assert "admin" not in err
        assert "hunter2" not in err
        assert "192.168.1.50" in err
    finally:
        worker.stop()


def test_worker_invalid_mode_raises_immediately():
    with pytest.raises(ValueError, match="Unknown anonymization mode"):
        worker_module.CameraDashboardWorker(CameraShieldConfig(), mode="wibble")


def test_worker_stop_is_idempotent(monkeypatch):
    _patch_mediapipe(monkeypatch, _FakeMesh(faces=[]))
    monkeypatch.setattr(worker_module.cv2, "VideoCapture", _FakeCaptureFactory())
    worker = worker_module.CameraDashboardWorker(CameraShieldConfig())
    worker.start()
    assert _wait_for(lambda: worker.snapshot()["frame_count"] > 0)
    worker.stop()
    worker.stop()  # must not raise or hang
    assert worker.running is False


def test_worker_restart_after_stop(monkeypatch):
    _patch_mediapipe(monkeypatch, _FakeMesh(faces=[]))
    monkeypatch.setattr(worker_module.cv2, "VideoCapture", _FakeCaptureFactory())
    worker = worker_module.CameraDashboardWorker(CameraShieldConfig())

    worker.start()
    assert _wait_for(lambda: worker.snapshot()["frame_count"] > 0)
    worker.stop()
    assert worker.running is False

    worker.start()
    try:
        assert _wait_for(lambda: worker.snapshot()["frame_count"] > 0)
    finally:
        worker.stop()
