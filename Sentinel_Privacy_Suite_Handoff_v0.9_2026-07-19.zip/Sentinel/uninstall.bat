@echo off
setlocal
cd /d "%~dp0"

echo ============================================
echo  Sentinel Privacy Suite - Uninstaller
echo ============================================
echo.
echo This deletes ONLY the virtual environment folder:
echo   %cd%\.venv
echo.
echo It does not touch the Sentinel source code, your requirements.txt,
echo any config files, or anything outside this folder. It also does not
echo touch your system-wide Python install -- everything installed by
echo install.bat lived inside .venv.
echo.

if not exist ".venv" (
    echo No .venv folder found here -- there is nothing to remove.
    pause
    exit /b 0
)

choice /C YN /M "Delete .venv now"
if errorlevel 2 (
    echo Cancelled -- nothing was removed.
    pause
    exit /b 0
)

rmdir /s /q ".venv"
if exist ".venv" (
    echo [ERROR] Could not fully remove .venv -- it may be in use.
    echo Close any running Sentinel/Python processes and try again.
    pause
    exit /b 1
)

echo .venv removed. Run install.bat again any time to reinstall.
pause
