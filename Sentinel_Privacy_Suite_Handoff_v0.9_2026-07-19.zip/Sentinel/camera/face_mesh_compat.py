"""Compatibility shim: wraps `mediapipe.tasks.vision.FaceLandmarker` (the
current API) so it exposes the same interface as the deprecated
`mediapipe.solutions.face_mesh.FaceMesh` (the legacy API this codebase was
originally built against).

Why a shim instead of rewriting the callers
--------------------------------------------
The legacy `solutions` API is gone from mediapipe releases >=0.10.30 (see
DEPENDENCY_REPORT.md), and 0.10.21 -- the last version with `solutions` --
has no wheel for Python 3.13+, which is what actually forces the version
pin this module exists to remove.

The straightforward migration would rewrite `camera/shield.py`'s
`process_frame()` and every test's fake-mesh object to match the Tasks
API's different result shape (`result.face_landmarks` is a bare list of
landmark lists, not an object with `.multi_face_landmarks[i].landmark`).
That touches the most heavily-tested code in the project for no functional
gain -- the landmark data is identical, only the container shape differs.

Instead, `FaceMeshCompat` below does the real Tasks API work (model
loading, `detect_for_video`, monotonic timestamps) but returns a result
object shaped exactly like the legacy API's: `.multi_face_landmarks` is a
list of objects with a `.landmark` attribute, each entry having `.x`/`.y`/
`.z` -- verified against the actual installed Tasks API types (see
CHANGELOG.md v0.9 entry for how this was checked). `process_frame()` and
every existing fake-mesh test needed zero changes.
"""

from __future__ import annotations

import os
from dataclasses import dataclass


class ModelNotFoundError(RuntimeError):
    pass


@dataclass
class _CompatLandmarkList:
    """Mimics the legacy API's per-face landmark container: has `.landmark`,
    an iterable of objects with `.x`/`.y`/`.z`. The Tasks API's own
    NormalizedLandmark objects already have `.x`/`.y`/`.z` directly (checked
    against the installed package's type signature), so this wrapper only
    needs to supply the missing outer `.landmark` attribute -- it does not
    need to re-wrap each individual landmark."""

    landmark: list


@dataclass
class _CompatResult:
    """Mimics the legacy API's result object: has `.multi_face_landmarks`."""

    multi_face_landmarks: list | None


class FaceMeshCompat:
    """Drop-in replacement for `mp.solutions.face_mesh.FaceMesh` backed by
    `mediapipe.tasks.vision.FaceLandmarker`.

    Usage (identical to the legacy API):
        with FaceMeshCompat(model_path, max_num_faces=4, ...) as mesh:
            result = mesh.process(rgb_frame)
            if result.multi_face_landmarks:
                for face in result.multi_face_landmarks:
                    for point in face.landmark:
                        ... point.x, point.y, point.z ...
    """

    def __init__(
        self,
        model_path: str,
        max_num_faces: int = 4,
        min_detection_confidence: float = 0.5,
        min_tracking_confidence: float = 0.5,
    ):
        if not os.path.isfile(model_path):
            raise ModelNotFoundError(
                f"Face landmark model not found at {model_path!r}. This file "
                "isn't bundled with the repo (it's a multi-MB binary asset). "
                "Download face_landmarker.task from the MediaPipe model zoo "
                "(see README.md 'Setup') and place it at that path, or point "
                "--face-model / config face_model_path at wherever you put it."
            )

        # Imported lazily so importing this module doesn't require mediapipe
        # to be importable at all call sites that don't actually use it
        # (mirrors how pyvirtualcam is imported lazily in camera/shield.py).
        import mediapipe as mp
        from mediapipe.tasks import python as mp_tasks_python
        from mediapipe.tasks.python import vision as mp_tasks_vision

        self._mp = mp
        base_options = mp_tasks_python.BaseOptions(model_asset_path=model_path)
        options = mp_tasks_vision.FaceLandmarkerOptions(
            base_options=base_options,
            running_mode=mp_tasks_vision.RunningMode.VIDEO,
            num_faces=max_num_faces,
            min_face_detection_confidence=min_detection_confidence,
            min_face_presence_confidence=min_detection_confidence,
            min_tracking_confidence=min_tracking_confidence,
            output_face_blendshapes=False,
            output_facial_transformation_matrixes=False,
        )
        self._detector = mp_tasks_vision.FaceLandmarker.create_from_options(options)
        # VIDEO running mode requires strictly increasing timestamps across
        # calls -- a simple counter is sufficient since we don't need these
        # to correspond to real wall-clock time, only to increase monotonically.
        self._timestamp_ms = 0

    def process(self, rgb_frame) -> _CompatResult:
        mp_image = self._mp.Image(image_format=self._mp.ImageFormat.SRGB, data=rgb_frame)
        self._timestamp_ms += 1
        result = self._detector.detect_for_video(mp_image, self._timestamp_ms)

        if not result.face_landmarks:
            return _CompatResult(multi_face_landmarks=None)

        multi_face_landmarks = [_CompatLandmarkList(landmark=face) for face in result.face_landmarks]
        return _CompatResult(multi_face_landmarks=multi_face_landmarks)

    def close(self) -> None:
        self._detector.close()

    def __enter__(self) -> "FaceMeshCompat":
        return self

    def __exit__(self, *exc_info) -> None:
        self.close()
