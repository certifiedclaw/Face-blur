"""Lightweight MJPEG HTTP stream server for headless/homelab deployments.

Not a replacement for a real streaming stack (go2rtc, ffmpeg+RTSP, Frigate,
etc) -- this is intentionally minimal (stdlib `http.server` only, no Flask/
FastAPI dependency) so a headless box can expose the *already-anonymized*
Camera Shield output on the local network without needing a display server
or a virtual-camera driver, neither of which exist on a homelab server.

View it at http://<host>:<port>/ in any browser on the same network, or
pull http://<host>:<port>/stream.mjpg directly (e.g. as an <img> src, or
into something like Home Assistant's generic MJPEG camera integration).
"""

from __future__ import annotations

import logging
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import cv2
import numpy as np

logger = logging.getLogger(__name__)

_BOUNDARY = "sentinelframe"


class FrameBuffer:
    """Thread-safe holder for the most recently processed frame.

    The capture loop calls `update()` once per frame; any number of HTTP
    client threads call `get_jpeg()` concurrently. Kept deliberately dumb
    (last-write-wins, no queue) -- clients always want the *latest* frame,
    not a backlog, for a live view.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._frame: np.ndarray | None = None

    def update(self, frame: np.ndarray) -> None:
        with self._lock:
            self._frame = frame

    def get_jpeg(self, quality: int = 80) -> bytes | None:
        with self._lock:
            frame = None if self._frame is None else self._frame.copy()
        if frame is None:
            return None
        ok, buf = cv2.imencode(".jpg", frame, [int(cv2.IMWRITE_JPEG_QUALITY), quality])
        if not ok:
            return None
        return buf.tobytes()


def _make_handler(buffer: FrameBuffer, jpeg_quality: int):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, fmt: str, *args) -> None:
            # Route access logs through our logger instead of stderr.
            logger.debug("%s - %s", self.address_string(), fmt % args)

        def do_GET(self) -> None:  # noqa: N802 - stdlib method name
            if self.path in ("/", "/index.html"):
                self._serve_index()
            elif self.path in ("/stream", "/stream.mjpg"):
                self._serve_stream()
            else:
                self.send_response(404)
                self.end_headers()

        def _serve_index(self) -> None:
            body = (
                b"<!doctype html><html><head><title>Sentinel Camera Shield</title></head>"
                b"<body style='margin:0;background:#000'>"
                b"<img src='/stream.mjpg' style='width:100%;display:block'></body></html>"
            )
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def _serve_stream(self) -> None:
            self.send_response(200)
            self.send_header("Age", "0")
            self.send_header("Cache-Control", "no-cache, private")
            self.send_header("Pragma", "no-cache")
            self.send_header("Content-Type", f"multipart/x-mixed-replace; boundary={_BOUNDARY}")
            self.end_headers()
            try:
                while True:
                    jpeg = buffer.get_jpeg(jpeg_quality)
                    if jpeg is None:
                        continue
                    self.wfile.write(f"--{_BOUNDARY}\r\n".encode())
                    self.wfile.write(b"Content-Type: image/jpeg\r\n")
                    self.wfile.write(f"Content-Length: {len(jpeg)}\r\n\r\n".encode())
                    self.wfile.write(jpeg)
                    self.wfile.write(b"\r\n")
            except (BrokenPipeError, ConnectionResetError):
                logger.debug("Stream client disconnected: %s", self.client_address)

    return Handler


class MjpegStreamServer:
    """Runs a ThreadingHTTPServer serving `FrameBuffer` as MJPEG in a
    background thread, so it never blocks the capture/anonymization loop."""

    def __init__(
        self,
        buffer: FrameBuffer,
        host: str = "0.0.0.0",
        port: int = 8080,
        jpeg_quality: int = 80,
    ) -> None:
        self._buffer = buffer
        self._server = ThreadingHTTPServer((host, port), _make_handler(buffer, jpeg_quality))
        self._thread: threading.Thread | None = None

    @property
    def address(self) -> tuple[str, int]:
        return self._server.server_address[:2]

    def start(self) -> None:
        self._thread = threading.Thread(target=self._server.serve_forever, daemon=True)
        self._thread.start()
        host, port = self.address
        logger.info("MJPEG stream available at http://%s:%s/", host or "0.0.0.0", port)

    def stop(self) -> None:
        self._server.shutdown()
        self._server.server_close()
        if self._thread is not None:
            self._thread.join(timeout=2)
