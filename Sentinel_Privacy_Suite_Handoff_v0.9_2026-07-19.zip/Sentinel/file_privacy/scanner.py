"""Scan files for privacy-relevant metadata, producing `Finding` objects."""

from __future__ import annotations

from pathlib import Path

from core.findings import Finding, Severity
from file_privacy.formats import docx as docx_fmt
from file_privacy.formats import images as image_fmt
from file_privacy.formats import pdf as pdf_fmt

IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".tiff", ".tif"}
PNG_EXTENSIONS = {".png"}
PDF_EXTENSIONS = {".pdf"}
DOCX_EXTENSIONS = {".docx"}


class UnsupportedFileType(ValueError):
    pass


def detect_format(path: str | Path) -> str:
    ext = Path(path).suffix.lower()
    if ext in IMAGE_EXTENSIONS:
        return "image"
    if ext in PNG_EXTENSIONS:
        return "png"
    if ext in PDF_EXTENSIONS:
        return "pdf"
    if ext in DOCX_EXTENSIONS:
        return "docx"
    raise UnsupportedFileType(f"No scanner for file extension '{ext}'")


def scan_file(path: str | Path) -> list[Finding]:
    """Scan a single file and return a list of Findings. Raises
    UnsupportedFileType for formats not yet handled (see ROADMAP.md)."""
    path = Path(path)
    fmt = detect_format(path)
    findings: list[Finding] = []

    if fmt == "image":
        exif = image_fmt.read_exif(path)
        if exif["gps"]:
            lat, lon = exif["gps"]["lat"], exif["gps"]["lon"]
            findings.append(
                Finding(
                    category="gps_metadata",
                    title="GPS coordinates found in photo",
                    description=(
                        f"This image embeds a precise location ({lat:.5f}, {lon:.5f}), "
                        "often the exact spot the photo was taken -- frequently home, "
                        "work, or a place visited regularly."
                    ),
                    remediation="Strip EXIF metadata before sharing this photo.",
                    severity=Severity.HIGH,
                    source_module="file_privacy",
                    location=str(path),
                    extra={"lat": lat, "lon": lon},
                )
            )
        for tag, value in exif["tags"].items():
            severity = Severity.MEDIUM if tag in ("Artist", "Copyright") else Severity.LOW
            findings.append(
                Finding(
                    category="image_metadata",
                    title=f"{tag} metadata present",
                    description=f"EXIF tag '{tag}' = {value!r}. "
                                 f"({image_fmt.NOTABLE_TAGS.get(tag, 'metadata field')})",
                    remediation="Strip EXIF metadata before sharing this photo.",
                    severity=severity,
                    source_module="file_privacy",
                    location=str(path),
                    extra={"tag": tag, "value": str(value)},
                )
            )

    elif fmt == "png":
        meta = image_fmt.read_png_metadata(path)
        if meta["gps"]:
            lat, lon = meta["gps"]["lat"], meta["gps"]["lon"]
            findings.append(
                Finding(
                    category="gps_metadata",
                    title="GPS coordinates found in photo",
                    description=(
                        f"This image embeds a precise location ({lat:.5f}, {lon:.5f}), "
                        "often the exact spot the photo was taken -- frequently home, "
                        "work, or a place visited regularly."
                    ),
                    remediation="Strip metadata before sharing this photo.",
                    severity=Severity.HIGH,
                    source_module="file_privacy",
                    location=str(path),
                    extra={"lat": lat, "lon": lon},
                )
            )
        for tag, value in meta["tags"].items():
            label = image_fmt.NOTABLE_TAGS.get(tag) or image_fmt.NOTABLE_PNG_TEXT_KEYS.get(tag, "metadata field")
            severity = Severity.MEDIUM if tag in ("Author", "Comment") else Severity.LOW
            findings.append(
                Finding(
                    category="image_metadata",
                    title=f"{tag} metadata present",
                    description=f"PNG metadata '{tag}' = {value!r}. ({label})",
                    remediation="Strip metadata before sharing this photo.",
                    severity=severity,
                    source_module="file_privacy",
                    location=str(path),
                    extra={"tag": tag, "value": str(value)},
                )
            )

    elif fmt == "pdf":
        meta = pdf_fmt.read_pdf_metadata(path)
        for key, value in meta.items():
            severity = Severity.MEDIUM if key in ("Author", "Company") else Severity.LOW
            findings.append(
                Finding(
                    category="pdf_metadata",
                    title=f"{key} metadata present",
                    description=f"PDF Info field '{key}' = {value!r}. "
                                 f"({pdf_fmt.NOTABLE_KEYS.get('/' + key, 'metadata field')})",
                    remediation="Strip PDF metadata before sharing this document.",
                    severity=severity,
                    source_module="file_privacy",
                    location=str(path),
                    extra={"key": key, "value": value},
                )
            )

    elif fmt == "docx":
        meta = docx_fmt.read_docx_metadata(path)
        for key, value in meta.items():
            prefix, _, local = key.partition(":")
            severity = (
                Severity.MEDIUM
                if local in ("creator", "lastModifiedBy", "Company", "Manager")
                else Severity.LOW
            )
            if prefix == "app":
                label = docx_fmt.NOTABLE_APP_TAGS.get(local, "metadata field")
                description = f"DOCX app property '{key}' = {value!r}. ({label})"
            else:
                label = docx_fmt.NOTABLE_CORE_TAGS.get((prefix, local), "metadata field")
                description = f"DOCX core property '{key}' = {value!r}. ({label})"
            findings.append(
                Finding(
                    category="docx_metadata",
                    title=f"{key} metadata present",
                    description=description,
                    remediation="Strip document metadata before sharing this file.",
                    severity=severity,
                    source_module="file_privacy",
                    location=str(path),
                    extra={"key": key, "value": value},
                )
            )

    return findings


def scan_directory(path: str | Path, recursive: bool = True) -> dict[str, list[Finding]]:
    """Scan every supported file under a directory. Unsupported files are
    silently skipped (this is a scan of what we understand, not an error
    report on file types we don't support yet)."""
    path = Path(path)
    pattern = "**/*" if recursive else "*"
    results: dict[str, list[Finding]] = {}
    for file_path in sorted(path.glob(pattern)):
        if not file_path.is_file():
            continue
        try:
            detect_format(file_path)
        except UnsupportedFileType:
            continue
        results[str(file_path)] = scan_file(file_path)
    return results
