"""DOCX (Office Open XML) core-properties metadata: read and strip.

A .docx is a zip archive; author/title/company metadata lives in
`docProps/core.xml` (and sometimes `docProps/app.xml`). Implemented with the
stdlib `zipfile`/`xml.etree` instead of pulling in python-docx, since this is
the only thing needed from it and it avoids an lxml dependency.
"""

from __future__ import annotations

import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

CORE_PROPS_PATH = "docProps/core.xml"
APP_PROPS_PATH = "docProps/app.xml"

NAMESPACES = {
    "cp": "http://schemas.openxmlformats.org/package/2006/metadata/core-properties",
    "dc": "http://purl.org/dc/elements/1.1/",
    "dcterms": "http://purl.org/dc/terms/",
}

# (namespace prefix, local tag) -> human label
NOTABLE_CORE_TAGS = {
    ("dc", "creator"): "document author",
    ("cp", "lastModifiedBy"): "last editor name",
    ("dc", "title"): "document title",
    ("dc", "subject"): "document subject",
    ("dc", "description"): "document description",
    ("cp", "category"): "document category",
    ("dcterms", "created"): "creation timestamp",
    ("dcterms", "modified"): "last-modified timestamp",
}


APP_NAMESPACE = "http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"

# app.xml has no namespace prefix convention like core.xml's cp:/dc:/dcterms: --
# it's a flat element set in its own single namespace.
NOTABLE_APP_TAGS = {
    "Company": "organization name",
    "Manager": "manager/supervisor name",
}


def read_docx_metadata(path: str | Path) -> dict:
    path = Path(path)
    found: dict = {}
    with zipfile.ZipFile(path) as zf:
        names = zf.namelist()

        if CORE_PROPS_PATH in names:
            with zf.open(CORE_PROPS_PATH) as f:
                tree = ET.parse(f)
                root = tree.getroot()
                for (prefix, local), label in NOTABLE_CORE_TAGS.items():
                    el = root.find(f"{{{NAMESPACES[prefix]}}}{local}")
                    if el is not None and el.text:
                        found[f"{prefix}:{local}"] = el.text

        if APP_PROPS_PATH in names:
            with zf.open(APP_PROPS_PATH) as f:
                tree = ET.parse(f)
                root = tree.getroot()
                for local in NOTABLE_APP_TAGS:
                    el = root.find(f"{{{APP_NAMESPACE}}}{local}")
                    if el is not None and el.text:
                        found[f"app:{local}"] = el.text

    return found


def _clear_fields(xml_bytes: bytes, namespace: str, local_tags, use_prefix_map=None) -> bytes:
    """Parse an XML part, blank out text on the given tags, return re-serialized bytes."""
    import io

    root = ET.fromstring(xml_bytes)
    if use_prefix_map:
        for prefix, uri in use_prefix_map.items():
            ET.register_namespace(prefix, uri)
        for prefix, local in local_tags:
            el = root.find(f"{{{use_prefix_map[prefix]}}}{local}")
            if el is not None:
                el.text = ""
    else:
        for local in local_tags:
            el = root.find(f"{{{namespace}}}{local}")
            if el is not None:
                el.text = ""
    buf = io.BytesIO()
    ET.ElementTree(root).write(buf, xml_declaration=True, encoding="UTF-8")
    return buf.getvalue()


def strip_docx_metadata(path: str | Path, output_path: str | Path) -> None:
    """Write a copy of the docx with core.xml and app.xml text fields cleared.

    Leaves the XML structure intact (required tags stay present but empty)
    rather than deleting elements outright, which keeps the file valid for
    Word/LibreOffice.
    """
    path = Path(path)
    output_path = Path(output_path)

    with zipfile.ZipFile(path) as zin:
        names = zin.namelist()
        replacements = {}

        if CORE_PROPS_PATH in names:
            replacements[CORE_PROPS_PATH] = _clear_fields(
                zin.read(CORE_PROPS_PATH),
                namespace="",
                local_tags=list(NOTABLE_CORE_TAGS.keys()),
                use_prefix_map=NAMESPACES,
            )

        if APP_PROPS_PATH in names:
            replacements[APP_PROPS_PATH] = _clear_fields(
                zin.read(APP_PROPS_PATH),
                namespace=APP_NAMESPACE,
                local_tags=list(NOTABLE_APP_TAGS.keys()),
            )

        with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as zout:
            for item in zin.infolist():
                data = replacements.get(item.filename, zin.read(item.filename))
                zout.writestr(item, data)
