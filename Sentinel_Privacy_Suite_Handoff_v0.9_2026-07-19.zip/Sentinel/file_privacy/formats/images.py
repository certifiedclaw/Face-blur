"""Image (JPEG/TIFF) EXIF metadata: read and strip.

Uses Pillow. GPS tags get special handling since they're the highest-severity
find (they can pinpoint where a photo was taken, often the user's home).
"""

from __future__ import annotations

from pathlib import Path

from PIL import Image
from PIL.ExifTags import TAGS, GPSTAGS

# EXIF tags that are privacy-relevant beyond GPS. Not exhaustive -- these are
# the ones most likely to leak something the average user wouldn't expect.
NOTABLE_TAGS = {
    "Make": "camera manufacturer",
    "Model": "camera/phone model",
    "Software": "editing software / OS version",
    "DateTimeOriginal": "exact capture timestamp",
    "Artist": "camera owner name (if set)",
    "Copyright": "copyright/owner string",
    "BodySerialNumber": "camera serial number",
    "LensSerialNumber": "lens serial number",
}


def _convert_gps_coord(value, ref) -> float | None:
    try:
        degrees, minutes, seconds = value
        decimal = float(degrees) + float(minutes) / 60 + float(seconds) / 3600
        if ref in ("S", "W"):
            decimal = -decimal
        return decimal
    except Exception:
        return None


def read_exif(path: str | Path) -> dict:
    """Return a dict of decoded EXIF data: {"gps": {"lat":..,"lon":..} | None,
    "tags": {tag_name: value, ...}}. Returns {"gps": None, "tags": {}} if the
    file has no EXIF block (not an error -- most images legitimately don't)."""
    path = Path(path)
    result: dict = {"gps": None, "tags": {}}

    with Image.open(path) as img:
        exif = img.getexif()
        if not exif:
            return result

        gps_ifd = exif.get_ifd(0x8825) if hasattr(exif, "get_ifd") else {}
        for tag_id, value in exif.items():
            tag_name = TAGS.get(tag_id, str(tag_id))
            if tag_name in NOTABLE_TAGS:
                result["tags"][tag_name] = value

        if gps_ifd:
            gps_named = {GPSTAGS.get(k, k): v for k, v in gps_ifd.items()}
            lat = _convert_gps_coord(
                gps_named.get("GPSLatitude"), gps_named.get("GPSLatitudeRef")
            )
            lon = _convert_gps_coord(
                gps_named.get("GPSLongitude"), gps_named.get("GPSLongitudeRef")
            )
            if lat is not None and lon is not None:
                result["gps"] = {"lat": lat, "lon": lon}

    return result


# PNG text chunk keys (tEXt/iTXt/zTXt) that are privacy-relevant. PNG has no
# standard field list like EXIF -- these are the conventional keyword names
# tools commonly write (Pillow, ImageMagick, Photoshop, screenshot tools).
NOTABLE_PNG_TEXT_KEYS = {
    "Author": "image author",
    "Software": "editing software",
    "Comment": "free-text comment (may contain personal info)",
    "Description": "free-text description",
    "Creation Time": "capture/creation timestamp",
    "Source": "originating device/application",
    "Disclaimer": "may contain owner/organization info",
}


def read_png_metadata(path: str | Path) -> dict:
    """Return {"gps": ... | None, "tags": {...}} for a PNG.

    Modern PNGs can carry a real eXIf chunk (same GPS/EXIF as JPEG), which
    Pillow exposes via img.getexif() just like JPEG. Older-style PNG
    metadata lives in free-text tEXt/iTXt chunks with no fixed schema,
    exposed via img.info / img.text.
    """
    path = Path(path)
    result: dict = {"gps": None, "tags": {}}

    with Image.open(path) as img:
        # eXIf chunk, if present, behaves identically to JPEG EXIF.
        try:
            exif_result = read_exif(path)
            result["gps"] = exif_result["gps"]
            result["tags"].update(exif_result["tags"])
        except Exception:
            pass

        text_chunks = getattr(img, "text", None) or {}
        for key, value in {**img.info, **text_chunks}.items():
            if key in NOTABLE_PNG_TEXT_KEYS and isinstance(value, str):
                result["tags"][key] = value

    return result


def strip_png_metadata(path: str | Path, output_path: str | Path) -> None:
    """Write a copy of the PNG with EXIF and all text chunks removed."""
    path = Path(path)
    output_path = Path(output_path)
    with Image.open(path) as img:
        img.load()
        clean = Image.frombytes(img.mode, img.size, img.tobytes())
        clean.save(output_path, format="PNG")  # no pnginfo= means no text chunks written


def strip_exif(path: str | Path, output_path: str | Path) -> None:
    """Write a copy of the image with all EXIF metadata removed."""
    path = Path(path)
    output_path = Path(output_path)
    with Image.open(path) as img:
        img.load()
        clean = Image.frombytes(img.mode, img.size, img.tobytes())
        save_kwargs = {}
        if img.format == "JPEG":
            save_kwargs["quality"] = 95
        clean.save(output_path, format=img.format, **save_kwargs)
