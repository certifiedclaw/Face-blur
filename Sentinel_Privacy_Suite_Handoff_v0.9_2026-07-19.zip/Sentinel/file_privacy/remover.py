"""Dispatch metadata stripping to the right format handler."""

from __future__ import annotations

from pathlib import Path

from file_privacy.formats import docx as docx_fmt
from file_privacy.formats import images as image_fmt
from file_privacy.formats import pdf as pdf_fmt
from file_privacy.scanner import detect_format


def remove_metadata(path: str | Path, output_path: str | Path) -> None:
    """Write a metadata-stripped copy of `path` to `output_path`. Never
    modifies the original file in place -- privacy tools that silently
    overwrite the user's only copy of a file are a bad idea."""
    path = Path(path)
    output_path = Path(output_path)
    fmt = detect_format(path)

    if fmt == "image":
        image_fmt.strip_exif(path, output_path)
    elif fmt == "png":
        image_fmt.strip_png_metadata(path, output_path)
    elif fmt == "pdf":
        pdf_fmt.strip_pdf_metadata(path, output_path)
    elif fmt == "docx":
        docx_fmt.strip_docx_metadata(path, output_path)
