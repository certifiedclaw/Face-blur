@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

echo ============================================
echo  Sentinel Privacy Suite - Installer
echo ============================================
echo.
echo This creates a self-contained virtual environment in a ".venv"
echo folder right here, and installs the pinned dependencies from
echo requirements.txt into it. It does not touch anything outside
echo this folder, and does not require admin rights.
echo.

rem --- Find a Python interpreter ------------------------------------------
where py >nul 2>nul
if %ERRORLEVEL%==0 (
    set "PYLAUNCHER=py -3"
) else (
    where python >nul 2>nul
    if %ERRORLEVEL%==0 (
        set "PYLAUNCHER=python"
    ) else (
        echo [ERROR] Python was not found on PATH.
        echo.
        echo Install Python 3.9-3.12 from https://www.python.org/downloads/
        echo and make sure "Add python.exe to PATH" is checked during setup,
        echo then run this installer again.
        echo.
        echo ^(Python 3.13+ is not yet supported here: mediapipe==0.10.21,
        echo  which Camera Shield depends on, does not ship a Windows wheel
        echo  for it -- see DEPENDENCY_REPORT.md.^)
        pause
        exit /b 1
    )
)

echo Using: %PYLAUNCHER%
%PYLAUNCHER% --version
echo.

rem --- Warn (don't hard-block) if the Python version is outside the range
rem     mediapipe==0.10.21 actually ships wheels for on Windows -----------
%PYLAUNCHER% -c "import sys; raise SystemExit(0 if (3,9) <= sys.version_info[:2] <= (3,12) else 1)"
if errorlevel 1 (
    echo [WARNING] mediapipe==0.10.21 ^(a hard-pinned dependency, see
    echo DEPENDENCY_REPORT.md^) only publishes Windows wheels for Python
    echo 3.9 through 3.12. The Python above is outside that range, so
    echo installation below may fail when it reaches mediapipe.
    echo.
    choice /C YN /M "Continue anyway"
    if errorlevel 2 (
        echo Cancelled. Install a Python 3.9-3.12 and re-run install.bat.
        pause
        exit /b 1
    )
)

rem --- Create (or reuse) the virtual environment ---------------------------
if exist ".venv" (
    echo A .venv folder already exists here.
    choice /C YN /M "Delete it and create a completely fresh one"
    if not errorlevel 2 (
        echo Removing existing .venv ...
        rmdir /s /q ".venv"
    ) else (
        echo Keeping the existing .venv; dependencies will be reinstalled into it.
    )
)

if not exist ".venv\Scripts\python.exe" (
    echo.
    echo Creating virtual environment in .venv ...
    %PYLAUNCHER% -m venv .venv
)

if not exist ".venv\Scripts\python.exe" (
    echo [ERROR] Failed to create the virtual environment.
    pause
    exit /b 1
)

rem --- Install dependencies -------------------------------------------------
echo.
echo Installing dependencies into .venv ^(this can take a few minutes,
echo mediapipe/opencv are large^) ...
echo.
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto :install_failed

".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto :install_failed

".venv\Scripts\python.exe" -m pip check
if errorlevel 1 (
    echo.
    echo [WARNING] pip check reported a problem above. Camera Shield may
    echo still work -- see DEPENDENCY_REPORT.md -- but this is worth a look.
)

echo.
echo ============================================
echo  Install complete.
echo.
echo  Run Sentinel:        run.bat
echo  Run a quick sanity check ^(no camera needed^): run.bat --help
echo  Remove everything:   uninstall.bat
echo ============================================
pause
exit /b 0

:install_failed
echo.
echo [ERROR] Dependency installation failed -- see the pip output above.
echo Nothing outside this folder was changed; you can safely delete the
echo .venv folder ^(or run uninstall.bat^) and try again.
pause
exit /b 1
