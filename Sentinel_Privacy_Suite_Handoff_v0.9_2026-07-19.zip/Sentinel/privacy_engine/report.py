"""Privacy Engine: aggregates `Finding`s from detection modules into a
human-readable risk report.

This is deliberately the *first, minimal* version of the module the project
spec calls the "flagship" -- it consumes `file_privacy`'s findings today.
Camera/audio/identity/network findings will plug in the same way once those
modules produce `Finding`s (see ROADMAP.md); nothing here is file_privacy-
specific except the module name strings used for grouping.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from core.findings import Finding, Severity

# Weight each severity contributes to the overall numeric risk score.
# Deliberately simple (sum of weights, thresholded) rather than a trained
# model -- the goal is an explainable score, not a precise one. See the
# `explanation` field on PrivacyReport for why a given score was reached.
SEVERITY_WEIGHT = {
    Severity.LOW: 1,
    Severity.MEDIUM: 3,
    Severity.HIGH: 8,
}

# Score thresholds -> overall risk label. Tuned so that a single HIGH-severity
# finding (e.g. one GPS leak) already reads as "High" risk on its own --
# a single precise location leak shouldn't be undersold as "Moderate" just
# because it's the only finding. Still intuition-based, not data-calibrated;
# flagged in ROADMAP.md as something to revisit once there's real usage to
# calibrate against.
RISK_THRESHOLDS = [
    (0, "None"),
    (1, "Low"),
    (3, "Moderate"),
    (8, "High"),
    (15, "Severe"),
]


@dataclass
class PrivacyReport:
    findings: list[Finding]
    score: int
    risk_label: str
    explanation: str
    by_module: dict[str, list[Finding]] = field(default_factory=dict)
    by_severity: dict[str, list[Finding]] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "score": self.score,
            "risk_label": self.risk_label,
            "explanation": self.explanation,
            "finding_count": len(self.findings),
            "by_module_counts": {k: len(v) for k, v in self.by_module.items()},
            "by_severity_counts": {k: len(v) for k, v in self.by_severity.items()},
            "findings": [f.to_dict() for f in self.findings],
        }

    def render_text(self) -> str:
        """Human-readable report matching the format sketched in the
        original project spec (Privacy Report / Face / Readable Text /
        Overall Risk / Explanation)."""
        lines = ["Privacy Report", "=" * 15, ""]
        if not self.findings:
            lines.append("No privacy-relevant findings detected.")
            lines.append(f"Overall Risk: {self.risk_label}")
            return "\n".join(lines)

        for module, module_findings in sorted(self.by_module.items()):
            lines.append(f"{module}:")
            for f in sorted(module_findings, key=lambda x: SEVERITY_WEIGHT[x.severity], reverse=True):
                lines.append(f"  [{f.severity.value.upper():6}] {f.title}")
                lines.append(f"           {f.description}")
                lines.append(f"           -> {f.remediation}")
            lines.append("")

        lines.append(f"Overall Risk: {self.risk_label} (score: {self.score})")
        lines.append(f"Explanation: {self.explanation}")
        return "\n".join(lines)


def _risk_label(score: int) -> str:
    label = RISK_THRESHOLDS[0][1]
    for threshold, name in RISK_THRESHOLDS:
        if score >= threshold:
            label = name
    return label


def _explain(findings: list[Finding], score: int, label: str) -> str:
    if not findings:
        return "No metadata or exposure indicators were detected in what was scanned."

    high = [f for f in findings if f.severity == Severity.HIGH]
    medium = [f for f in findings if f.severity == Severity.MEDIUM]
    low = [f for f in findings if f.severity == Severity.LOW]

    parts = []
    if high:
        parts.append(
            f"{len(high)} high-severity finding(s) ({', '.join(sorted({f.title for f in high}))}) "
            "on their own are enough to meaningfully identify or locate you."
        )
    if medium:
        parts.append(
            f"{len(medium)} medium-severity finding(s) add identifying details (names, "
            "organizations, editors) that narrow down who you are, especially combined "
            "with other findings."
        )
    if low and not (high or medium):
        parts.append(
            f"Only {len(low)} low-severity finding(s) were detected -- individually minor, "
            "but worth reviewing before sharing widely."
        )
    elif low:
        parts.append(
            f"{len(low)} additional low-severity finding(s) were detected; minor on their "
            "own but they compound the higher-severity findings above."
        )

    return " ".join(parts)


def build_report(findings: list[Finding]) -> PrivacyReport:
    """Aggregate a flat list of Findings (e.g. from file_privacy.scan_file or
    scan_directory, flattened) into a PrivacyReport."""
    by_module: dict[str, list[Finding]] = {}
    by_severity: dict[str, list[Finding]] = {}
    for f in findings:
        by_module.setdefault(f.source_module, []).append(f)
        by_severity.setdefault(f.severity.value, []).append(f)

    score = sum(SEVERITY_WEIGHT[f.severity] for f in findings)
    label = _risk_label(score)
    explanation = _explain(findings, score, label)

    return PrivacyReport(
        findings=findings,
        score=score,
        risk_label=label,
        explanation=explanation,
        by_module=by_module,
        by_severity=by_severity,
    )
