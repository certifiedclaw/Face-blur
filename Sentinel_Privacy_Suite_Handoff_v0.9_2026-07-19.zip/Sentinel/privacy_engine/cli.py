"""CLI entry point for Privacy Engine.

Usage:
    python -m privacy_engine.cli report <path> [--json]
    python -m privacy_engine.cli camera-scan [--source N|URL] [--duration S]
                                            [--mode light|warp|blur]
                                            [--max-faces N] [--config PATH]
                                            [--json]

`report` scans a file or directory with the file-based detection
modules (today: file_privacy) and prints an aggregated risk report.

`camera-scan` (v0.8) runs the Camera Shield for a bounded time window
and reports on the privacy findings observed in that live feed --
the live path counterpart to `report <path>`. See
`privacy_engine/camera_scan.py` for the implementation and
`ARCHITECTURE.md` for the design rationale.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from config.settings import CameraShieldConfig
from core.findings import Finding
from file_privacy.scanner import UnsupportedFileType, scan_directory, scan_file
from privacy_engine.camera_scan import scan_camera
from privacy_engine.report import build_report


def _collect_findings(path: Path) -> list[Finding]:
    if path.is_dir():
        results = scan_directory(path, recursive=True)
        findings: list[Finding] = []
        for file_findings in results.values():
            findings.extend(file_findings)
        return findings
    try:
        return scan_file(path)
    except UnsupportedFileType:
        return []


def cmd_report(args: argparse.Namespace) -> int:
    path = Path(args.path)
    if not path.exists():
        print(f"error: {path} does not exist", file=sys.stderr)
        return 1

    findings = _collect_findings(path)
    report = build_report(findings)

    if args.json:
        print(json.dumps(report.to_dict(), indent=2, default=str))
    else:
        print(report.render_text())
    return 0


def cmd_camera_scan(args: argparse.Namespace) -> int:
    """Live counterpart to `cmd_report`: run Camera Shield for
    `args.duration` seconds, dedup the per-frame findings, and render
    the same report shape as the file-based path.

    The camera-side config (source, max_faces, blur_ksize, etc.) goes
    through `CameraShieldConfig.from_args()` so a `--config` file
    works the same way as on `main.py`. The `anonymization mode` is
    the one knob that isn't in `CameraShieldConfig` (it's a runtime
    choice on the shield, cycled with SPACE in the desktop preview) --
    we hand it through to `scan_camera()` as a separate arg, which
    sets `CameraShield.mode_idx` directly. See ARCHITECTURE.md for
    why it stays out of the config dataclass for now.
    """
    argv: list[str] = []
    if args.config:
        argv += ["--config", args.config]
    argv += ["--source", str(args.source)]
    argv += ["--max-faces", str(args.max_faces)]
    # The camera-scan command is always a one-shot, so all deployment-
    # mode output channels (preview window, virtual cam, HTTP stream)
    # are forced off -- we want a clean short-lived scan, not a long-
    # running service. CameraShieldConfig still parses them from
    # from_args() with their normal defaults; the runtime doesn't
    # need to honor those defaults because scan_camera() never
    # calls CameraShield.run() (the loop is in camera_scan.py itself).
    config = CameraShieldConfig.from_args(argv)

    try:
        findings = scan_camera(config, args.duration, mode=args.mode)
    except (RuntimeError, ValueError) as e:
        print(f"error: {e}", file=sys.stderr)
        return 1

    report = build_report(findings)
    if args.json:
        print(json.dumps(report.to_dict(), indent=2, default=str))
    else:
        print(report.render_text())
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="privacy_engine", description="Aggregate privacy findings into a report")
    sub = parser.add_subparsers(dest="command", required=True)

    report_p = sub.add_parser("report", help="scan a file or directory and print a privacy risk report")
    report_p.add_argument("path", help="file or directory to scan")
    report_p.add_argument("--json", action="store_true", help="output machine-readable JSON instead of text")
    report_p.set_defaults(func=cmd_report)

    scan_p = sub.add_parser(
        "camera-scan",
        help="run Camera Shield for N seconds and report on what it observed "
             "(live counterpart to `report <path>`)",
    )
    scan_p.add_argument(
        "--source", type=str, default="0",
        help="camera source: a device index (e.g. 0) for a local/USB webcam, "
             "or a stream URL (e.g. rtsp://user:pass@host/stream) for a "
             "network/IP camera. Default: 0.",
    )
    scan_p.add_argument(
        "--duration", type=float, default=10.0,
        help="how long to sample the camera feed, in seconds (default 10).",
    )
    scan_p.add_argument(
        "--mode", choices=["light", "warp", "blur"], default="light",
        help="anonymization mode Camera Shield runs in during the scan "
             "(default: light). Note: this is the *anonymization* mode "
             "(how faces are scrambled), not the deployment mode.",
    )
    scan_p.add_argument(
        "--max-faces", type=int, default=4,
        help="max faces to scramble at once (default 4). Lower this to "
             "deliberately provoke the 'unprotected face' finding for "
             "diagnostic scans.",
    )
    scan_p.add_argument(
        "--config", type=str, default=None,
        help="optional JSON/YAML config file providing defaults for the "
             "camera-side settings (same format as main.py --config). "
             "Any flag you pass on the command line overrides the file.",
    )
    scan_p.add_argument(
        "--json", action="store_true",
        help="output machine-readable JSON instead of text.",
    )
    scan_p.set_defaults(func=cmd_camera_scan)

    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
