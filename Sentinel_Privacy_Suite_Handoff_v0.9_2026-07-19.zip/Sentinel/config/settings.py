"""Configuration for Camera Shield.

Centralizing settings here (instead of module-level globals scattered through
the pipeline) is what lets the dashboard, CLI, and future plugin system all
read/write the same config object.

v0.5: added `deployment_mode` so the same codebase runs two genuinely
different deployment shapes from one config, per the project's local-first
goal:

  desktop  : local USB webcam, on-screen preview window, output to a
             virtual webcam (pyvirtualcam) for use in Zoom/Meet/Discord.
             This is what v0.1-v0.4 assumed implicitly.

  headless : no display attached (a homelab box / server). Reads from a
             local device index *or* a network camera (RTSP/HTTP URL).
             Never touches cv2.imshow/waitKey (those need a display server
             and will error on a headless machine even if you don't look at
             the window). Serves the already-anonymized output as an MJPEG
             HTTP stream instead of a virtual webcam, since "virtual webcam
             on a headless box" isn't a meaningful concept -- nothing is
             video-calling from it.

`--mode` picks sensible defaults for preview/vcam/streaming; each of those
can still be forced on/off explicitly (e.g. `--mode desktop --stream` to
also expose an MJPEG feed from your desktop machine).
"""

from __future__ import annotations

import argparse
import json
from dataclasses import dataclass, fields
from enum import Enum
from pathlib import Path

try:
    import yaml
except ImportError:  # pragma: no cover - exercised only when PyYAML absent
    yaml = None


class DeploymentMode(str, Enum):
    DESKTOP = "desktop"
    HEADLESS = "headless"


class ConfigFileError(ValueError):
    """Raised for a malformed config file or one with unknown keys."""


def _config_field_names() -> set[str]:
    return {f.name for f in fields(CameraShieldConfig)}


def load_config_file(path: str | Path) -> dict:
    """Load a JSON or YAML config file into a plain dict of
    `CameraShieldConfig` field overrides.

    Unknown keys are rejected immediately rather than silently ignored --
    a typo'd key in a homelab config nobody looks at again is worse than a
    loud failure at startup. YAML support is optional: it only works if
    PyYAML happens to be installed (not a hard dependency of this project,
    see requirements.txt); JSON needs nothing extra and always works.
    """
    path = Path(path)
    if not path.is_file():
        raise ConfigFileError(f"Config file not found: '{path}'")

    text = path.read_text()
    suffix = path.suffix.lower()

    if suffix == ".json":
        try:
            data = json.loads(text)
        except json.JSONDecodeError as e:
            raise ConfigFileError(f"Malformed JSON in '{path}': {e}") from e
    elif suffix in (".yaml", ".yml"):
        if yaml is None:
            raise ConfigFileError(
                f"'{path}' is a YAML file but PyYAML is not installed. "
                "Install it (`pip install pyyaml`) or use a .json config "
                "file instead."
            )
        try:
            data = yaml.safe_load(text)
        except yaml.YAMLError as e:
            raise ConfigFileError(f"Malformed YAML in '{path}': {e}") from e
        data = data or {}
    else:
        raise ConfigFileError(
            f"Unrecognized config file extension '{suffix}' for '{path}'. "
            "Use .json, .yaml, or .yml."
        )

    if not isinstance(data, dict):
        raise ConfigFileError(
            f"Config file '{path}' must contain a top-level mapping/object, "
            f"got {type(data).__name__}."
        )

    unknown = set(data) - _config_field_names()
    if unknown:
        raise ConfigFileError(
            f"Unknown config key(s) in '{path}': {', '.join(sorted(unknown))}. "
            f"Valid keys: {', '.join(sorted(_config_field_names()))}."
        )

    return data


def _parse_source(raw: str) -> int | str:
    """A bare integer means a local device index (USB webcam). Anything
    else -- an RTSP/HTTP(S) URL, a `/dev/videoN`-style path -- is passed
    straight through: cv2.VideoCapture natively accepts either an int
    index or a string URL/path, so no further translation is needed."""
    try:
        return int(raw)
    except ValueError:
        return raw


def redact_source(source: int | str) -> str:
    """Return a version of `source` safe to log or include in an exception
    message.

    A network camera source can be `rtsp://user:pass@host/stream` --
    credentials embedded directly in the URL. Found and fixed this session:
    both the startup log line in main.py and the "could not open camera"
    RuntimeErrors in camera/shield.py and privacy_engine/camera_scan.py were
    including the raw source, which meant a misconfigured RTSP password
    would appear in plaintext in application logs and error messages/crash
    reports. Every place that logs or raises on `config.source` should go
    through this function instead of using the raw value directly.
    """
    if isinstance(source, int):
        return str(source)
    if "@" in source and "://" in source:
        scheme, _, rest = source.partition("://")
        _, _, host_and_path = rest.partition("@")
        return f"{scheme}://***:***@{host_and_path}"
    return source


@dataclass
class CameraShieldConfig:
    deployment_mode: DeploymentMode = DeploymentMode.DESKTOP

    # Camera source: int device index (USB webcam) or a string URL
    # (rtsp://... / http://... for a network/IP camera -- typical for a
    # homelab setup where the camera isn't physically in the server).
    source: int | str = 0

    block_size: int = 14
    blur_ksize: int = 35
    warp_strength: int = 40
    pad_fraction: float = 0.35
    feather_px: int = 18
    max_faces: int = 4
    smoothing_alpha: float = 0.5  # higher = less smoothing, more responsive
    min_detection_confidence: float = 0.5
    min_tracking_confidence: float = 0.5

    # Path to the MediaPipe Tasks .task model bundle used for face landmark
    # detection. Not bundled with this repo (it's a ~4-9MB binary asset) --
    # see README.md "Setup" for the download step. Defaults to the
    # conventional location under models/; override via --face-model or a
    # config file if you've put it elsewhere.
    face_model_path: str = "models/face_landmarker.task"

    # Output. Desktop mode defaults preview+vcam on / stream off; headless
    # mode defaults preview+vcam off / stream on. See from_args().
    show_preview: bool = True
    use_virtual_cam: bool = True
    http_stream: bool = False
    http_host: str = "0.0.0.0"
    http_port: int = 8080
    http_jpeg_quality: int = 80

    @classmethod
    def from_args(cls, argv: list[str] | None = None) -> "CameraShieldConfig":
        parser = argparse.ArgumentParser(description="Sentinel Camera Shield")
        parser.add_argument(
            "--config", type=str, default=None,
            help="path to a JSON or YAML file providing defaults for any of "
                 "the settings below, so you don't have to remember CLI "
                 "flags every run. Any flag passed explicitly on the "
                 "command line always overrides the config file.",
        )
        parser.add_argument(
            # Default None (not "desktop"): None means "not set on the CLI",
            # so a config file's `deployment_mode` can supply it instead --
            # see the merge logic below. "desktop" remains the ultimate
            # fallback if neither CLI nor config file specify a mode.
            "--mode", choices=["desktop", "headless"], default=None,
            help="desktop: local preview window + virtual webcam (default). "
                 "headless: no display; for a homelab/server box -- serves "
                 "anonymized video over HTTP MJPEG instead.",
        )
        parser.add_argument(
            "--source", type=str, default=None,
            help="camera source: a device index (e.g. 0) for a local/USB "
                 "webcam, or a stream URL (e.g. rtsp://user:pass@host/stream) "
                 "for a network/IP camera. Default: 0.",
        )
        parser.add_argument("--block", type=int, default=None, help="pixel block size")
        parser.add_argument("--warp", type=int, default=None, help="max warp displacement (px)")
        parser.add_argument("--pad", type=float, default=None, help="face box padding fraction")
        parser.add_argument("--feather", type=int, default=None, help="edge feather width in px, 0 to disable")
        parser.add_argument("--max-faces", type=int, default=None, help="max faces to scramble at once")
        parser.add_argument(
            "--face-model", type=str, default=None,
            help="path to the MediaPipe face_landmarker.task model bundle "
                 "(default: models/face_landmarker.task). See README.md "
                 "'Setup' for how to download it.",
        )

        # Tri-state (None = "use the mode default, or the config file, see
        # below") so --mode alone is enough to get sane behavior, but every
        # output can still be forced.
        parser.add_argument("--no-vcam", dest="vcam", action="store_false", default=None,
                             help="disable virtual camera (desktop mode only)")
        parser.add_argument("--vcam", dest="vcam", action="store_true", default=None,
                             help="force-enable virtual camera")
        parser.add_argument("--no-preview", dest="preview", action="store_false", default=None,
                             help="disable the local preview window (desktop mode only)")
        parser.add_argument("--preview", dest="preview", action="store_true", default=None,
                             help="force-enable the local preview window")
        parser.add_argument("--stream", dest="stream", action="store_true", default=None,
                             help="serve anonymized video over HTTP MJPEG "
                                  "(default: on in headless mode, off in desktop mode)")
        parser.add_argument("--no-stream", dest="stream", action="store_false", default=None,
                             help="disable HTTP MJPEG streaming")
        parser.add_argument("--http-host", type=str, default=None, help="MJPEG stream bind host")
        parser.add_argument("--http-port", type=int, default=None, help="MJPEG stream bind port")
        parser.add_argument("--http-quality", type=int, default=None, help="MJPEG JPEG quality (1-100)")

        args = parser.parse_args(argv)
        file_data: dict = load_config_file(args.config) if args.config else {}

        def pick(cli_value, key: str, default):
            """CLI flag (if explicitly passed) > config file value > hard default."""
            if cli_value is not None:
                return cli_value
            if key in file_data:
                return file_data[key]
            return default

        mode = DeploymentMode(pick(args.mode, "deployment_mode", "desktop"))

        if args.source is not None:
            source = _parse_source(args.source)
        elif "source" in file_data:
            raw_source = file_data["source"]
            # A config file can spell a device index as either a JSON/YAML
            # int (0) or a string ("0") -- normalize the same way the CLI
            # does. A URL always arrives as a string and passes through.
            source = _parse_source(str(raw_source)) if isinstance(raw_source, str) else raw_source
        else:
            source = 0

        block_size = pick(args.block, "block_size", 14)
        warp_strength = pick(args.warp, "warp_strength", 40)
        pad_fraction = pick(args.pad, "pad_fraction", 0.35)
        feather_px = pick(args.feather, "feather_px", 18)
        max_faces = pick(args.max_faces, "max_faces", 4)
        face_model_path = pick(args.face_model, "face_model_path", "models/face_landmarker.task")

        if mode == DeploymentMode.HEADLESS:
            # No display server on a homelab/server box: never default to
            # opening a preview window or a virtual webcam device -- both
            # assume a desktop session that isn't there.
            default_preview, default_vcam, default_stream = False, False, True
        else:
            default_preview, default_vcam, default_stream = True, True, False

        show_preview = pick(args.preview, "show_preview", default_preview)
        use_virtual_cam = pick(args.vcam, "use_virtual_cam", default_vcam)
        http_stream = pick(args.stream, "http_stream", default_stream)

        http_host = pick(args.http_host, "http_host", "0.0.0.0")
        http_port = pick(args.http_port, "http_port", 8080)
        http_jpeg_quality = pick(args.http_quality, "http_jpeg_quality", 80)

        return cls(
            deployment_mode=mode,
            source=source,
            block_size=block_size,
            warp_strength=warp_strength,
            pad_fraction=pad_fraction,
            feather_px=feather_px,
            max_faces=max_faces,
            face_model_path=face_model_path,
            # blur_ksize, smoothing_alpha, min_detection_confidence, and
            # min_tracking_confidence have no CLI flags -- config-file-only
            # overrides, falling back to the dataclass field defaults.
            blur_ksize=file_data.get("blur_ksize", 35),
            smoothing_alpha=file_data.get("smoothing_alpha", 0.5),
            min_detection_confidence=file_data.get("min_detection_confidence", 0.5),
            min_tracking_confidence=file_data.get("min_tracking_confidence", 0.5),
            show_preview=show_preview,
            use_virtual_cam=use_virtual_cam,
            http_stream=http_stream,
            http_host=http_host,
            http_port=http_port,
            http_jpeg_quality=http_jpeg_quality,
        )
