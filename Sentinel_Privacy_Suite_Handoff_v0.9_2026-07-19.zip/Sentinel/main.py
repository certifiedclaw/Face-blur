"""Sentinel Privacy Suite - entry point.

Currently launches Camera Shield directly. As identity_audit, file_privacy,
network, and the PyQt6 dashboard come online, this will route to a proper
CLI/dashboard chooser instead of assuming camera mode.
"""

from __future__ import annotations

import logging
import sys

from camera.shield import CameraShield
from config.settings import CameraShieldConfig, redact_source


def main() -> int:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    log = logging.getLogger(__name__)
    config = CameraShieldConfig.from_args()
    log.info(
        "Starting Camera Shield: mode=%s source=%s preview=%s vcam=%s http_stream=%s",
        config.deployment_mode.value, redact_source(config.source),
        config.show_preview, config.use_virtual_cam, config.http_stream,
    )
    if config.http_stream and config.http_host not in ("127.0.0.1", "localhost", "::1"):
        log.warning(
            "MJPEG stream server has no authentication and is binding to "
            "%s:%s, not just localhost -- anyone who can reach this host on "
            "the network can view the anonymized feed. This is fine on a "
            "trusted home LAN; do NOT port-forward this to the public "
            "internet. Use --http-host 127.0.0.1 to restrict it to this "
            "machine only.",
            config.http_host, config.http_port,
        )
    shield = CameraShield(config)
    try:
        shield.run()
    except RuntimeError as e:
        log.error(str(e))
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
