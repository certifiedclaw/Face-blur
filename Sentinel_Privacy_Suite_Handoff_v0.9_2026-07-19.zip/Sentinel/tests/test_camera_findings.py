"""Tests for CameraShield.process_frame()'s Finding emission -- the camera
module's contribution to privacy_engine's module-agnostic aggregation (see
ROADMAP.md 'Next': camera as the second real Finding producer).

Uses a fake mediapipe-shaped mesh (an object exposing .process() ->
an object with .multi_face_landmarks) instead of a real FaceMesh model, so
these tests don't need a camera or real inference -- only the geometry/
bookkeeping in process_frame() is under test here.
"""

from __future__ import annotations

import numpy as np

from camera.shield import CameraShield
from config.settings import CameraShieldConfig
from core.findings import Severity


class _FakeLandmark:
    def __init__(self, x: float, y: float):
        self.x = x
        self.y = y


class _FakeFaceLandmarks:
    def __init__(self, landmarks: list[_FakeLandmark]):
        self.landmark = landmarks


class _FakeResults:
    def __init__(self, faces: list[_FakeFaceLandmarks]):
        self.multi_face_landmarks = faces or None


class _FakeMesh:
    def __init__(self, faces: list[_FakeFaceLandmarks]):
        self._faces = faces

    def process(self, rgb):
        return _FakeResults(self._faces)


def _frame(h=100, w=100):
    return np.zeros((h, w, 3), dtype=np.uint8)


def _centered_face(cx=0.5, cy=0.5, spread=0.1, n=8):
    """A face whose landmarks form a small cluster around (cx, cy) in
    normalized [0,1] coordinates -- lands well inside the frame with a
    normal, non-degenerate bounding box."""
    offsets = np.linspace(-spread, spread, n)
    return _FakeFaceLandmarks([_FakeLandmark(cx + o, cy + o) for o in offsets])


def _corner_face():
    """All landmarks pinned to the exact top-left corner -- after padding
    and clamping this collapses to a zero-area box."""
    return _FakeFaceLandmarks([_FakeLandmark(0.0, 0.0) for _ in range(8)])


def test_no_faces_produces_no_findings():
    config = CameraShieldConfig(max_faces=4)
    shield = CameraShield(config)
    frame = _frame()
    out = shield.process_frame(frame, _FakeMesh([]), 100, 100)
    assert out.shape == frame.shape
    assert shield.get_findings() == []


def test_faces_within_limit_produce_no_unprotected_finding():
    config = CameraShieldConfig(max_faces=4)
    shield = CameraShield(config)
    faces = [_centered_face(0.3, 0.3), _centered_face(0.7, 0.7)]
    shield.process_frame(_frame(), _FakeMesh(faces), 100, 100)
    assert shield.get_findings() == []


def test_faces_beyond_max_faces_produce_high_finding():
    config = CameraShieldConfig(max_faces=1)
    shield = CameraShield(config)
    faces = [_centered_face(0.3, 0.3), _centered_face(0.6, 0.6), _centered_face(0.8, 0.2)]
    shield.process_frame(_frame(), _FakeMesh(faces), 100, 100)

    findings = shield.get_findings()
    unprotected = [f for f in findings if f.category == "unprotected_face" and f.severity == Severity.HIGH]
    assert len(unprotected) == 1
    assert unprotected[0].source_module == "camera"
    assert unprotected[0].extra == {"detected_faces": 3, "max_faces": 1}


def test_degenerate_box_produces_medium_finding_and_is_skipped():
    config = CameraShieldConfig(max_faces=4, pad_fraction=0.0)
    shield = CameraShield(config)
    faces = [_corner_face()]
    out = shield.process_frame(_frame(), _FakeMesh(faces), 100, 100)

    findings = shield.get_findings()
    degenerate = [f for f in findings if "degenerate box" in f.title]
    assert len(degenerate) == 1
    assert degenerate[0].severity == Severity.MEDIUM
    assert degenerate[0].source_module == "camera"
    # Frame is untouched since the only face was skipped, not scrambled.
    assert np.array_equal(out, _frame())


def test_get_findings_resets_between_frames():
    config = CameraShieldConfig(max_faces=1)
    shield = CameraShield(config)
    overflow_faces = [_centered_face(0.3, 0.3), _centered_face(0.6, 0.6)]
    shield.process_frame(_frame(), _FakeMesh(overflow_faces), 100, 100)
    assert shield.get_findings() != []

    # Next frame has no faces at all -- stale findings must not linger.
    shield.process_frame(_frame(), _FakeMesh([]), 100, 100)
    assert shield.get_findings() == []


def test_get_findings_returns_a_copy():
    config = CameraShieldConfig(max_faces=1)
    shield = CameraShield(config)
    faces = [_centered_face(0.3, 0.3), _centered_face(0.6, 0.6)]
    shield.process_frame(_frame(), _FakeMesh(faces), 100, 100)

    findings = shield.get_findings()
    findings.append("mutating the returned list should not affect internal state")
    assert len(shield.get_findings()) == 1
