import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from core.findings import Finding, Severity
from privacy_engine.report import build_report


def make_finding(severity, category="test_cat", source_module="file_privacy", title=None):
    return Finding(
        category=category,
        title=title or f"{category} finding",
        description="a test finding",
        remediation="do something about it",
        severity=severity,
        source_module=source_module,
        location="test.file",
    )


def test_empty_findings_zero_score_none_risk():
    report = build_report([])
    assert report.score == 0
    assert report.risk_label == "None"
    assert "No metadata" in report.explanation


def test_single_low_finding_low_risk():
    report = build_report([make_finding(Severity.LOW)])
    assert report.score == 1
    assert report.risk_label == "Low"


def test_single_high_finding_is_high_risk():
    report = build_report([make_finding(Severity.HIGH)])
    assert report.score == 8
    assert report.risk_label == "High"


def test_mixed_findings_score_sums_weights():
    findings = [
        make_finding(Severity.HIGH),   # 8
        make_finding(Severity.MEDIUM), # 3
        make_finding(Severity.LOW),    # 1
    ]
    report = build_report(findings)
    assert report.score == 12
    assert report.risk_label == "High"


def test_many_findings_reach_severe():
    findings = [make_finding(Severity.HIGH) for _ in range(3)]  # 24
    report = build_report(findings)
    assert report.risk_label == "Severe"


def test_grouping_by_module_and_severity():
    findings = [
        make_finding(Severity.HIGH, source_module="file_privacy"),
        make_finding(Severity.LOW, source_module="camera"),
    ]
    report = build_report(findings)
    assert set(report.by_module.keys()) == {"file_privacy", "camera"}
    assert len(report.by_module["file_privacy"]) == 1
    assert set(report.by_severity.keys()) == {"high", "low"}


def test_explanation_mentions_high_severity_when_present():
    report = build_report([make_finding(Severity.HIGH, title="GPS coordinates found in photo")])
    assert "high-severity" in report.explanation
    assert "GPS coordinates found in photo" in report.explanation


def test_explanation_low_only_says_minor():
    report = build_report([make_finding(Severity.LOW)])
    assert "low-severity" in report.explanation
    assert "minor" in report.explanation


def test_render_text_no_findings():
    text = build_report([]).render_text()
    assert "No privacy-relevant findings detected." in text
    assert "Overall Risk: None" in text


def test_render_text_includes_module_and_severity():
    findings = [make_finding(Severity.HIGH, source_module="file_privacy", title="GPS leak")]
    text = build_report(findings).render_text()
    assert "file_privacy:" in text
    assert "GPS leak" in text
    assert "HIGH" in text
    assert "Overall Risk:" in text


def test_to_dict_shape():
    findings = [make_finding(Severity.MEDIUM)]
    d = build_report(findings).to_dict()
    assert d["finding_count"] == 1
    assert d["score"] == 3
    assert d["risk_label"] == "Moderate"
    assert len(d["findings"]) == 1
    assert d["findings"][0]["severity"] == "medium"
