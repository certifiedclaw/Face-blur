import io
import sys
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

import piexif
import pytest
from pypdf import PdfWriter
from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from core.findings import Severity
from file_privacy.formats import docx as docx_fmt
from file_privacy.formats import images as image_fmt
from file_privacy.formats import pdf as pdf_fmt
from file_privacy.remover import remove_metadata
from file_privacy.scanner import UnsupportedFileType, detect_format, scan_file


# ---------- fixtures: build real files with real metadata ----------

@pytest.fixture
def jpeg_with_gps(tmp_path) -> Path:
    img_path = tmp_path / "photo.jpg"
    img = Image.new("RGB", (20, 20), color="red")

    def deg_to_dms_rational(deg_float):
        deg = int(deg_float)
        minutes_float = (deg_float - deg) * 60
        minutes = int(minutes_float)
        seconds = round((minutes_float - minutes) * 60 * 100)
        return [(deg, 1), (minutes, 1), (seconds, 100)]

    lat, lon = 37.7749, -122.4194
    gps_ifd = {
        piexif.GPSIFD.GPSLatitudeRef: "N",
        piexif.GPSIFD.GPSLatitude: deg_to_dms_rational(abs(lat)),
        piexif.GPSIFD.GPSLongitudeRef: "W",
        piexif.GPSIFD.GPSLongitude: deg_to_dms_rational(abs(lon)),
    }
    zeroth_ifd = {
        piexif.ImageIFD.Make: b"TestCam",
        piexif.ImageIFD.Model: b"TestModel X",
        piexif.ImageIFD.Software: b"TestOS 1.0",
    }
    exif_dict = {"0th": zeroth_ifd, "GPS": gps_ifd}
    exif_bytes = piexif.dump(exif_dict)
    img.save(img_path, "jpeg", exif=exif_bytes)
    return img_path


@pytest.fixture
def jpeg_without_metadata(tmp_path) -> Path:
    img_path = tmp_path / "clean.jpg"
    Image.new("RGB", (20, 20), color="blue").save(img_path, "jpeg")
    return img_path


@pytest.fixture
def pdf_with_metadata(tmp_path) -> Path:
    pdf_path = tmp_path / "doc.pdf"
    writer = PdfWriter()
    writer.add_blank_page(width=72, height=72)
    writer.add_metadata({"/Author": "Jane Tester", "/Producer": "TestSuite"})
    with open(pdf_path, "wb") as f:
        writer.write(f)
    return pdf_path


@pytest.fixture
def docx_with_metadata(tmp_path) -> Path:
    docx_path = tmp_path / "letter.docx"
    core_xml = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<cp:coreProperties '
        'xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" '
        'xmlns:dc="http://purl.org/dc/elements/1.1/" '
        'xmlns:dcterms="http://purl.org/dc/terms/">'
        "<dc:creator>Jane Tester</dc:creator>"
        "<cp:lastModifiedBy>Jane Tester</cp:lastModifiedBy>"
        "<dc:title>Confidential Letter</dc:title>"
        "</cp:coreProperties>"
    )
    with zipfile.ZipFile(docx_path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("docProps/core.xml", core_xml)
        zf.writestr("word/document.xml", "<document/>")
    return docx_path


# ---------- format detection ----------

def test_detect_format_dispatches_correctly(jpeg_with_gps, pdf_with_metadata, docx_with_metadata):
    assert detect_format(jpeg_with_gps) == "image"
    assert detect_format(pdf_with_metadata) == "pdf"
    assert detect_format(docx_with_metadata) == "docx"


def test_detect_format_unsupported_raises(tmp_path):
    unknown = tmp_path / "notes.txt"
    unknown.write_text("hello")
    with pytest.raises(UnsupportedFileType):
        detect_format(unknown)


# ---------- image EXIF ----------

def test_read_exif_finds_gps_and_tags(jpeg_with_gps):
    exif = image_fmt.read_exif(jpeg_with_gps)
    assert exif["gps"] is not None
    assert exif["gps"]["lat"] == pytest.approx(37.7749, abs=0.01)
    assert exif["gps"]["lon"] == pytest.approx(-122.4194, abs=0.01)
    assert exif["tags"]["Make"] == "TestCam"


def test_read_exif_clean_image_has_no_gps(jpeg_without_metadata):
    exif = image_fmt.read_exif(jpeg_without_metadata)
    assert exif["gps"] is None
    assert exif["tags"] == {}


def test_strip_exif_removes_gps(jpeg_with_gps, tmp_path):
    out = tmp_path / "stripped.jpg"
    image_fmt.strip_exif(jpeg_with_gps, out)
    exif_after = image_fmt.read_exif(out)
    assert exif_after["gps"] is None
    assert exif_after["tags"] == {}


# ---------- scanner produces Findings ----------

def test_scan_file_jpeg_gps_is_high_severity(jpeg_with_gps):
    findings = scan_file(jpeg_with_gps)
    gps_findings = [f for f in findings if f.category == "gps_metadata"]
    assert len(gps_findings) == 1
    assert gps_findings[0].severity == Severity.HIGH
    assert gps_findings[0].source_module == "file_privacy"


def test_scan_file_clean_jpeg_has_no_findings(jpeg_without_metadata):
    assert scan_file(jpeg_without_metadata) == []


def test_scan_file_pdf_author_is_medium_severity(pdf_with_metadata):
    findings = scan_file(pdf_with_metadata)
    author_findings = [f for f in findings if f.extra.get("key") == "Author"]
    assert len(author_findings) == 1
    assert author_findings[0].severity == Severity.MEDIUM


def test_scan_file_docx_creator_detected(docx_with_metadata):
    findings = scan_file(docx_with_metadata)
    categories = {f.category for f in findings}
    assert "docx_metadata" in categories
    creator_findings = [f for f in findings if "creator" in f.extra.get("key", "")]
    assert len(creator_findings) == 1
    assert creator_findings[0].extra["value"] == "Jane Tester"


@pytest.fixture
def png_with_metadata(tmp_path) -> Path:
    from PIL import PngImagePlugin

    img_path = tmp_path / "screenshot.png"
    img = Image.new("RGB", (20, 20), color="green")
    pnginfo = PngImagePlugin.PngInfo()
    pnginfo.add_text("Author", "Jane Tester")
    pnginfo.add_text("Software", "TestPaint 2.0")
    pnginfo.add_text("Comment", "internal draft, do not share")
    img.save(img_path, "png", pnginfo=pnginfo)
    return img_path


@pytest.fixture
def png_without_metadata(tmp_path) -> Path:
    img_path = tmp_path / "clean.png"
    Image.new("RGB", (20, 20), color="purple").save(img_path, "png")
    return img_path


@pytest.fixture
def docx_with_app_metadata(tmp_path) -> Path:
    docx_path = tmp_path / "memo.docx"
    core_xml = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<cp:coreProperties '
        'xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" '
        'xmlns:dc="http://purl.org/dc/elements/1.1/" '
        'xmlns:dcterms="http://purl.org/dc/terms/">'
        "<dc:creator>Jane Tester</dc:creator>"
        "</cp:coreProperties>"
    )
    app_xml = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties">'
        "<Company>Acme Corp</Company>"
        "<Manager>Jane's Boss</Manager>"
        "</Properties>"
    )
    with zipfile.ZipFile(docx_path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("docProps/core.xml", core_xml)
        zf.writestr("docProps/app.xml", app_xml)
        zf.writestr("word/document.xml", "<document/>")
    return docx_path


# ---------- PNG metadata ----------

def test_read_png_metadata_finds_text_chunks(png_with_metadata):
    meta = image_fmt.read_png_metadata(png_with_metadata)
    assert meta["gps"] is None
    assert meta["tags"]["Author"] == "Jane Tester"
    assert meta["tags"]["Software"] == "TestPaint 2.0"
    assert meta["tags"]["Comment"] == "internal draft, do not share"


def test_read_png_metadata_clean_image_has_no_tags(png_without_metadata):
    meta = image_fmt.read_png_metadata(png_without_metadata)
    assert meta["gps"] is None
    assert meta["tags"] == {}


def test_strip_png_metadata_removes_text_chunks(png_with_metadata, tmp_path):
    out = tmp_path / "stripped.png"
    image_fmt.strip_png_metadata(png_with_metadata, out)
    meta_after = image_fmt.read_png_metadata(out)
    assert meta_after["tags"] == {}


def test_scan_file_png_author_is_medium_severity(png_with_metadata):
    findings = scan_file(png_with_metadata)
    author_findings = [f for f in findings if f.extra.get("tag") == "Author"]
    assert len(author_findings) == 1
    assert author_findings[0].severity == Severity.MEDIUM


def test_scan_file_clean_png_has_no_findings(png_without_metadata):
    assert scan_file(png_without_metadata) == []


def test_remove_metadata_dispatches_png(png_with_metadata, tmp_path):
    out = tmp_path / "out.png"
    remove_metadata(png_with_metadata, out)
    assert image_fmt.read_png_metadata(out)["tags"] == {}


# ---------- DOCX app.xml ----------

def test_read_docx_metadata_includes_app_xml_fields(docx_with_app_metadata):
    meta = docx_fmt.read_docx_metadata(docx_with_app_metadata)
    assert meta["app:Company"] == "Acme Corp"
    assert meta["app:Manager"] == "Jane's Boss"
    assert meta["dc:creator"] == "Jane Tester"


def test_scan_file_docx_company_is_medium_severity(docx_with_app_metadata):
    findings = scan_file(docx_with_app_metadata)
    company_findings = [f for f in findings if f.extra.get("key") == "app:Company"]
    assert len(company_findings) == 1
    assert company_findings[0].severity == Severity.MEDIUM
    assert "organization name" in company_findings[0].description


def test_strip_docx_metadata_clears_both_core_and_app(docx_with_app_metadata, tmp_path):
    out = tmp_path / "clean_memo.docx"
    docx_fmt.strip_docx_metadata(docx_with_app_metadata, out)
    meta_after = docx_fmt.read_docx_metadata(out)
    assert meta_after == {}
    with zipfile.ZipFile(out) as zf:
        assert zf.read("word/document.xml") == b"<document/>"


# ---------- format detection (extended) ----------

def test_detect_format_png(png_with_metadata):
    assert detect_format(png_with_metadata) == "png"


# ---------- PDF metadata round trip ----------

def test_pdf_metadata_round_trip(pdf_with_metadata, tmp_path):
    meta_before = pdf_fmt.read_pdf_metadata(pdf_with_metadata)
    assert meta_before["Author"] == "Jane Tester"

    out = tmp_path / "clean.pdf"
    pdf_fmt.strip_pdf_metadata(pdf_with_metadata, out)
    meta_after = pdf_fmt.read_pdf_metadata(out)
    assert meta_after == {}


# ---------- DOCX metadata round trip ----------

def test_docx_metadata_round_trip(docx_with_metadata, tmp_path):
    meta_before = docx_fmt.read_docx_metadata(docx_with_metadata)
    assert meta_before["dc:creator"] == "Jane Tester"

    out = tmp_path / "clean.docx"
    docx_fmt.strip_docx_metadata(docx_with_metadata, out)
    meta_after = docx_fmt.read_docx_metadata(out)
    assert meta_after.get("dc:creator", "") == ""

    # sibling parts must survive untouched
    with zipfile.ZipFile(out) as zf:
        assert zf.read("word/document.xml") == b"<document/>"


# ---------- remover dispatch ----------

def test_remove_metadata_dispatches_by_format(jpeg_with_gps, pdf_with_metadata, docx_with_metadata, tmp_path):
    out_jpg = tmp_path / "out.jpg"
    out_pdf = tmp_path / "out.pdf"
    out_docx = tmp_path / "out.docx"

    remove_metadata(jpeg_with_gps, out_jpg)
    remove_metadata(pdf_with_metadata, out_pdf)
    remove_metadata(docx_with_metadata, out_docx)

    assert image_fmt.read_exif(out_jpg)["gps"] is None
    assert pdf_fmt.read_pdf_metadata(out_pdf) == {}
    assert docx_fmt.read_docx_metadata(out_docx).get("dc:creator", "") == ""


def test_remove_metadata_never_touches_original(jpeg_with_gps, tmp_path):
    original_bytes_before = jpeg_with_gps.read_bytes()
    out = tmp_path / "out.jpg"
    remove_metadata(jpeg_with_gps, out)
    assert jpeg_with_gps.read_bytes() == original_bytes_before
