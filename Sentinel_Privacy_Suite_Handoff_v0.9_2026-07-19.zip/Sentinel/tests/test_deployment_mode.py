"""Tests for config/settings.py's deployment-mode switch (desktop vs headless)."""

from __future__ import annotations

from config.settings import CameraShieldConfig, DeploymentMode, _parse_source, redact_source


def test_parse_source_int_string_becomes_int():
    assert _parse_source("0") == 0
    assert _parse_source("2") == 2


def test_parse_source_url_stays_string():
    url = "rtsp://user:pass@192.168.1.50/stream1"
    assert _parse_source(url) == url


# -- redact_source() -------------------------------------------------------
# Added this session after finding that config.source (which can embed
# credentials, e.g. rtsp://user:pass@host/stream) was being logged in
# plaintext at startup (main.py) and embedded raw in RuntimeError messages
# (camera/shield.py, privacy_engine/camera_scan.py) when a camera source
# failed to open. redact_source() is the fix; these tests are what would
# have caught the leak if they'd existed before it did.

def test_redact_source_masks_credentials_in_url():
    assert redact_source("rtsp://admin:hunter2@192.168.1.50:554/stream") == \
        "rtsp://***:***@192.168.1.50:554/stream"


def test_redact_source_leaves_credential_free_url_unchanged():
    url = "http://192.168.1.50:8080/video"
    assert redact_source(url) == url


def test_redact_source_leaves_device_index_unchanged():
    assert redact_source(0) == "0"
    assert redact_source(2) == "2"


def test_redact_source_leaves_device_path_unchanged():
    assert redact_source("/dev/video0") == "/dev/video0"


def test_redact_source_never_contains_the_original_secret():
    """The specific property that matters: whatever the credential was,
    it must not appear anywhere in the output -- not just that *some*
    masking happened."""
    secret = "hunter2"
    url = f"rtsp://admin:{secret}@192.168.1.50/stream"
    assert secret not in redact_source(url)


def test_desktop_defaults():
    config = CameraShieldConfig.from_args(["--mode", "desktop"])
    assert config.deployment_mode == DeploymentMode.DESKTOP
    assert config.show_preview is True
    assert config.use_virtual_cam is True
    assert config.http_stream is False


def test_headless_defaults():
    config = CameraShieldConfig.from_args(["--mode", "headless"])
    assert config.deployment_mode == DeploymentMode.HEADLESS
    assert config.show_preview is False
    assert config.use_virtual_cam is False
    assert config.http_stream is True


def test_headless_with_rtsp_source():
    config = CameraShieldConfig.from_args(
        ["--mode", "headless", "--source", "rtsp://cam.local/stream"]
    )
    assert config.source == "rtsp://cam.local/stream"


def test_desktop_source_defaults_to_device_index_zero():
    config = CameraShieldConfig.from_args(["--mode", "desktop"])
    assert config.source == 0


def test_explicit_overrides_beat_mode_defaults():
    # Force streaming on even in desktop mode.
    config = CameraShieldConfig.from_args(["--mode", "desktop", "--stream"])
    assert config.http_stream is True
    assert config.show_preview is True  # unaffected

    # Force preview/vcam off even in desktop mode.
    config2 = CameraShieldConfig.from_args(["--mode", "desktop", "--no-preview", "--no-vcam"])
    assert config2.show_preview is False
    assert config2.use_virtual_cam is False

    # Force preview on even in headless mode (unusual, but should be honored).
    config3 = CameraShieldConfig.from_args(["--mode", "headless", "--preview"])
    assert config3.show_preview is True
    assert config3.http_stream is True  # headless default still applies


def test_http_host_and_port_configurable():
    config = CameraShieldConfig.from_args(
        ["--mode", "headless", "--http-host", "127.0.0.1", "--http-port", "9001"]
    )
    assert config.http_host == "127.0.0.1"
    assert config.http_port == 9001
