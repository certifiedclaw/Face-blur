"""Tests for camera/face_mesh_compat.py.

No real .task model file is available in this sandbox (mediapipe's model
storage, storage.googleapis.com, is outside this environment's network
allowlist -- see CHANGELOG.md v0.9 entry). These tests instead verify the
one thing that's actually ours to get right: translating the Tasks API's
result shape into the legacy-API-shaped object `process_frame()` and every
other test in this project expects. The Tasks API call itself
(`FaceLandmarker.create_from_options`, `detect_for_video`) is mocked at the
`mediapipe.tasks.python.vision` boundary -- this project's actual code
(model-not-found handling, timestamp bookkeeping, result translation) still
runs for real.
"""

from __future__ import annotations

import sys
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from camera.face_mesh_compat import FaceMeshCompat, ModelNotFoundError


@pytest.fixture
def dummy_model_file(tmp_path) -> Path:
    """FaceMeshCompat only checks the model path *exists* before handing it
    to mediapipe -- content doesn't matter for these tests since the actual
    FaceLandmarker construction is mocked."""
    p = tmp_path / "face_landmarker.task"
    p.write_bytes(b"not a real model, just needs to exist")
    return p


def _fake_landmark(x, y, z=0.0):
    return SimpleNamespace(x=x, y=y, z=z)


def test_missing_model_raises_actionable_error(tmp_path):
    missing = tmp_path / "nope.task"
    with pytest.raises(ModelNotFoundError, match="not found"):
        FaceMeshCompat(str(missing))


def test_missing_model_error_mentions_readme(tmp_path):
    """The error should point somewhere actionable, not just say 'missing'."""
    missing = tmp_path / "nope.task"
    with pytest.raises(ModelNotFoundError, match="README"):
        FaceMeshCompat(str(missing))


def test_no_faces_returns_none_multi_face_landmarks(dummy_model_file, monkeypatch):
    fake_detector = MagicMock()
    fake_detector.detect_for_video.return_value = SimpleNamespace(face_landmarks=[])

    from mediapipe.tasks.python import vision as mp_tasks_vision
    monkeypatch.setattr(
        mp_tasks_vision.FaceLandmarker, "create_from_options",
        classmethod(lambda cls, options: fake_detector),
    )

    with FaceMeshCompat(str(dummy_model_file)) as mesh:
        rgb = np.zeros((10, 10, 3), dtype=np.uint8)
        result = mesh.process(rgb)

    assert result.multi_face_landmarks is None


def test_faces_translate_to_legacy_shaped_result(dummy_model_file, monkeypatch):
    """The core translation this module exists for: Tasks API gives a bare
    list of landmark lists; legacy-shaped result needs .multi_face_landmarks
    where each entry has a .landmark attribute, and each point has .x/.y/.z."""
    fake_face_1 = [_fake_landmark(0.1, 0.2), _fake_landmark(0.3, 0.4)]
    fake_face_2 = [_fake_landmark(0.5, 0.6)]
    fake_detector = MagicMock()
    fake_detector.detect_for_video.return_value = SimpleNamespace(
        face_landmarks=[fake_face_1, fake_face_2]
    )

    from mediapipe.tasks.python import vision as mp_tasks_vision
    monkeypatch.setattr(
        mp_tasks_vision.FaceLandmarker, "create_from_options",
        classmethod(lambda cls, options: fake_detector),
    )

    with FaceMeshCompat(str(dummy_model_file)) as mesh:
        rgb = np.zeros((10, 10, 3), dtype=np.uint8)
        result = mesh.process(rgb)

    assert result.multi_face_landmarks is not None
    assert len(result.multi_face_landmarks) == 2
    assert len(result.multi_face_landmarks[0].landmark) == 2
    assert result.multi_face_landmarks[0].landmark[0].x == pytest.approx(0.1)
    assert result.multi_face_landmarks[0].landmark[0].y == pytest.approx(0.2)
    assert len(result.multi_face_landmarks[1].landmark) == 1
    assert result.multi_face_landmarks[1].landmark[0].x == pytest.approx(0.5)


def test_timestamp_increases_monotonically_across_calls(dummy_model_file, monkeypatch):
    """VIDEO running mode requires strictly increasing timestamps -- this is
    a real Tasks API constraint (calling detect_for_video with a
    non-increasing timestamp raises), so it's worth locking down that our
    counter actually increments every call."""
    fake_detector = MagicMock()
    fake_detector.detect_for_video.return_value = SimpleNamespace(face_landmarks=[])

    from mediapipe.tasks.python import vision as mp_tasks_vision
    monkeypatch.setattr(
        mp_tasks_vision.FaceLandmarker, "create_from_options",
        classmethod(lambda cls, options: fake_detector),
    )

    with FaceMeshCompat(str(dummy_model_file)) as mesh:
        rgb = np.zeros((10, 10, 3), dtype=np.uint8)
        mesh.process(rgb)
        mesh.process(rgb)
        mesh.process(rgb)

    timestamps = [call.args[1] for call in fake_detector.detect_for_video.call_args_list]
    assert timestamps == sorted(timestamps)
    assert len(set(timestamps)) == len(timestamps)  # strictly increasing, no repeats


def test_close_closes_underlying_detector(dummy_model_file, monkeypatch):
    fake_detector = MagicMock()

    from mediapipe.tasks.python import vision as mp_tasks_vision
    monkeypatch.setattr(
        mp_tasks_vision.FaceLandmarker, "create_from_options",
        classmethod(lambda cls, options: fake_detector),
    )

    with FaceMeshCompat(str(dummy_model_file)):
        pass

    fake_detector.close.assert_called_once()


def test_options_pass_through_max_faces_and_confidence(dummy_model_file, monkeypatch):
    """Regression guard: it would be easy for a future edit to silently drop
    one of these constructor args when touching FaceLandmarkerOptions."""
    captured = {}

    def _fake_create(cls, options):
        captured["num_faces"] = options.num_faces
        captured["min_face_detection_confidence"] = options.min_face_detection_confidence
        captured["min_tracking_confidence"] = options.min_tracking_confidence
        return MagicMock()

    from mediapipe.tasks.python import vision as mp_tasks_vision
    monkeypatch.setattr(
        mp_tasks_vision.FaceLandmarker, "create_from_options", classmethod(_fake_create)
    )

    FaceMeshCompat(
        str(dummy_model_file), max_num_faces=7,
        min_detection_confidence=0.42, min_tracking_confidence=0.77,
    )

    assert captured["num_faces"] == 7
    assert captured["min_face_detection_confidence"] == pytest.approx(0.42)
    assert captured["min_tracking_confidence"] == pytest.approx(0.77)
