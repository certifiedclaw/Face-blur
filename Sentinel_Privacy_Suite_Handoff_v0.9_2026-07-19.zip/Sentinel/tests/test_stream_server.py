"""Tests for camera/stream_server.py.

Runs a real server on 127.0.0.1 with an ephemeral port (port=0) and makes
real HTTP requests over loopback -- no camera or mediapipe involved, just
verifying the frame buffer + MJPEG plumbing itself.
"""

from __future__ import annotations

import urllib.request

import numpy as np
import pytest

from camera.stream_server import FrameBuffer, MjpegStreamServer


def _solid_frame(h=16, w=16, value=128):
    return np.full((h, w, 3), value, dtype=np.uint8)


def test_frame_buffer_returns_none_before_any_update():
    buf = FrameBuffer()
    assert buf.get_jpeg() is None


def test_frame_buffer_returns_valid_jpeg_after_update():
    buf = FrameBuffer()
    buf.update(_solid_frame())
    jpeg = buf.get_jpeg(quality=80)
    assert jpeg is not None
    assert jpeg[:2] == b"\xff\xd8"  # JPEG magic bytes (SOI marker)


@pytest.fixture
def running_server():
    buf = FrameBuffer()
    buf.update(_solid_frame())
    server = MjpegStreamServer(buf, host="127.0.0.1", port=0, jpeg_quality=80)
    server.start()
    yield server, buf
    server.stop()


def test_index_page_serves_html(running_server):
    server, _ = running_server
    host, port = server.address
    with urllib.request.urlopen(f"http://{host}:{port}/", timeout=5) as resp:
        assert resp.status == 200
        assert "text/html" in resp.headers.get("Content-Type", "")
        body = resp.read()
        assert b"stream.mjpg" in body


def test_stream_endpoint_serves_multipart_jpeg(running_server):
    server, buf = running_server
    host, port = server.address
    with urllib.request.urlopen(f"http://{host}:{port}/stream.mjpg", timeout=5) as resp:
        assert resp.status == 200
        content_type = resp.headers.get("Content-Type", "")
        assert "multipart/x-mixed-replace" in content_type
        # Read enough of the stream to see at least one full boundary + JPEG header.
        chunk = resp.read(4096)
        assert b"Content-Type: image/jpeg" in chunk
        assert b"\xff\xd8" in chunk  # JPEG SOI marker present in the stream


def test_unknown_path_returns_404(running_server):
    server, _ = running_server
    host, port = server.address
    try:
        urllib.request.urlopen(f"http://{host}:{port}/nonexistent", timeout=5)
        assert False, "expected HTTPError"
    except urllib.error.HTTPError as e:
        assert e.code == 404
