"""Face box tracking helpers: turns raw per-frame landmarks into a stable,
padded bounding box so the scrambled region doesn't jitter."""

from __future__ import annotations

import numpy as np


class SmoothedBox:
    """Exponentially-smoothed bounding box to reduce frame-to-frame jitter.

    alpha close to 1.0 = very responsive but jittery; close to 0.0 = very
    smooth but laggy. 0.5 is a reasonable default for webcam framerates.
    """

    def __init__(self, alpha: float = 0.5):
        self.alpha = alpha
        self.box: np.ndarray | None = None

    def update(self, new_box: tuple[int, int, int, int]) -> tuple[int, int, int, int]:
        if self.box is None:
            self.box = np.array(new_box, dtype=np.float32)
        else:
            self.box = self.alpha * np.array(new_box, dtype=np.float32) + (1 - self.alpha) * self.box
        return tuple(int(v) for v in self.box)  # type: ignore[return-value]


def get_box_from_landmarks(
    landmarks_px: list[tuple[int, int]], frame_w: int, frame_h: int, pad_frac: float
) -> tuple[int, int, int, int]:
    xs = [p[0] for p in landmarks_px]
    ys = [p[1] for p in landmarks_px]
    x1, x2 = min(xs), max(xs)
    y1, y2 = min(ys), max(ys)
    bw, bh = x2 - x1, y2 - y1
    px, py = int(bw * pad_frac), int(bh * pad_frac)
    x1, y1 = max(0, x1 - px), max(0, y1 - py)
    x2, y2 = min(frame_w, x2 + px), min(frame_h, y2 + py)
    return x1, y1, x2, y2
