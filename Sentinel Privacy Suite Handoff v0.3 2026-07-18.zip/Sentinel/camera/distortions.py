"""Pixel-level distortion primitives used by Camera Shield.

Kept dependency-free of MediaPipe/OpenCV video plumbing so they're easy to
unit test in isolation and reuse elsewhere (e.g. file_privacy image redaction).
"""

from __future__ import annotations

import cv2
import numpy as np

# Landmark indices (MediaPipe FaceMesh, 468-point model) used as warp "anchors".
# Each anchor gets a per-frame random push/pull; nearby pixels are displaced
# with a falloff, which produces a face-shaped, organic warp instead of a
# pure random-noise grid.
WARP_ANCHOR_LANDMARKS = [
    1,          # nose tip
    33, 263,    # eye outer corners (L/R)
    133, 362,   # eye inner corners
    61, 291,    # mouth corners
    199,        # chin
    10,         # forehead
]


def pixelate(region: np.ndarray, block_size: int) -> np.ndarray:
    h, w = region.shape[:2]
    if h < 1 or w < 1:
        return region
    small = cv2.resize(
        region,
        (max(1, w // block_size), max(1, h // block_size)),
        interpolation=cv2.INTER_LINEAR,
    )
    return cv2.resize(small, (w, h), interpolation=cv2.INTER_NEAREST)


def block_shuffle(region: np.ndarray, block_size: int, rng: np.random.Generator) -> np.ndarray:
    h, w = region.shape[:2]
    if h < block_size or w < block_size:
        return region
    gh, gw = h // block_size, w // block_size
    cropped = region[: gh * block_size, : gw * block_size].copy()
    blocks = cropped.reshape(gh, block_size, gw, block_size, 3)
    blocks = blocks.transpose(0, 2, 1, 3, 4).reshape(gh * gw, block_size, block_size, 3)
    order = rng.permutation(gh * gw)
    blocks = blocks[order]
    blocks = blocks.reshape(gh, gw, block_size, block_size, 3).transpose(0, 2, 1, 3, 4)
    shuffled = blocks.reshape(gh * block_size, gw * block_size, 3)
    out = region.copy()
    out[: gh * block_size, : gw * block_size] = shuffled
    return out


def landmark_warp(
    region: np.ndarray,
    landmarks_local: list[tuple[int, int]] | None,
    strength: int,
    rng: np.random.Generator,
) -> np.ndarray:
    """Displace pixels using a field built from face-mesh anchor points.

    Each anchor gets a random 2D push vector; every pixel's displacement is a
    distance-weighted sum of all anchor push vectors, so distortion follows
    facial structure (eyes, mouth, nose) rather than pure noise.
    """
    h, w = region.shape[:2]
    if h < 2 or w < 2 or not landmarks_local:
        return region

    ys, xs = np.mgrid[0:h, 0:w].astype(np.float32)
    dx_total = np.zeros((h, w), dtype=np.float32)
    dy_total = np.zeros((h, w), dtype=np.float32)
    weight_total = np.zeros((h, w), dtype=np.float32)

    sigma = max(h, w) * 0.35  # falloff radius scales with region size

    for lx, ly in landmarks_local:
        push_x = rng.uniform(-strength, strength)
        push_y = rng.uniform(-strength, strength)
        d2 = (xs - lx) ** 2 + (ys - ly) ** 2
        weight = np.exp(-d2 / (2 * sigma**2))
        dx_total += push_x * weight
        dy_total += push_y * weight
        weight_total += weight

    norm = np.clip(weight_total, 1e-3, None)
    dx = dx_total / norm * np.clip(weight_total, 0, 1)
    dy = dy_total / norm * np.clip(weight_total, 0, 1)

    map_x = (xs + dx).astype(np.float32)
    map_y = (ys + dy).astype(np.float32)
    return cv2.remap(
        region, map_x, map_y, interpolation=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT
    )


def feather_mask(w: int, h: int, feather_px: int) -> np.ndarray:
    """Alpha mask: 1 in the center, fading to 0 within feather_px of the edge,
    so the scrambled patch blends into the frame instead of showing a hard
    rectangle seam."""
    if feather_px <= 0:
        return np.ones((h, w), dtype=np.float32)
    mask = np.ones((h, w), dtype=np.float32)
    ramp_x = np.clip(np.minimum(np.arange(w), w - 1 - np.arange(w)) / feather_px, 0, 1)
    ramp_y = np.clip(np.minimum(np.arange(h), h - 1 - np.arange(h)) / feather_px, 0, 1)
    mask *= ramp_x[None, :]
    mask *= ramp_y[:, None]
    return mask


def scramble_region(
    region: np.ndarray,
    mode: str,
    block_size: int,
    blur_ksize: int,
    warp_strength: int,
    rng: np.random.Generator,
    landmarks_local: list[tuple[int, int]] | None = None,
) -> np.ndarray:
    if mode == "warp":
        region = landmark_warp(region, landmarks_local, warp_strength, rng)
        region = pixelate(region, block_size)
        region = block_shuffle(region, block_size, rng)
    elif mode == "blur":
        k = blur_ksize | 1  # gaussian kernel must be odd
        region = cv2.GaussianBlur(region, (k, k), 0)
    else:  # light
        region = pixelate(region, block_size)
        region = block_shuffle(region, block_size, rng)
    return region
