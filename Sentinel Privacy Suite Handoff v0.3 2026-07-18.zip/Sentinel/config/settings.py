"""Configuration for Camera Shield.

Centralizing settings here (instead of module-level globals scattered through
the pipeline) is what lets the dashboard, CLI, and future plugin system all
read/write the same config object.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass


@dataclass
class CameraShieldConfig:
    cam_index: int = 0
    block_size: int = 14
    blur_ksize: int = 35
    warp_strength: int = 40
    pad_fraction: float = 0.35
    feather_px: int = 18
    max_faces: int = 4
    use_virtual_cam: bool = True
    smoothing_alpha: float = 0.5  # higher = less smoothing, more responsive
    min_detection_confidence: float = 0.5
    min_tracking_confidence: float = 0.5

    @classmethod
    def from_args(cls, argv: list[str] | None = None) -> "CameraShieldConfig":
        parser = argparse.ArgumentParser(description="Sentinel Camera Shield")
        parser.add_argument("--cam", type=int, default=0, help="camera index")
        parser.add_argument("--block", type=int, default=14, help="pixel block size")
        parser.add_argument("--warp", type=int, default=40, help="max warp displacement (px)")
        parser.add_argument("--pad", type=float, default=0.35, help="face box padding fraction")
        parser.add_argument("--feather", type=int, default=18, help="edge feather width in px, 0 to disable")
        parser.add_argument("--max-faces", type=int, default=4, help="max faces to scramble at once")
        parser.add_argument("--no-vcam", action="store_true", help="disable virtual camera, preview only")
        args = parser.parse_args(argv)
        return cls(
            cam_index=args.cam,
            block_size=args.block,
            warp_strength=args.warp,
            pad_fraction=args.pad,
            feather_px=args.feather,
            max_faces=args.max_faces,
            use_virtual_cam=not args.no_vcam,
        )
