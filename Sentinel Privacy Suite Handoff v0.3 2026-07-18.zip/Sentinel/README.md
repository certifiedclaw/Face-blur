# Sentinel Privacy Suite

A local-first privacy and identity protection platform. Everything runs on
your machine — no cloud calls, no telemetry.

**Current status: v0.3 — Camera Shield + File Privacy.** The broader suite
described in `ROADMAP.md` (audio shield, privacy engine risk scoring,
identity audit, network awareness, dashboard) is planned but not yet
implemented. See `PROJECT_STATE.md` for the honest current state.

## What works today: Camera Shield

Real-time webcam face anonymization with three modes:

- **light** — pixelation + randomized block shuffle over the detected face.
  Cheap, good for video calls.
- **warp** — landmark-driven nonlinear warp (eyes/nose/mouth get pulled and
  pushed based on actual face-mesh geometry) + pixelation + shuffle. Heavier
  distortion, still moves naturally with your face.
- **blur** — plain Gaussian blur. Cheapest option, good fallback on weak
  hardware.

Output is sent to a virtual camera you can select as your webcam source in
Zoom/Meet/Discord, or previewed locally if no virtual camera driver is found.

### Install

```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

> **Note on the mediapipe version pin:** `requirements.txt` pins
> `mediapipe==0.10.21` deliberately. Mediapipe releases from 0.10.30 onward
> removed the legacy `mediapipe.solutions` API that this code uses for
> FaceMesh. See `DEPENDENCY_REPORT.md` for details and the migration plan.

Virtual camera driver (needed for `--no-vcam` to be optional):

- **Windows**: install OBS (bundles the virtual cam driver), or "OBS Virtual Camera".
- **macOS**: `brew install obs`, or use OBS's virtual cam.
- **Linux**: `sudo modprobe v4l2loopback devices=1 video_nr=10 card_label="ScrambleCam"`

### Run

```bash
python main.py
```

Options:

```
--cam N          camera index (default 0)
--block N        pixel block size (default 14)
--warp N         max warp displacement in px (default 40)
--pad F          face box padding fraction (default 0.35)
--feather N      edge feather width in px, 0 to disable (default 18)
--max-faces N    max faces to scramble at once (default 4)
--no-vcam        disable virtual camera, local preview only
```

Controls while running:

```
SPACE   cycle light -> warp -> blur -> light
=/-     increase/decrease scramble intensity
[ / ]   decrease/increase warp strength (warp mode)
f       toggle FPS overlay
q       quit
```

### Run tests

```bash
pip install pytest
python -m pytest tests/
```

The test suite covers the pure image-processing functions (pixelate, block
shuffle, feathering, warp, box smoothing) without needing a webcam. It does
**not** cover `CameraShield.run()`'s live camera loop, which needs real
hardware — see `PROJECT_STATE.md` for what's manually verified vs.
unit-tested.

## What works today: File Privacy

Scans photos and documents for metadata that could identify or locate you,
and can write a metadata-stripped copy. Supports JPEG/TIFF (EXIF, including
GPS), PDF (Info dictionary), and DOCX (core properties: author, last
editor, title, etc).

```bash
python -m file_privacy.cli scan photo.jpg
python -m file_privacy.cli scan ~/Documents --recursive
python -m file_privacy.cli clean photo.jpg -o photo_clean.jpg
```

`clean` always writes to a separate output path — it never overwrites or
modifies the original file.

**Not yet supported**: PNG, HEIC (the default iPhone photo format), legacy
`.doc`/`.xls`/`.ppt`, PDF XMP metadata streams, and document *content*
(tracked changes, comments, hidden text) as opposed to metadata fields. See
`PROJECT_STATE.md` for the current, honest coverage limits.

## Project layout

```
Sentinel/
├── main.py              # entry point
├── camera/               # Camera Shield (implemented)
│   ├── distortions.py    # pixelate / shuffle / landmark-warp / feather
│   ├── tracking.py       # box smoothing, landmark -> bbox
│   └── shield.py         # pipeline orchestrator (capture -> detect -> distort -> output)
├── config/                # CameraShieldConfig dataclass + CLI parsing
├── core/
│   └── findings.py        # shared Finding/Severity data structure
├── file_privacy/           # metadata scan/strip (implemented)
│   ├── formats/            # images.py, pdf.py, docx.py
│   ├── scanner.py
│   ├── remover.py
│   └── cli.py
├── tests/                  # pytest suite for camera/ and file_privacy/
├── audio/                  # placeholder package, not implemented
├── privacy_engine/          # placeholder package, not implemented
├── identity_audit/          # placeholder package, not implemented
├── network/                  # placeholder package, not implemented
├── dashboard/              # placeholder package, not implemented
├── plugins/                # placeholder package, not implemented
├── models/                 # reserved for local model weights
├── docs/                   # this documentation set
└── releases/                # handoff zips
```

See `ARCHITECTURE.md` for design rationale and `ROADMAP.md` for what's next.

## Design principles

- **Local processing** — no frame, image, or metadata ever leaves the machine.
- **Privacy by design** — every module should default to the more protective
  option.
- **Transparency** — the suite should explain *why* it flags something as a
  risk, not just present a score.
- **Modular** — each capability is its own package with a narrow interface,
  so it can be developed, tested, and disabled independently.
