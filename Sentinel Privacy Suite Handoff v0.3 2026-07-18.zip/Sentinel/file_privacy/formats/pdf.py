"""PDF document metadata: read and strip.

Uses pypdf. Covers the standard Info dictionary (Author, Creator, Producer,
etc). Does not attempt to scrub embedded XMP metadata streams or content-
level leaks (e.g. text pasted from a document with tracked changes) -- that's
future scope, noted in ROADMAP.md.
"""

from __future__ import annotations

from pathlib import Path

from pypdf import PdfReader, PdfWriter

# Info dict keys that commonly leak identity/organization info.
NOTABLE_KEYS = {
    "/Author": "document author name",
    "/Creator": "authoring application",
    "/Producer": "PDF-generating software",
    "/Title": "document title (may contain personal info)",
    "/Subject": "document subject line",
    "/Company": "organization name",
}


def read_pdf_metadata(path: str | Path) -> dict:
    path = Path(path)
    reader = PdfReader(str(path))
    meta = reader.metadata or {}
    found = {}
    for key, label in NOTABLE_KEYS.items():
        value = meta.get(key)
        if value:
            found[key.lstrip("/")] = str(value)
    return found


def strip_pdf_metadata(path: str | Path, output_path: str | Path) -> None:
    """Write a copy of the PDF with the Info dictionary cleared.

    Note: pypdf's PdfWriter re-stamps its own "/Producer": "pypdf" on every
    write() regardless of what's passed to add_metadata({}) -- verified by
    testing an empty-dict overwrite, which left Producer set. Explicitly
    overwriting every notable key (including Producer) with an empty string
    is what actually clears it.
    """
    path = Path(path)
    output_path = Path(output_path)
    reader = PdfReader(str(path))
    writer = PdfWriter()
    for page in reader.pages:
        writer.add_page(page)
    writer.add_metadata({key: "" for key in NOTABLE_KEYS})
    with open(output_path, "wb") as f:
        writer.write(f)
