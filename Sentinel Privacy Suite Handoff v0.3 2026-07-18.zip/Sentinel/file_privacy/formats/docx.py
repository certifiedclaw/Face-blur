"""DOCX (Office Open XML) core-properties metadata: read and strip.

A .docx is a zip archive; author/title/company metadata lives in
`docProps/core.xml` (and sometimes `docProps/app.xml`). Implemented with the
stdlib `zipfile`/`xml.etree` instead of pulling in python-docx, since this is
the only thing needed from it and it avoids an lxml dependency.
"""

from __future__ import annotations

import shutil
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

CORE_PROPS_PATH = "docProps/core.xml"
APP_PROPS_PATH = "docProps/app.xml"

NAMESPACES = {
    "cp": "http://schemas.openxmlformats.org/package/2006/metadata/core-properties",
    "dc": "http://purl.org/dc/elements/1.1/",
    "dcterms": "http://purl.org/dc/terms/",
}

# (namespace prefix, local tag) -> human label
NOTABLE_CORE_TAGS = {
    ("dc", "creator"): "document author",
    ("cp", "lastModifiedBy"): "last editor name",
    ("dc", "title"): "document title",
    ("dc", "subject"): "document subject",
    ("dc", "description"): "document description",
    ("cp", "category"): "document category",
    ("dcterms", "created"): "creation timestamp",
    ("dcterms", "modified"): "last-modified timestamp",
}


def read_docx_metadata(path: str | Path) -> dict:
    path = Path(path)
    found: dict = {}
    with zipfile.ZipFile(path) as zf:
        if CORE_PROPS_PATH not in zf.namelist():
            return found
        with zf.open(CORE_PROPS_PATH) as f:
            tree = ET.parse(f)
            root = tree.getroot()
            for (prefix, local), label in NOTABLE_CORE_TAGS.items():
                el = root.find(f"{{{NAMESPACES[prefix]}}}{local}")
                if el is not None and el.text:
                    found[f"{prefix}:{local}"] = el.text
    return found


def strip_docx_metadata(path: str | Path, output_path: str | Path) -> None:
    """Write a copy of the docx with core-properties text fields cleared.

    Leaves the XML structure intact (required tags stay present but empty)
    rather than deleting elements outright, which keeps the file valid for
    Word/LibreOffice.
    """
    path = Path(path)
    output_path = Path(output_path)

    tmp_path = output_path.with_suffix(output_path.suffix + ".tmp")
    shutil.copy(path, tmp_path)

    # Read, modify, and rewrite core.xml in place within the zip.
    with zipfile.ZipFile(tmp_path) as zin:
        names = zin.namelist()
        if CORE_PROPS_PATH not in names:
            shutil.move(tmp_path, output_path)
            return
        with zin.open(CORE_PROPS_PATH) as f:
            tree = ET.parse(f)
            root = tree.getroot()
            for prefix, local in NOTABLE_CORE_TAGS:
                el = root.find(f"{{{NAMESPACES[prefix]}}}{local}")
                if el is not None:
                    el.text = ""
        for prefix, uri in NAMESPACES.items():
            ET.register_namespace(prefix, uri)
        import io

        buf = io.BytesIO()
        tree.write(buf, xml_declaration=True, encoding="UTF-8")
        new_core_xml = buf.getvalue()

    with zipfile.ZipFile(tmp_path) as zin, zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            data = new_core_xml if item.filename == CORE_PROPS_PATH else zin.read(item.filename)
            zout.writestr(item, data)

    tmp_path.unlink(missing_ok=True)
