"""CLI entry point for file_privacy.

Usage:
    python -m file_privacy.cli scan <path> [--recursive]
    python -m file_privacy.cli clean <path> -o <output_path>
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from file_privacy.remover import remove_metadata
from file_privacy.scanner import UnsupportedFileType, scan_directory, scan_file


def _print_findings(path: str, findings: list) -> None:
    if not findings:
        print(f"{path}: no privacy-relevant metadata found")
        return
    print(f"{path}: {len(findings)} finding(s)")
    for f in findings:
        print(f"  [{f.severity.value.upper():6}] {f.title} -- {f.description}")


def cmd_scan(args: argparse.Namespace) -> int:
    path = Path(args.path)
    if path.is_dir():
        results = scan_directory(path, recursive=args.recursive)
        if not results:
            print("No supported files found (jpg/jpeg/tiff, pdf, docx).")
            return 0
        for file_path, findings in results.items():
            _print_findings(file_path, findings)
        return 0

    try:
        findings = scan_file(path)
    except UnsupportedFileType as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    _print_findings(str(path), findings)
    return 0


def cmd_clean(args: argparse.Namespace) -> int:
    try:
        remove_metadata(args.path, args.output)
    except UnsupportedFileType as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    print(f"Wrote metadata-stripped copy to {args.output}")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="file_privacy", description="Scan and clean file metadata")
    sub = parser.add_subparsers(dest="command", required=True)

    scan_p = sub.add_parser("scan", help="scan a file or directory for privacy-relevant metadata")
    scan_p.add_argument("path", help="file or directory to scan")
    scan_p.add_argument("--recursive", action="store_true", default=True)
    scan_p.set_defaults(func=cmd_scan)

    clean_p = sub.add_parser("clean", help="write a metadata-stripped copy of a file")
    clean_p.add_argument("path", help="source file")
    clean_p.add_argument("-o", "--output", required=True, help="output path for the cleaned copy")
    clean_p.set_defaults(func=cmd_clean)

    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
