"""Shared data structure for privacy findings.

Every module that detects a privacy exposure (file_privacy, and eventually
camera/audio/identity_audit/network) should represent it as a `Finding` so
`privacy_engine/` can aggregate across modules without being coupled to
each module's internals. See ARCHITECTURE.md.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class Severity(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


@dataclass
class Finding:
    """A single detected privacy exposure.

    category: short machine-readable tag, e.g. "gps_metadata", "author_metadata"
    title: short human-readable summary, e.g. "GPS coordinates found in photo"
    description: what was detected and why it matters
    remediation: concrete suggestion to reduce exposure
    severity: Severity
    source_module: which module produced this, e.g. "file_privacy"
    location: optional pointer to where in the source this was found,
              e.g. a file path or an EXIF tag name
    """

    category: str
    title: str
    description: str
    remediation: str
    severity: Severity
    source_module: str
    location: str | None = None
    extra: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "category": self.category,
            "title": self.title,
            "description": self.description,
            "remediation": self.remediation,
            "severity": self.severity.value,
            "source_module": self.source_module,
            "location": self.location,
            "extra": self.extra,
        }
