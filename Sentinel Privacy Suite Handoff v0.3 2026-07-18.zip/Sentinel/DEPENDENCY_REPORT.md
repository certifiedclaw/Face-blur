# DEPENDENCY_REPORT.md

_Verified in this sandbox on 2026-07-18, Python 3.12.3, Linux x86_64._

## Runtime dependencies

| Package | Pin | Verified installed version | Notes |
|---|---|---|---|
| opencv-python | `>=4.9,<5` | 4.13.0.92 (headless variant used for testing) | Core image processing. No known API breaks at this range. |
| numpy | `>=1.26,<2.0` | 1.26.4 | **Capped below 2.0 deliberately.** `opencv-python`/`opencv-python-headless` 4.13.x on PyPI request `numpy>=2`; installing both in the same env produced a pip dependency-conflict warning during this session. Pinning numpy `<2.0` avoids that conflict at the cost of an older numpy. If you upgrade numpy to 2.x, re-verify opencv-python compatibility together — don't do it silently. |
| mediapipe | `==0.10.21` (hard pin) | 0.10.21 | **Critical, verified by bisection.** `mediapipe.solutions.face_mesh.FaceMesh` (the legacy API this codebase uses) is present in 0.10.14–0.10.21 and **absent** starting 0.10.30 (tested 0.10.30, 0.10.31, 0.10.32, 0.10.33, 0.10.35 — all missing `mp.solutions`). Google replaced it with the Tasks API (`mediapipe.tasks.vision`). Do not bump this pin without either porting `camera/shield.py` to the Tasks API or re-verifying `solutions` is somehow back. |
| pyvirtualcam | `>=0.11,<0.12` | not installed in this sandbox (no display/virtual-cam driver available in container) | Import is wrapped in try/except in `CameraShield.run()`, so its absence degrades to local-preview-only rather than crashing. Behavior not re-verified this session beyond reading the code path — was verified in the original script. |

| Pillow | `>=11.0,<13` | 12.1.1 | Used by `file_privacy/formats/images.py` for EXIF read/strip. No known issues at this range; capped below 13 defensively since no major-version compat check has been done yet. |
| pypdf | `>=5.0,<6` | 5.9.0 | Used by `file_privacy/formats/pdf.py`. Note: `PdfWriter.write()` always re-stamps `"/Producer": "pypdf"` regardless of `add_metadata()` calls unless every key including Producer is explicitly overwritten — verified by test failure during v0.3 development, worked around in `strip_pdf_metadata()`. Re-check this behavior if pypdf is upgraded across a major version. |

## Dev/test dependencies

| Package | Pin | Verified installed version |
|---|---|---|
| pytest | `>=8.0` | 9.1.1 |
| piexif | `>=1.1,<2` | 1.1.3 | Test-only — used to build synthetic JPEGs with real EXIF/GPS data for `tests/test_file_privacy.py` fixtures. Not needed at runtime; not imported by any `file_privacy/` module itself. |

## What was actually tested in this sandbox

- `opencv-python-headless`, `numpy`, `pytest`: installed and used to run
  the full `tests/` suite (11/11 passed).
- `mediapipe`: installed multiple versions (0.10.14, 0.10.15, 0.10.18,
  0.10.20, 0.10.21, 0.10.30, 0.10.31, 0.10.32, 0.10.33, 0.10.35) specifically
  to bisect the `solutions` API removal. Settled on 0.10.21 and re-ran a
  full smoke test (`CameraShield.process_frame()` against a real
  `FaceMesh` instance) successfully on that version.
- `pyvirtualcam`: **not installed or tested** — this sandbox has no virtual
  camera driver/display, and installing it here would not meaningfully
  validate the OS-level driver behavior anyway. Test on a real machine with
  OBS or v4l2loopback installed per the README setup notes.
- `cv2.VideoCapture` against a real physical webcam: **not tested** — no
  camera device in this container.
- `Pillow`, `pypdf`: installed and exercised against real (synthetically
  constructed but structurally genuine) JPEG/PDF files — EXIF GPS decoding,
  Info-dict read/write, round-trip strip verified via 13 passing tests plus
  a manual CLI run. Not tested against files produced by real-world
  software (actual phones, actual Word/Acrobat) — flagged in
  PROJECT_STATE.md as a follow-up.

## Recommendations

1. Before any future dependency bump, re-run this bisection process for
   whichever package changed — don't assume a routine `pip install -U`
   is safe. The mediapipe break in this exact codebase is proof it isn't.
2. When the mediapipe Tasks API migration (see ROADMAP.md) happens, this
   report needs a full rewrite of the mediapipe row, including new import
   paths and result-object shapes.
3. Consider adding a CI smoke test that imports `camera.shield` and
   asserts `mp.solutions` exists, so a future `pip install -U mediapipe`
   fails loudly in CI instead of silently at runtime on a user's machine.
