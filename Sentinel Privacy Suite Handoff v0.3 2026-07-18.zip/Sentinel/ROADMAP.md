# ROADMAP.md

Sequenced by what unblocks what, not just by feature excitement. Nothing
below is started unless `PROJECT_STATE.md` says so.

## Now (v0.2 stabilization)

- [ ] Validate `CameraShield.run()` on real webcam hardware, all three OSes
      if possible. This sandbox has no camera device, so the live loop is
      untested end-to-end — see PROJECT_STATE.md for exactly what *was*
      verified.
- [ ] Resolve the mediapipe `solutions` API deprecation properly instead of
      just pinning to 0.10.21 indefinitely. Options:
      1. Stay pinned, accept the tech debt, revisit when it becomes a real
         install problem (e.g. Python version incompatibility).
      2. Migrate to `mediapipe.tasks.vision.FaceLandmarker` (the replacement
         API). This is a real rewrite of `camera/shield.py`'s model-loading
         and result-parsing code, not a drop-in swap — the Tasks API result
         objects have a different shape than `solutions` results.
      Decision owner: project owner, not to be silently chosen by whoever
      picks up this ticket.
- [ ] Add a config file loader (JSON or YAML) so `CameraShieldConfig` values
      don't require code changes or remembering CLI flags every run.

## Done (v0.3)

- [x] **`file_privacy/`**: metadata scanner + remover for JPEG/TIFF (EXIF +
      GPS), PDF (Info dict), DOCX (core.xml). CLI + Python API. 13 tests
      against real synthetic files.
- [x] Shared "privacy finding" data structure (`core/findings.py`,
      `Finding`/`Severity`) — `file_privacy` is the first real producer.

## Next

- [ ] Expand `file_privacy` format coverage: PNG metadata chunks, HEIC
      (default iPhone format), legacy `.doc`/`.xls`/`.ppt`. Also DOCX
      `docProps/app.xml` (company/manager fields aren't in core.xml).
- [ ] Test `file_privacy` against real-world files (actual phone camera
      output, actual Word/Acrobat-generated documents), not just the
      synthetic fixtures used so far — real tools may set fields the
      current `NOTABLE_*` lists don't know about yet.
- [ ] Start `privacy_engine/` as a real aggregator/reporter consuming
      `Finding` lists, now that `file_privacy` produces them for real.

## Later

- [ ] `identity_audit/`: username exposure / local metadata analysis.
      Ethical scope note: self-auditing only, no scraping of other people's
      accounts or data — this needs an explicit design pass on what
      "authorized self-auditing" means technically before writing code.
      Concretely, in-scope: checking the user's *own* email/username
      against public breach-notification APIs (e.g. HaveIBeenPwned, which
      is designed for exactly this), scanning the user's *own* local
      files/accounts for exposure. Out of scope, and declined once already
      (see PROJECT_STATE.md v0.3 note): generic recon tooling aimed at
      arbitrary targets — WHOIS/subdomain-enum/port-scan/Google-dork style
      tools — even if a convenient package happens to bundle them.
- [ ] `privacy_engine/`: aggregate findings from camera/audio/file/identity
      modules into the risk report + explanation described in the original
      spec. Depends on the shared finding structure above existing first.
- [ ] `network/`: VPN/DNS/public-IP *awareness* only — explicitly no
      offensive networking, no packet capture beyond what's needed to show
      the user their own exposure.
- [ ] `audio/`: mic monitoring, speech activity detection, optional voice
      anonymization.
- [ ] Camera Shield extensions: OCR-based readable-text detection,
      background privacy, QR/barcode detection, license plate detection —
      these plug into `privacy_engine/`'s findings model rather than being
      camera-only pixel effects.

## Much later

- [ ] `dashboard/` (PyQt6): live preview, module status, privacy score,
      settings, logs. Deferred until there's more than one module worth
      dashboarding — building a UI shell around a single camera toggle
      isn't a good use of the first dashboard milestone.
- [ ] `plugins/`: enable/disable, versioning, dependency checking for
      third-party modules. Needs at least 2-3 first-party modules to exist
      first so the plugin interface is designed against real examples, not
      guessed at.
- [ ] GPU acceleration / performance pass across all modules once there's
      enough of the suite built to know where the actual bottlenecks are.

## Explicitly out of scope

- Anything that claims "perfect anonymity" — the privacy engine's job is to
  explain residual risk, not promise zero risk.
- Any network functionality beyond passive awareness of the user's own
  connection (no scanning others, no offensive tooling).
- Cloud processing of any kind for the core privacy features.
