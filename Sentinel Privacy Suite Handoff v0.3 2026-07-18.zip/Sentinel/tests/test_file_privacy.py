import io
import sys
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

import piexif
import pytest
from pypdf import PdfWriter
from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from core.findings import Severity
from file_privacy.formats import docx as docx_fmt
from file_privacy.formats import images as image_fmt
from file_privacy.formats import pdf as pdf_fmt
from file_privacy.remover import remove_metadata
from file_privacy.scanner import UnsupportedFileType, detect_format, scan_file


# ---------- fixtures: build real files with real metadata ----------

@pytest.fixture
def jpeg_with_gps(tmp_path) -> Path:
    img_path = tmp_path / "photo.jpg"
    img = Image.new("RGB", (20, 20), color="red")

    def deg_to_dms_rational(deg_float):
        deg = int(deg_float)
        minutes_float = (deg_float - deg) * 60
        minutes = int(minutes_float)
        seconds = round((minutes_float - minutes) * 60 * 100)
        return [(deg, 1), (minutes, 1), (seconds, 100)]

    lat, lon = 37.7749, -122.4194
    gps_ifd = {
        piexif.GPSIFD.GPSLatitudeRef: "N",
        piexif.GPSIFD.GPSLatitude: deg_to_dms_rational(abs(lat)),
        piexif.GPSIFD.GPSLongitudeRef: "W",
        piexif.GPSIFD.GPSLongitude: deg_to_dms_rational(abs(lon)),
    }
    zeroth_ifd = {
        piexif.ImageIFD.Make: b"TestCam",
        piexif.ImageIFD.Model: b"TestModel X",
        piexif.ImageIFD.Software: b"TestOS 1.0",
    }
    exif_dict = {"0th": zeroth_ifd, "GPS": gps_ifd}
    exif_bytes = piexif.dump(exif_dict)
    img.save(img_path, "jpeg", exif=exif_bytes)
    return img_path


@pytest.fixture
def jpeg_without_metadata(tmp_path) -> Path:
    img_path = tmp_path / "clean.jpg"
    Image.new("RGB", (20, 20), color="blue").save(img_path, "jpeg")
    return img_path


@pytest.fixture
def pdf_with_metadata(tmp_path) -> Path:
    pdf_path = tmp_path / "doc.pdf"
    writer = PdfWriter()
    writer.add_blank_page(width=72, height=72)
    writer.add_metadata({"/Author": "Jane Tester", "/Producer": "TestSuite"})
    with open(pdf_path, "wb") as f:
        writer.write(f)
    return pdf_path


@pytest.fixture
def docx_with_metadata(tmp_path) -> Path:
    docx_path = tmp_path / "letter.docx"
    core_xml = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<cp:coreProperties '
        'xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" '
        'xmlns:dc="http://purl.org/dc/elements/1.1/" '
        'xmlns:dcterms="http://purl.org/dc/terms/">'
        "<dc:creator>Jane Tester</dc:creator>"
        "<cp:lastModifiedBy>Jane Tester</cp:lastModifiedBy>"
        "<dc:title>Confidential Letter</dc:title>"
        "</cp:coreProperties>"
    )
    with zipfile.ZipFile(docx_path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("docProps/core.xml", core_xml)
        zf.writestr("word/document.xml", "<document/>")
    return docx_path


# ---------- format detection ----------

def test_detect_format_dispatches_correctly(jpeg_with_gps, pdf_with_metadata, docx_with_metadata):
    assert detect_format(jpeg_with_gps) == "image"
    assert detect_format(pdf_with_metadata) == "pdf"
    assert detect_format(docx_with_metadata) == "docx"


def test_detect_format_unsupported_raises(tmp_path):
    unknown = tmp_path / "notes.txt"
    unknown.write_text("hello")
    with pytest.raises(UnsupportedFileType):
        detect_format(unknown)


# ---------- image EXIF ----------

def test_read_exif_finds_gps_and_tags(jpeg_with_gps):
    exif = image_fmt.read_exif(jpeg_with_gps)
    assert exif["gps"] is not None
    assert exif["gps"]["lat"] == pytest.approx(37.7749, abs=0.01)
    assert exif["gps"]["lon"] == pytest.approx(-122.4194, abs=0.01)
    assert exif["tags"]["Make"] == "TestCam"


def test_read_exif_clean_image_has_no_gps(jpeg_without_metadata):
    exif = image_fmt.read_exif(jpeg_without_metadata)
    assert exif["gps"] is None
    assert exif["tags"] == {}


def test_strip_exif_removes_gps(jpeg_with_gps, tmp_path):
    out = tmp_path / "stripped.jpg"
    image_fmt.strip_exif(jpeg_with_gps, out)
    exif_after = image_fmt.read_exif(out)
    assert exif_after["gps"] is None
    assert exif_after["tags"] == {}


# ---------- scanner produces Findings ----------

def test_scan_file_jpeg_gps_is_high_severity(jpeg_with_gps):
    findings = scan_file(jpeg_with_gps)
    gps_findings = [f for f in findings if f.category == "gps_metadata"]
    assert len(gps_findings) == 1
    assert gps_findings[0].severity == Severity.HIGH
    assert gps_findings[0].source_module == "file_privacy"


def test_scan_file_clean_jpeg_has_no_findings(jpeg_without_metadata):
    assert scan_file(jpeg_without_metadata) == []


def test_scan_file_pdf_author_is_medium_severity(pdf_with_metadata):
    findings = scan_file(pdf_with_metadata)
    author_findings = [f for f in findings if f.extra.get("key") == "Author"]
    assert len(author_findings) == 1
    assert author_findings[0].severity == Severity.MEDIUM


def test_scan_file_docx_creator_detected(docx_with_metadata):
    findings = scan_file(docx_with_metadata)
    categories = {f.category for f in findings}
    assert "docx_metadata" in categories
    creator_findings = [f for f in findings if "creator" in f.extra.get("key", "")]
    assert len(creator_findings) == 1
    assert creator_findings[0].extra["value"] == "Jane Tester"


# ---------- PDF metadata round trip ----------

def test_pdf_metadata_round_trip(pdf_with_metadata, tmp_path):
    meta_before = pdf_fmt.read_pdf_metadata(pdf_with_metadata)
    assert meta_before["Author"] == "Jane Tester"

    out = tmp_path / "clean.pdf"
    pdf_fmt.strip_pdf_metadata(pdf_with_metadata, out)
    meta_after = pdf_fmt.read_pdf_metadata(out)
    assert meta_after == {}


# ---------- DOCX metadata round trip ----------

def test_docx_metadata_round_trip(docx_with_metadata, tmp_path):
    meta_before = docx_fmt.read_docx_metadata(docx_with_metadata)
    assert meta_before["dc:creator"] == "Jane Tester"

    out = tmp_path / "clean.docx"
    docx_fmt.strip_docx_metadata(docx_with_metadata, out)
    meta_after = docx_fmt.read_docx_metadata(out)
    assert meta_after.get("dc:creator", "") == ""

    # sibling parts must survive untouched
    with zipfile.ZipFile(out) as zf:
        assert zf.read("word/document.xml") == b"<document/>"


# ---------- remover dispatch ----------

def test_remove_metadata_dispatches_by_format(jpeg_with_gps, pdf_with_metadata, docx_with_metadata, tmp_path):
    out_jpg = tmp_path / "out.jpg"
    out_pdf = tmp_path / "out.pdf"
    out_docx = tmp_path / "out.docx"

    remove_metadata(jpeg_with_gps, out_jpg)
    remove_metadata(pdf_with_metadata, out_pdf)
    remove_metadata(docx_with_metadata, out_docx)

    assert image_fmt.read_exif(out_jpg)["gps"] is None
    assert pdf_fmt.read_pdf_metadata(out_pdf) == {}
    assert docx_fmt.read_docx_metadata(out_docx).get("dc:creator", "") == ""


def test_remove_metadata_never_touches_original(jpeg_with_gps, tmp_path):
    original_bytes_before = jpeg_with_gps.read_bytes()
    out = tmp_path / "out.jpg"
    remove_metadata(jpeg_with_gps, out)
    assert jpeg_with_gps.read_bytes() == original_bytes_before
