import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from camera.distortions import pixelate, block_shuffle, feather_mask, scramble_region
from camera.tracking import SmoothedBox, get_box_from_landmarks


def make_region(h=40, w=40):
    rng = np.random.default_rng(0)
    return rng.integers(0, 255, (h, w, 3), dtype=np.uint8)


def test_pixelate_preserves_shape():
    region = make_region()
    out = pixelate(region, block_size=8)
    assert out.shape == region.shape


def test_pixelate_handles_tiny_region():
    region = make_region(0, 0)
    out = pixelate(region, block_size=8)
    assert out.shape == region.shape


def test_block_shuffle_preserves_shape_and_pixel_set():
    region = make_region(32, 32)
    rng = np.random.default_rng(1)
    out = block_shuffle(region, block_size=8, rng=rng)
    assert out.shape == region.shape
    # shuffle should rearrange blocks, not invent/destroy pixel values
    assert sorted(region.flatten().tolist()) == sorted(out.flatten().tolist())


def test_block_shuffle_too_small_is_noop():
    region = make_region(4, 4)
    rng = np.random.default_rng(1)
    out = block_shuffle(region, block_size=8, rng=rng)
    assert np.array_equal(out, region)


def test_feather_mask_center_is_one_edges_fade():
    mask = feather_mask(40, 40, feather_px=10)
    assert mask[20, 20] == 1.0
    assert mask[0, 0] == 0.0
    assert 0.0 < mask[5, 20] < 1.0


def test_feather_mask_zero_feather_is_flat_one():
    mask = feather_mask(20, 20, feather_px=0)
    assert np.all(mask == 1.0)


def test_scramble_region_light_mode_preserves_shape():
    region = make_region(32, 32)
    rng = np.random.default_rng(2)
    out = scramble_region(region, "light", block_size=8, blur_ksize=15, warp_strength=10, rng=rng)
    assert out.shape == region.shape


def test_scramble_region_blur_mode_preserves_shape():
    region = make_region(32, 32)
    rng = np.random.default_rng(2)
    out = scramble_region(region, "blur", block_size=8, blur_ksize=15, warp_strength=10, rng=rng)
    assert out.shape == region.shape


def test_scramble_region_warp_mode_with_anchors():
    region = make_region(32, 32)
    rng = np.random.default_rng(2)
    anchors = [(16, 16), (5, 5), (25, 25)]
    out = scramble_region(region, "warp", block_size=8, blur_ksize=15, warp_strength=10, rng=rng, landmarks_local=anchors)
    assert out.shape == region.shape


def test_smoothed_box_converges_toward_new_value():
    smoother = SmoothedBox(alpha=0.5)
    first = smoother.update((0, 0, 100, 100))
    assert first == (0, 0, 100, 100)
    second = smoother.update((100, 100, 200, 200))
    # halfway between old and new box for each coordinate
    assert second == (50, 50, 150, 150)


def test_get_box_from_landmarks_pads_and_clamps():
    landmarks = [(50, 50), (60, 60), (40, 70)]
    x1, y1, x2, y2 = get_box_from_landmarks(landmarks, frame_w=100, frame_h=100, pad_frac=0.5)
    assert 0 <= x1 < x2 <= 100
    assert 0 <= y1 < y2 <= 100
