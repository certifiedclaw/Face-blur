"""Sentinel Privacy Suite - entry point.

Currently launches Camera Shield directly. As identity_audit, file_privacy,
network, and the PyQt6 dashboard come online, this will route to a proper
CLI/dashboard chooser instead of assuming camera mode.
"""

from __future__ import annotations

import logging
import sys

from camera.shield import CameraShield
from config.settings import CameraShieldConfig


def main() -> int:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    config = CameraShieldConfig.from_args()
    shield = CameraShield(config)
    try:
        shield.run()
    except RuntimeError as e:
        logging.getLogger(__name__).error(str(e))
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
