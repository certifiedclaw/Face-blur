# CHANGELOG.md

## v0.3 — 2026-07-18

### Declined

- A second repo was suggested as a source for an "OSINT module"
  (`certifiedclaw/aether`). Inspected it: unrelated general-purpose voice
  assistant with a generic OSINT toolkit (WHOIS, subdomain enumeration,
  port scanning, breach checks, Google dorks) aimed at arbitrary targets.
  Conflicts with this project's own stated scope for `identity_audit/`
  (self-auditing only) and `network/` (no offensive networking). Not
  imported. See PROJECT_STATE.md for the full note and ROADMAP.md for what
  a properly self-audit-scoped identity module would look like instead.

### Added

- `core/findings.py`: shared `Finding`/`Severity` data structure, the
  prerequisite ARCHITECTURE.md flagged before `privacy_engine/` could be
  built for real.
- `file_privacy/` module, fully functional:
  - `formats/images.py`: EXIF read (`read_exif`, including GPS coordinate
    decoding) and strip (`strip_exif`) for JPEG/TIFF.
  - `formats/pdf.py`: PDF Info-dictionary read/strip.
  - `formats/docx.py`: DOCX `docProps/core.xml` read/strip using stdlib
    `zipfile`/`xml.etree` only (no `python-docx`/`lxml` dependency added).
  - `scanner.py`: `detect_format`, `scan_file`, `scan_directory` — produce
    `Finding` lists with severity assigned per category (GPS = HIGH,
    author/creator = MEDIUM, other metadata = LOW).
  - `remover.py`: `remove_metadata()`, dispatches by format, always writes
    to a separate output path (never mutates the original file).
  - `cli.py`: `python -m file_privacy.cli scan <path>` and
    `python -m file_privacy.cli clean <path> -o <output>`.
- `tests/test_file_privacy.py`: 13 new tests using real synthetic files
  (genuine EXIF via `piexif`, genuine PDF Info dict via `pypdf`, genuine
  DOCX `core.xml` via `zipfile`) — format detection, read/strip round
  trips for all three formats, Finding severity assignment, remover
  dispatch, and an explicit "original file bytes unchanged" guarantee.

### Fixed

- `pypdf.PdfWriter` was found to re-stamp `"/Producer": "pypdf"` on every
  `write()` regardless of `add_metadata({})` — caught by a round-trip test
  asserting exact post-strip metadata state. Fixed by explicitly
  overwriting every notable key (including Producer) with an empty string.
- Pillow's `Image.getdata()`/`putdata()` (used in `strip_exif`) is
  deprecated, slated for removal in Pillow 14 (2027-10-15). Switched to
  `img.tobytes()`/`Image.frombytes()`.

### Validation performed

- `python -m py_compile` on all new/changed files: pass.
- `python -m pytest tests/`: 24/24 pass (11 from v0.2 camera suite,
  13 new file_privacy tests).
- Manual CLI smoke test: generated a real JPEG with EXIF GPS + Make tags,
  ran `python -m file_privacy.cli scan`, confirmed HIGH-severity GPS
  finding and LOW-severity Make finding; ran `clean`; rescanned the cleaned
  output and confirmed zero findings.
- **Not validated**: `file_privacy` against real-world (non-synthetic)
  files from actual cameras/phones/Office/Acrobat — flagged as the next
  validation step in PROJECT_STATE.md and ROADMAP.md.

### Affected files

New: `Sentinel/core/findings.py`, `Sentinel/file_privacy/scanner.py`,
`Sentinel/file_privacy/remover.py`, `Sentinel/file_privacy/cli.py`,
`Sentinel/file_privacy/formats/__init__.py`,
`Sentinel/file_privacy/formats/images.py`,
`Sentinel/file_privacy/formats/pdf.py`,
`Sentinel/file_privacy/formats/docx.py`,
`Sentinel/tests/test_file_privacy.py`.
Modified: `Sentinel/requirements.txt` (added Pillow, pypdf, piexif),
`Sentinel/PROJECT_STATE.md`, `Sentinel/ARCHITECTURE.md`,
`Sentinel/ROADMAP.md`, `Sentinel/DEPENDENCY_REPORT.md`, `Sentinel/README.md`.

## v0.2 — 2026-07-18

Starting point: a single-file script (`scramblecam.py`-equivalent) pasted
into the handoff conversation. The linked GitHub repo returned a 404 during
this session and could not be used as the source of truth — see
PROJECT_STATE.md for the caveat this creates.

### Changed

- Restructured the single script into the target modular layout:
  `camera/distortions.py`, `camera/tracking.py`, `camera/shield.py`,
  `config/settings.py`, `main.py`. Scaffolded (empty) packages for
  `audio/`, `privacy_engine/`, `identity_audit/`, `file_privacy/`,
  `network/`, `dashboard/`, `plugins/`, `models/` per the target
  architecture, with no functional code in them yet.
- Replaced module-level constants (`CAM_INDEX`, `BLOCK_SIZE`, etc.) with a
  `CameraShieldConfig` dataclass and `argparse`-based CLI.

### Fixed

- **Warp mode now actually uses face landmarks.** The original
  `random_warp()` used a pure random displacement grid with no landmark
  input, contradicting its own docstring/module description. New
  `landmark_warp()` builds displacement from real FaceMesh anchor points
  (nose, eyes, mouth, chin, forehead).
- **Face box jitter.** Original recomputed an unsmoothed box every frame.
  Added `SmoothedBox` (exponential smoothing) per tracked face.
- **Crash on camera drop.** Original's `cap.read()` failure just broke the
  loop silently. Now retries the capture device.
- **mediapipe dependency break**: pinned `mediapipe==0.10.21` after
  discovering (by installing and testing 10 different versions) that
  `mediapipe>=0.10.30` removed the `mediapipe.solutions` legacy API this
  code depends on. Original script's `requirements` (implied, not
  formalized) would silently break on a fresh `pip install mediapipe`
  today. See DEPENDENCY_REPORT.md.

### Added

- Multi-face support (was single-face only).
- Edge feathering so scrambled regions blend instead of showing a hard
  rectangle seam.
- `blur` mode (third mode alongside light/warp) as a cheap fallback.
- FPS overlay toggle (`f` key).
- Warp-strength hotkeys (`[` / `]`), separate from block-size hotkeys
  (`=`/`-`).
- `requirements.txt` with verified, pinned versions.
- `tests/test_distortions.py`: 11 unit tests covering all pure functions
  (pixelate, block_shuffle, feather_mask, scramble_region dispatch,
  landmark_warp via scramble_region, SmoothedBox, get_box_from_landmarks).
- `README.md`, `PROJECT_STATE.md`, `ARCHITECTURE.md`, `ROADMAP.md`,
  `DEPENDENCY_REPORT.md` (this set of docs).

### Validation performed

- `python -m py_compile` on all changed files: pass.
- `python -m pytest tests/`: 11/11 pass.
- Manual smoke test: instantiated `CameraShield`, ran `process_frame()`
  against a real `mediapipe.solutions.face_mesh.FaceMesh` instance on a
  synthetic frame, forced the `warp` code path with fabricated landmark
  anchors, exercised keyboard handling. All ran without exceptions.
- **Not validated**: live webcam capture end-to-end, `pyvirtualcam` virtual
  device creation — no camera hardware or virtual-cam driver available in
  this sandbox. Flagged clearly in PROJECT_STATE.md as the top item to
  verify on real hardware before treating Camera Shield as fully done.

### Affected files

New: `Sentinel/main.py`, `Sentinel/camera/__init__.py`,
`Sentinel/camera/distortions.py`, `Sentinel/camera/tracking.py`,
`Sentinel/camera/shield.py`, `Sentinel/config/__init__.py`,
`Sentinel/config/settings.py`, `Sentinel/tests/__init__.py`,
`Sentinel/tests/test_distortions.py`, `Sentinel/requirements.txt`,
`Sentinel/README.md`, `Sentinel/PROJECT_STATE.md`,
`Sentinel/ARCHITECTURE.md`, `Sentinel/ROADMAP.md`,
`Sentinel/DEPENDENCY_REPORT.md`, `Sentinel/CHANGELOG.md`, plus empty
`__init__.py` placeholders in `audio/`, `privacy_engine/`,
`identity_audit/`, `file_privacy/`, `network/`, `dashboard/`, `plugins/`.
