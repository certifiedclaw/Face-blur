"""CLI entry point for Privacy Engine.

Usage:
    python -m privacy_engine.cli report <path> [--json]

Scans <path> (file or directory) using every available detection module
(today: file_privacy only) and prints an aggregated risk report.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from core.findings import Finding
from file_privacy.scanner import UnsupportedFileType, scan_directory, scan_file
from privacy_engine.report import build_report


def _collect_findings(path: Path) -> list[Finding]:
    if path.is_dir():
        results = scan_directory(path, recursive=True)
        findings: list[Finding] = []
        for file_findings in results.values():
            findings.extend(file_findings)
        return findings
    try:
        return scan_file(path)
    except UnsupportedFileType:
        return []


def cmd_report(args: argparse.Namespace) -> int:
    path = Path(args.path)
    if not path.exists():
        print(f"error: {path} does not exist", file=sys.stderr)
        return 1

    findings = _collect_findings(path)
    report = build_report(findings)

    if args.json:
        print(json.dumps(report.to_dict(), indent=2, default=str))
    else:
        print(report.render_text())
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="privacy_engine", description="Aggregate privacy findings into a report")
    sub = parser.add_subparsers(dest="command", required=True)

    report_p = sub.add_parser("report", help="scan a file or directory and print a privacy risk report")
    report_p.add_argument("path", help="file or directory to scan")
    report_p.add_argument("--json", action="store_true", help="output machine-readable JSON instead of text")
    report_p.set_defaults(func=cmd_report)

    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
