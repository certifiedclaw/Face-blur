# DEPENDENCY_REPORT.md

_Verified in this sandbox on 2026-07-18, Python 3.12.3, Linux x86_64.
Updated for v0.6 — fixed a real numpy/opencv-python/mediapipe pin
conflict (found during v0.5, fixed now). No new runtime dependencies
added._

## v0.6: numpy/opencv-python/mediapipe conflict — fixed

**The problem, exactly as found:** `mediapipe==0.10.21` requires
`numpy<2`. Current `opencv-python`/`opencv-python-headless` releases
(4.12.0.88 and later, verified via PyPI's release metadata) require
`numpy>=2`. The old `requirements.txt` pinned `opencv-python>=4.9,<5` —
wide open on the upper end — so a fresh `pip install -r requirements.txt`
could resolve to opencv-python 4.12+ and collide with mediapipe's numpy
cap. Confirmed by actually running the install fresh in this sandbox:
pip's resolver reported the conflict explicitly.

**The fix:** capped `opencv-python>=4.9,<4.12` in `requirements.txt`.
Checked PyPI's per-version `requires_dist` metadata directly (not
guessed) to find the boundary — 4.11.0.86 declares `numpy>=1.26.0` for
Python 3.12 (compatible with the `numpy<2.0` pin), 4.12.0.88 declares
`numpy>=2` (not compatible). The cap lands exactly on that boundary.

**Verified, not just reasoned about:** built a brand-new, completely
empty virtualenv (`python3 -m venv`, no pre-existing packages) and ran
`pip install -r requirements.txt` fresh against the corrected file —
resolved to opencv-python 4.11.0.86 / numpy 1.26.4 / mediapipe 0.10.21
with **zero** resolver conflict warnings (previously there were three).
Followed up with `pip check` (reports "No broken requirements found",
exit code 0) and a real functional smoke test: instantiated
`mediapipe.solutions.face_mesh.FaceMesh` and ran
`CameraShield.process_frame()` on a synthetic frame through the actual
installed stack — succeeded, correct output shape/dtype. Then ran the
full `pytest` suite in that same clean venv: 58/58 passed.

## Runtime dependencies

| Package | Pin | Verified installed version | Notes |
|---|---|---|---|
| opencv-python | `>=4.9,<4.12` (v0.6: capped, was `<5`) | 4.11.0.86 | **Cap is load-bearing, not arbitrary** — 4.12.0.88+ requires `numpy>=2`, which conflicts with mediapipe's `numpy<2` requirement below. Don't loosen this cap without re-checking mediapipe's numpy requirement at the same time. |
| numpy | `>=1.26,<2.0` | 1.26.4 | Capped below 2.0 because `mediapipe==0.10.21` requires it. This is the *actual* upstream constraint driving the numpy cap — the opencv-python cap above exists to stay compatible with *this*, not the other way around. If mediapipe's numpy requirement changes, revisit both pins together. |
| mediapipe | `==0.10.21` (hard pin) | 0.10.21 | **Critical, verified by bisection.** `mediapipe.solutions.face_mesh.FaceMesh` (the legacy API this codebase uses) is present in 0.10.14–0.10.21 and **absent** starting 0.10.30 (tested 0.10.30, 0.10.31, 0.10.32, 0.10.33, 0.10.35 — all missing `mp.solutions`). Google replaced it with the Tasks API (`mediapipe.tasks.vision`). Do not bump this pin without either porting `camera/shield.py` to the Tasks API or re-verifying `solutions` is somehow back. |
| pyvirtualcam | `>=0.11,<0.12` | 0.11.1 | Installs and imports cleanly (v0.6: actually installed and verified in this session, previously only reasoned about). Still **not functionally tested** — no display/virtual-cam driver available in this container, so `pyvirtualcam.Camera(...)` opening a real virtual device is unverified here. `CameraShield.run()` wraps it in try/except, so absence/failure degrades to no-vcam rather than crashing. |
| Pillow | `>=11.0,<13` | 12.3.0 | Used by `file_privacy/formats/images.py` for EXIF read/strip. No known issues at this range. |
| pypdf | `>=5.0,<6` | 5.9.0 | Used by `file_privacy/formats/pdf.py`. Note: `PdfWriter.write()` always re-stamps `"/Producer": "pypdf"` regardless of `add_metadata()` calls unless every key including Producer is explicitly overwritten — verified by test failure during v0.3 development, worked around in `strip_pdf_metadata()`. Re-check this behavior if pypdf is upgraded across a major version. |

Transitive: mediapipe pulls in `opencv-contrib-python` itself (needed
for its own internals) — pip resolved it to 4.11.0.86 as well in the
clean-venv test, matching the `opencv-python` pin with no conflict.
Nothing in `requirements.txt` needs to name it directly.

## Dev/test dependencies

| Package | Pin | Verified installed version |
|---|---|---|
| pytest | `>=8.0` | 9.1.1 |
| piexif | `>=1.1,<2` | 1.1.3 — test-only, builds synthetic EXIF for `tests/test_file_privacy.py` fixtures. Not imported by any `file_privacy/` module itself. |

## What was actually tested in this sandbox (v0.6 pass)

- Fresh `python3 -m venv` (zero pre-existing packages) → `pip install -r
  requirements.txt` against the corrected file → **zero conflict
  warnings** (down from three previously).
- `pip check` in that venv → `No broken requirements found.` (exit 0).
- Imported every runtime dependency directly (`numpy`, `cv2`,
  `mediapipe`, `PIL`, `pypdf`, `pyvirtualcam`) and printed each version —
  all succeeded.
- Confirmed `mediapipe.solutions.face_mesh` and
  `mediapipe.solutions.face_detection` both present on the installed
  0.10.21 build.
- Ran a real `mediapipe.solutions.face_mesh.FaceMesh` instance against a
  synthetic frame through `CameraShield.process_frame()` — no exceptions,
  correct output shape.
- Full `pytest tests/` in the clean venv: **58 passed**, 0 failed.

## Still not tested (unchanged from earlier, carried forward honestly)

- `pyvirtualcam.Camera(...)` actually producing a usable OS-level virtual
  webcam device — needs a real display + OBS/v4l2loopback driver, neither
  present in this container.
- `cv2.VideoCapture` against real physical camera hardware (USB webcam or
  a real RTSP/IP camera) — no camera device reachable from this sandbox.
- `--mode headless`'s MJPEG stream viewed from an actual second device
  over a real LAN.

## Recommendations

1. Before any future dependency bump, re-run this bisection process for
   whichever package changed — don't assume a routine `pip install -U`
   is safe. The mediapipe `solutions` removal *and* the opencv-python
   numpy>=2 bump are both proof that "just upgrade" silently breaks this
   stack.
2. If `numpy>=2` is ever required (e.g. for a future dependency), that
   forces dropping `mediapipe==0.10.21` and completing the Tasks API
   migration (see ROADMAP.md) at the same time — the two pins are now
   linked, not independent.
3. When the mediapipe Tasks API migration happens, this report needs a
   full rewrite of the mediapipe row, including new import paths and
   result-object shapes, and the opencv-python cap above should be
   re-evaluated (the Tasks API migration is likely to remove the reason
   for capping numpy at all).
4. Consider adding a CI job that does exactly what this session did by
   hand: fresh venv, `pip install -r requirements.txt`, `pip check`, run
   `pytest` — so a future silent break is caught automatically instead of
   requiring someone to remember to re-verify.
