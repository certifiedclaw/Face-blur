# CHANGELOG.md

## v0.6 — 2026-07-18

### Fixed

- `requirements.txt`: capped `opencv-python>=4.9,<4.12` (was `>=4.9,<5`).
  opencv-python 4.12.0.88+ declares `numpy>=2` (checked directly against
  PyPI's release metadata, not guessed), which conflicts with
  `mediapipe==0.10.21`'s `numpy<2` requirement. The old unbounded upper
  cap meant a fresh install could land on either side of that line
  depending on when you ran it. 4.11.0.86 is the newest version still on
  the numpy<2 side, matching the existing `numpy>=1.26,<2.0` pin.

### Verified this session, exactly what was checked

- Built a brand-new, completely empty virtualenv (no pre-existing
  packages of any kind) and ran `pip install -r requirements.txt` against
  the fixed file: resolved to opencv-python 4.11.0.86 / numpy 1.26.4 /
  mediapipe 0.10.21 with **zero** resolver conflict warnings (there were
  three before the fix, from a separate ad-hoc install in a different
  session).
- `pip check` in that venv: `No broken requirements found.` (exit 0).
- Imported every runtime dependency (`numpy`, `cv2`, `mediapipe`, `PIL`,
  `pypdf`, `pyvirtualcam`) directly and printed versions — all succeeded.
- Confirmed `mediapipe.solutions.face_mesh`/`face_detection` still
  present on the resolved mediapipe 0.10.21 build.
- Instantiated a real `mediapipe.solutions.face_mesh.FaceMesh` and ran
  `CameraShield.process_frame()` on a synthetic frame through the
  actually-installed stack: succeeded, correct output shape/dtype.
- Full `pytest tests/` in the same clean venv: `58 passed`, unchanged
  from before the fix (this was a dependency-resolution fix, not a code
  change, so the same 58 tests apply).

## v0.5 — 2026-07-18

### Added

- `config/settings.py`: `DeploymentMode` enum (`desktop` / `headless`) and
  a `--mode` CLI flag. `CameraShieldConfig.source` replaces the old
  `cam_index: int`-only field — it now accepts either a local device index
  (USB webcam) or a string RTSP/HTTP URL (network/IP camera), parsed by
  the new `_parse_source()` helper. Every output channel (preview window,
  virtual camera, HTTP stream) gets a sensible default from `--mode` but
  can still be forced on/off individually (`--preview`/`--no-preview`,
  `--vcam`/`--no-vcam`, `--stream`/`--no-stream`).
- `camera/stream_server.py`, new module: a minimal stdlib-only
  (`http.server`, no Flask/FastAPI) MJPEG HTTP server — `FrameBuffer`
  (thread-safe latest-frame holder) + `MjpegStreamServer`. Serves the
  already-anonymized output at `http://<host>:<port>/` for viewing from
  any device on the local network, since a homelab/server box has no
  display for `cv2.imshow` and no video-call app to feed a virtual camera
  into.
- `camera/shield.py`: `CameraShield.run()` now branches on
  `deployment_mode` — desktop mode is unchanged (mirror flip, preview
  window, virtual cam); headless mode never calls `cv2.imshow`/
  `cv2.waitKey` (both require a display server and will error without
  one), skips the desktop-only mirror flip (wrong for a fixed IP camera),
  and pushes frames into a `FrameBuffer` for the stream server instead.
- 13 new tests: `tests/test_deployment_mode.py` (8, config/CLI defaults
  and overrides), `tests/test_stream_server.py` (5, real HTTP requests
  against a real server on loopback — index page, MJPEG content-type and
  boundary framing, 404 handling).

### Found, documented, not yet fixed

- `requirements.txt`'s `numpy>=1.26,<2.0` pin conflicts with current
  `opencv-python`/`opencv-python-headless` releases, which require
  `numpy>=2` — a genuine 3-way pip resolver conflict alongside the
  `mediapipe==0.10.21` pin (which also wants numpy<2). Surfaced by
  actually running `pip install` fresh, not just reading the file. See
  ROADMAP.md and DEPENDENCY_REPORT.md.

### Verified this session, exactly what was checked

- `python -m py_compile` on every file: clean.
- Full pytest suite: `58 passed` (45 carried over from v0.4 + 13 new).
- Manually constructed both a desktop config (`--mode desktop`, default
  source `0`) and a headless config (`--mode headless --source
  rtsp://...`) and called `CameraShield.run()` on each: both correctly
  attempt to open the configured source and raise a clear `RuntimeError`
  when it doesn't exist — this sandbox has neither a USB webcam nor a
  reachable RTSP camera, so that's as far as this environment can verify.
- **Not verified**: an actual physical homelab deployment — real USB
  webcam or real RTSP/IP camera on a real headless Linux box, and the
  MJPEG stream actually viewed in a browser over a LAN. Needs testing on
  real hardware before calling headless mode "field-tested."

## v0.4 — 2026-07-18

### Added

- `file_privacy` format coverage expanded:
  - PNG support: `formats/images.py` gains `read_png_metadata()` /
    `strip_png_metadata()` — reads both free-text chunks (Author, Software,
    Comment, etc, via Pillow's `img.text`/`img.info`) and any real `eXIf`
    chunk (reuses the existing EXIF/GPS decoding path). `scanner.py` and
    `remover.py` updated to dispatch `.png` files.
  - DOCX `docProps/app.xml` support: `formats/docx.py`'s
    `read_docx_metadata()`/`strip_docx_metadata()` now also read/clear
    Company and Manager fields, which live in `app.xml` and were entirely
    invisible to v0.3's core.xml-only implementation. `strip_docx_metadata`
    was rewritten to clear both XML parts generically via a shared
    `_clear_fields()` helper instead of one function hard-coded to
    core.xml.
- `privacy_engine/` module, fully functional:
  - `report.py`: `build_report(findings)` -> `PrivacyReport` (weighted
    score, risk label, plain-language explanation, findings grouped by
    module and by severity). Pure function of a `Finding` list — no
    imports from any detection module.
  - `cli.py`: `python -m privacy_engine.cli report <path> [--json]`, scans
    via `file_privacy` and renders the report in the
    `Privacy Report / <module>: / Overall Risk: / Explanation:` shape the
    original project spec sketched, or as JSON.
- `tests/test_file_privacy.py`: 10 new tests for PNG and DOCX app.xml
  (fixtures build real PNG text chunks and real app.xml, round-trip
  scan/strip, severity assignment).
- `tests/test_privacy_engine.py`: 11 new tests for score/label/grouping/
  explanation/rendering.

### Fixed

- Risk-threshold miscalibration caught by a failing test during
  development: a single HIGH-severity finding (e.g. one GPS leak) was
  landing in the "Moderate" band, which undersells a genuinely serious
  single exposure. Retuned `RISK_THRESHOLDS` so one HIGH finding alone
  reads as "High," not diluted by being the only finding.

### Validation performed

- `python -m py_compile` on every file in the project: pass.
- `python -m pytest tests/`: 45/45 pass (11 camera, 23 file_privacy,
  11 privacy_engine).
- End-to-end smoke test: built a real demo directory (GPS-tagged JPEG,
  PNG with Author/Comment text chunks, a clean PNG with no metadata), ran
  `python -m privacy_engine.cli report` against it in both text and
  `--json` mode. Confirmed: correct HIGH finding for GPS, correct MEDIUM
  findings for Author/Comment, correct LOW for camera Make tag, correct
  aggregate score and "Severe" label, and the clean PNG correctly
  contributed zero findings.
- **Not validated**: any of this against real-world (non-synthetic) files.
  Still the top follow-up item per PROJECT_STATE.md/ROADMAP.md.

### Affected files

New: `Sentinel/privacy_engine/report.py`, `Sentinel/privacy_engine/cli.py`,
`Sentinel/tests/test_privacy_engine.py`.
Modified: `Sentinel/file_privacy/formats/images.py` (PNG functions added),
`Sentinel/file_privacy/formats/docx.py` (app.xml support, strip function
rewritten), `Sentinel/file_privacy/scanner.py` (PNG dispatch, docx label
fix for app.xml keys), `Sentinel/file_privacy/remover.py` (PNG dispatch),
`Sentinel/tests/test_file_privacy.py` (PNG/app.xml fixtures and tests),
`Sentinel/PROJECT_STATE.md`, `Sentinel/ARCHITECTURE.md`,
`Sentinel/ROADMAP.md`, `Sentinel/DEPENDENCY_REPORT.md`.

## v0.3 — 2026-07-18

### Declined

- A second repo was suggested as a source for an "OSINT module"
  (`certifiedclaw/aether`). Inspected it: unrelated general-purpose voice
  assistant with a generic OSINT toolkit (WHOIS, subdomain enumeration,
  port scanning, breach checks, Google dorks) aimed at arbitrary targets.
  Conflicts with this project's own stated scope for `identity_audit/`
  (self-auditing only) and `network/` (no offensive networking). Not
  imported. See PROJECT_STATE.md for the full note and ROADMAP.md for what
  a properly self-audit-scoped identity module would look like instead.

### Added

- `core/findings.py`: shared `Finding`/`Severity` data structure, the
  prerequisite ARCHITECTURE.md flagged before `privacy_engine/` could be
  built for real.
- `file_privacy/` module, fully functional:
  - `formats/images.py`: EXIF read (`read_exif`, including GPS coordinate
    decoding) and strip (`strip_exif`) for JPEG/TIFF.
  - `formats/pdf.py`: PDF Info-dictionary read/strip.
  - `formats/docx.py`: DOCX `docProps/core.xml` read/strip using stdlib
    `zipfile`/`xml.etree` only (no `python-docx`/`lxml` dependency added).
  - `scanner.py`: `detect_format`, `scan_file`, `scan_directory` — produce
    `Finding` lists with severity assigned per category (GPS = HIGH,
    author/creator = MEDIUM, other metadata = LOW).
  - `remover.py`: `remove_metadata()`, dispatches by format, always writes
    to a separate output path (never mutates the original file).
  - `cli.py`: `python -m file_privacy.cli scan <path>` and
    `python -m file_privacy.cli clean <path> -o <output>`.
- `tests/test_file_privacy.py`: 13 new tests using real synthetic files
  (genuine EXIF via `piexif`, genuine PDF Info dict via `pypdf`, genuine
  DOCX `core.xml` via `zipfile`) — format detection, read/strip round
  trips for all three formats, Finding severity assignment, remover
  dispatch, and an explicit "original file bytes unchanged" guarantee.

### Fixed

- `pypdf.PdfWriter` was found to re-stamp `"/Producer": "pypdf"` on every
  `write()` regardless of `add_metadata({})` — caught by a round-trip test
  asserting exact post-strip metadata state. Fixed by explicitly
  overwriting every notable key (including Producer) with an empty string.
- Pillow's `Image.getdata()`/`putdata()` (used in `strip_exif`) is
  deprecated, slated for removal in Pillow 14 (2027-10-15). Switched to
  `img.tobytes()`/`Image.frombytes()`.

### Validation performed

- `python -m py_compile` on all new/changed files: pass.
- `python -m pytest tests/`: 24/24 pass (11 from v0.2 camera suite,
  13 new file_privacy tests).
- Manual CLI smoke test: generated a real JPEG with EXIF GPS + Make tags,
  ran `python -m file_privacy.cli scan`, confirmed HIGH-severity GPS
  finding and LOW-severity Make finding; ran `clean`; rescanned the cleaned
  output and confirmed zero findings.
- **Not validated**: `file_privacy` against real-world (non-synthetic)
  files from actual cameras/phones/Office/Acrobat — flagged as the next
  validation step in PROJECT_STATE.md and ROADMAP.md.

### Affected files

New: `Sentinel/core/findings.py`, `Sentinel/file_privacy/scanner.py`,
`Sentinel/file_privacy/remover.py`, `Sentinel/file_privacy/cli.py`,
`Sentinel/file_privacy/formats/__init__.py`,
`Sentinel/file_privacy/formats/images.py`,
`Sentinel/file_privacy/formats/pdf.py`,
`Sentinel/file_privacy/formats/docx.py`,
`Sentinel/tests/test_file_privacy.py`.
Modified: `Sentinel/requirements.txt` (added Pillow, pypdf, piexif),
`Sentinel/PROJECT_STATE.md`, `Sentinel/ARCHITECTURE.md`,
`Sentinel/ROADMAP.md`, `Sentinel/DEPENDENCY_REPORT.md`, `Sentinel/README.md`.

## v0.2 — 2026-07-18

Starting point: a single-file script (`scramblecam.py`-equivalent) pasted
into the handoff conversation. The linked GitHub repo returned a 404 during
this session and could not be used as the source of truth — see
PROJECT_STATE.md for the caveat this creates.

### Changed

- Restructured the single script into the target modular layout:
  `camera/distortions.py`, `camera/tracking.py`, `camera/shield.py`,
  `config/settings.py`, `main.py`. Scaffolded (empty) packages for
  `audio/`, `privacy_engine/`, `identity_audit/`, `file_privacy/`,
  `network/`, `dashboard/`, `plugins/`, `models/` per the target
  architecture, with no functional code in them yet.
- Replaced module-level constants (`CAM_INDEX`, `BLOCK_SIZE`, etc.) with a
  `CameraShieldConfig` dataclass and `argparse`-based CLI.

### Fixed

- **Warp mode now actually uses face landmarks.** The original
  `random_warp()` used a pure random displacement grid with no landmark
  input, contradicting its own docstring/module description. New
  `landmark_warp()` builds displacement from real FaceMesh anchor points
  (nose, eyes, mouth, chin, forehead).
- **Face box jitter.** Original recomputed an unsmoothed box every frame.
  Added `SmoothedBox` (exponential smoothing) per tracked face.
- **Crash on camera drop.** Original's `cap.read()` failure just broke the
  loop silently. Now retries the capture device.
- **mediapipe dependency break**: pinned `mediapipe==0.10.21` after
  discovering (by installing and testing 10 different versions) that
  `mediapipe>=0.10.30` removed the `mediapipe.solutions` legacy API this
  code depends on. Original script's `requirements` (implied, not
  formalized) would silently break on a fresh `pip install mediapipe`
  today. See DEPENDENCY_REPORT.md.

### Added

- Multi-face support (was single-face only).
- Edge feathering so scrambled regions blend instead of showing a hard
  rectangle seam.
- `blur` mode (third mode alongside light/warp) as a cheap fallback.
- FPS overlay toggle (`f` key).
- Warp-strength hotkeys (`[` / `]`), separate from block-size hotkeys
  (`=`/`-`).
- `requirements.txt` with verified, pinned versions.
- `tests/test_distortions.py`: 11 unit tests covering all pure functions
  (pixelate, block_shuffle, feather_mask, scramble_region dispatch,
  landmark_warp via scramble_region, SmoothedBox, get_box_from_landmarks).
- `README.md`, `PROJECT_STATE.md`, `ARCHITECTURE.md`, `ROADMAP.md`,
  `DEPENDENCY_REPORT.md` (this set of docs).

### Validation performed

- `python -m py_compile` on all changed files: pass.
- `python -m pytest tests/`: 11/11 pass.
- Manual smoke test: instantiated `CameraShield`, ran `process_frame()`
  against a real `mediapipe.solutions.face_mesh.FaceMesh` instance on a
  synthetic frame, forced the `warp` code path with fabricated landmark
  anchors, exercised keyboard handling. All ran without exceptions.
- **Not validated**: live webcam capture end-to-end, `pyvirtualcam` virtual
  device creation — no camera hardware or virtual-cam driver available in
  this sandbox. Flagged clearly in PROJECT_STATE.md as the top item to
  verify on real hardware before treating Camera Shield as fully done.

### Affected files

New: `Sentinel/main.py`, `Sentinel/camera/__init__.py`,
`Sentinel/camera/distortions.py`, `Sentinel/camera/tracking.py`,
`Sentinel/camera/shield.py`, `Sentinel/config/__init__.py`,
`Sentinel/config/settings.py`, `Sentinel/tests/__init__.py`,
`Sentinel/tests/test_distortions.py`, `Sentinel/requirements.txt`,
`Sentinel/README.md`, `Sentinel/PROJECT_STATE.md`,
`Sentinel/ARCHITECTURE.md`, `Sentinel/ROADMAP.md`,
`Sentinel/DEPENDENCY_REPORT.md`, `Sentinel/CHANGELOG.md`, plus empty
`__init__.py` placeholders in `audio/`, `privacy_engine/`,
`identity_audit/`, `file_privacy/`, `network/`, `dashboard/`, `plugins/`.
