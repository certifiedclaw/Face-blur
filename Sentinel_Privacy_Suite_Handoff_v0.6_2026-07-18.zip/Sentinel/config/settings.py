"""Configuration for Camera Shield.

Centralizing settings here (instead of module-level globals scattered through
the pipeline) is what lets the dashboard, CLI, and future plugin system all
read/write the same config object.

v0.5: added `deployment_mode` so the same codebase runs two genuinely
different deployment shapes from one config, per the project's local-first
goal:

  desktop  : local USB webcam, on-screen preview window, output to a
             virtual webcam (pyvirtualcam) for use in Zoom/Meet/Discord.
             This is what v0.1-v0.4 assumed implicitly.

  headless : no display attached (a homelab box / server). Reads from a
             local device index *or* a network camera (RTSP/HTTP URL).
             Never touches cv2.imshow/waitKey (those need a display server
             and will error on a headless machine even if you don't look at
             the window). Serves the already-anonymized output as an MJPEG
             HTTP stream instead of a virtual webcam, since "virtual webcam
             on a headless box" isn't a meaningful concept -- nothing is
             video-calling from it.

`--mode` picks sensible defaults for preview/vcam/streaming; each of those
can still be forced on/off explicitly (e.g. `--mode desktop --stream` to
also expose an MJPEG feed from your desktop machine).
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from enum import Enum


class DeploymentMode(str, Enum):
    DESKTOP = "desktop"
    HEADLESS = "headless"


def _parse_source(raw: str) -> int | str:
    """A bare integer means a local device index (USB webcam). Anything
    else -- an RTSP/HTTP(S) URL, a `/dev/videoN`-style path -- is passed
    straight through: cv2.VideoCapture natively accepts either an int
    index or a string URL/path, so no further translation is needed."""
    try:
        return int(raw)
    except ValueError:
        return raw


@dataclass
class CameraShieldConfig:
    deployment_mode: DeploymentMode = DeploymentMode.DESKTOP

    # Camera source: int device index (USB webcam) or a string URL
    # (rtsp://... / http://... for a network/IP camera -- typical for a
    # homelab setup where the camera isn't physically in the server).
    source: int | str = 0

    block_size: int = 14
    blur_ksize: int = 35
    warp_strength: int = 40
    pad_fraction: float = 0.35
    feather_px: int = 18
    max_faces: int = 4
    smoothing_alpha: float = 0.5  # higher = less smoothing, more responsive
    min_detection_confidence: float = 0.5
    min_tracking_confidence: float = 0.5

    # Output. Desktop mode defaults preview+vcam on / stream off; headless
    # mode defaults preview+vcam off / stream on. See from_args().
    show_preview: bool = True
    use_virtual_cam: bool = True
    http_stream: bool = False
    http_host: str = "0.0.0.0"
    http_port: int = 8080
    http_jpeg_quality: int = 80

    @classmethod
    def from_args(cls, argv: list[str] | None = None) -> "CameraShieldConfig":
        parser = argparse.ArgumentParser(description="Sentinel Camera Shield")
        parser.add_argument(
            "--mode", choices=["desktop", "headless"], default="desktop",
            help="desktop: local preview window + virtual webcam (default). "
                 "headless: no display; for a homelab/server box -- serves "
                 "anonymized video over HTTP MJPEG instead.",
        )
        parser.add_argument(
            "--source", type=str, default="0",
            help="camera source: a device index (e.g. 0) for a local/USB "
                 "webcam, or a stream URL (e.g. rtsp://user:pass@host/stream) "
                 "for a network/IP camera. Default: 0.",
        )
        parser.add_argument("--block", type=int, default=14, help="pixel block size")
        parser.add_argument("--warp", type=int, default=40, help="max warp displacement (px)")
        parser.add_argument("--pad", type=float, default=0.35, help="face box padding fraction")
        parser.add_argument("--feather", type=int, default=18, help="edge feather width in px, 0 to disable")
        parser.add_argument("--max-faces", type=int, default=4, help="max faces to scramble at once")

        # Tri-state (None = "use the mode default") so --mode alone is enough
        # to get sane behavior, but every output can still be forced.
        parser.add_argument("--no-vcam", dest="vcam", action="store_false", default=None,
                             help="disable virtual camera (desktop mode only)")
        parser.add_argument("--vcam", dest="vcam", action="store_true", default=None,
                             help="force-enable virtual camera")
        parser.add_argument("--no-preview", dest="preview", action="store_false", default=None,
                             help="disable the local preview window (desktop mode only)")
        parser.add_argument("--preview", dest="preview", action="store_true", default=None,
                             help="force-enable the local preview window")
        parser.add_argument("--stream", dest="stream", action="store_true", default=None,
                             help="serve anonymized video over HTTP MJPEG "
                                  "(default: on in headless mode, off in desktop mode)")
        parser.add_argument("--no-stream", dest="stream", action="store_false", default=None,
                             help="disable HTTP MJPEG streaming")
        parser.add_argument("--http-host", type=str, default="0.0.0.0", help="MJPEG stream bind host")
        parser.add_argument("--http-port", type=int, default=8080, help="MJPEG stream bind port")
        parser.add_argument("--http-quality", type=int, default=80, help="MJPEG JPEG quality (1-100)")

        args = parser.parse_args(argv)
        mode = DeploymentMode(args.mode)
        source = _parse_source(args.source)

        if mode == DeploymentMode.HEADLESS:
            # No display server on a homelab/server box: never default to
            # opening a preview window or a virtual webcam device -- both
            # assume a desktop session that isn't there.
            default_preview, default_vcam, default_stream = False, False, True
        else:
            default_preview, default_vcam, default_stream = True, True, False

        return cls(
            deployment_mode=mode,
            source=source,
            block_size=args.block,
            warp_strength=args.warp,
            pad_fraction=args.pad,
            feather_px=args.feather,
            max_faces=args.max_faces,
            show_preview=default_preview if args.preview is None else args.preview,
            use_virtual_cam=default_vcam if args.vcam is None else args.vcam,
            http_stream=default_stream if args.stream is None else args.stream,
            http_host=args.http_host,
            http_port=args.http_port,
            http_jpeg_quality=args.http_quality,
        )
